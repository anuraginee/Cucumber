from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import requests
import threading
import os
import shutil


def search_google(search_term, root_dir):
    options = webdriver.FirefoxOptions()
    options.headless = True
    driver = webdriver.Firefox(options=options)
    driver.get(url)
    time.sleep(2)
    try:
        cookie_consent = driver.find_element(by=By.ID, value='L2AGLb')
        cookie_consent.click()
    except:
        pass
    time.sleep(1)
    search_box = driver.find_element(by=By.NAME, value='q')
    search_box.send_keys(search_term)
    search_box.send_keys(Keys.ENTER)
    time.sleep(3)
    i = 0
    for i in range(6):
        time.sleep(2)
        driver.execute_script(f"window.scrollTo({200000 * i}, {200000 * (i + 1)});")

    time.sleep(4)
    driver.execute_script(f"window.scrollTo({200000 * (i + 1)}, 0);")

    image_search_block = driver.find_element(by=By.CLASS_NAME, value='islrc')
    images = image_search_block.find_elements(by=By.CLASS_NAME, value='rg_i')
    i = 0
    dirpath = root_dir + '/' + '_'.join(search_term.split())
    os.mkdir(dirpath)
    print("Images List : ", len(images))
    for image in images:
        if i == 10:
            break
        image.click()
        #driver.implicitly_wait(5)
        time.sleep(2)
        # original_urls = driver.find_elements(by=By.CLASS_NAME, value='n3VNCb')
        driver.implicitly_wait(5)
        error_count = 1
        try:
            original_urls = driver.find_element(by=By.XPATH, value='//div[@id="islsp"]//div[@class="MAtCL PUxBg"]//img[@class="r48jcc pT0Scc iPVvYb"]')
            driver.implicitly_wait(5)
            original = []
            original.append(original_urls)


            # print("Image : ",image)
            # print("Original URLs : ", original_urls)
            for urls in original:
                original_url = urls.get_attribute('src')
                # print("Original URL : ",original_url)
                if 'http' in original_url and 'gstatic' not in original_url:
                    #print(original_url)
                    data = requests.get(original_url)
                    file = open(dirpath + '/' + '_'.join(search_term.split(' ')) + '_' + str(i) + '.jpg', 'wb')
                    file.write(data.content)
                    file.close()
                    # print()
                    print(f"Saved : {i} : {dirpath + '/' + '_'.join(search_term.split(' ')) + '_' + str(i) + '.jpg'}")
                    print(f"Link : {original_url}")
                    i += 1
                    break
        except Exception as e:
            print("Error .......", error_count, e)
            error_count += 1
            continue
    driver.close()



if __name__ == '__main__':
    root_dir = 'Images_HD_150_1'
    if os.path.isdir(root_dir):
        shutil.rmtree(root_dir)
    os.mkdir(root_dir)
    url = "https://www.google.com/imghp"
    search_terms = ['narendra modi in crowd','narendra modi in rally','narendra modi with people','modi women bill']
    # ['Jaguar-Aircraft', 'JAS-Gripen', 'JF-17', 'LCA-Tejas', 'Mig-21', 'Mig-23', 'Mig-27', 'Mirage-2000', 'Rafale', 'Sukhoi Su-30 MKI', 'Sukhoi Su-35', 'Surya-Kiran-Team']
    # search_terms = ['Sanna Marin', 'Narendra Modi', 'Vladimir Putin', 'Tsai Ing-wen', 'Iván Duque Márquez', 'Alberto Fernández', 'Joe Bidden', 'Felix Tshisekedi', 'Jacinda Ardern', 'Carlos Alvarado Quesada']
    #              [Finland         India             Russia              Taiwan          Columbia              Argentina           USA             DRC                 NZ              Cost rica

    # threads = []
    for search_term in search_terms:
        search_google(search_term, root_dir)
        # threading.Thread(target=search_google, args=(search_term, root_dir)).start()
        # threading.Thread(target=search_google, args=(search_term, root_dir)).start()

    # for idx, thread in enumerate(threads):
    #     thread.start()
    #
    #     if (idx + 1) % 5 == 0:
    #         thread.join()







