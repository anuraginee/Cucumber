#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri August 05

@author: KapilM
"""

# Parse command line arguments
from app_config import app_params
import time
import requests
import base64
import warnings
warnings.filterwarnings("ignore")
import yaml

config_file_name = "app_config.yaml"
with open(config_file_name) as file:
    app_params = yaml.load(file, Loader=yaml.FullLoader)
        
def create_json_dict(**data):
    return data

def call_service(json_dict, headers, service_name):
    print(f"type(service_name) :: {type(service_name)}")
    print(service_name)
    r = requests.post(f'{service_name}', verify=False,
                      headers = headers,
                      json = json_dict)
    print(r)
    res = r.json()
    print(res)
    return res
            
def get_Face_features(imagepath):
    start = time.perf_counter()
    face_features_str = ""
    face_rot = -1
    print(f"Image Path is :: {imagepath}")
    
    try:
        srcBGR = base64.b64encode(open(imagepath, "rb").read()).decode('utf-8')
    except:
        timefacedet = time.perf_counter() - start
        return -1, timefacedet, face_features_str, face_rot
    json_dict =  create_json_dict(img_base64 = srcBGR, is_color_flag = app_params['is_color_flag'], is_face_rotation_flag = app_params['is_face_rotation_flag'],
    face_features_flag = app_params['face_features_flag'])
    headers = {"x-api-key" : app_params['x-api-key']}
    
    url = app_params['frs_api_ip_address'] + app_params['frs_api_get_face_image_assessment']

    print(json_dict)
    start=time.perf_counter()
    res = call_service(json_dict, {"x-api-key" : app_params['x-api-key']}, url)
    print(f"res is :: {res}")
    timefacedet = time.perf_counter() - start
    if res['success_flag'] == 0 and res['image_info']['invalid_image'] == True:
        print(f"image_path is :: {imagepath}")
        return -1, timefacedet, face_features_str, face_rot,json_dict
    
    # -1 is for invalid images.
    
    if res['success_flag'] == 1 and res['image_info']['face_count'] == 0:
        timefacedet = time.perf_counter() - start
        return -2, timefacedet, face_features_str, face_rot,json_dict
    
    # -2 is for no_faced images.
    
    if app_params['is_face_rotation_flag'] == True:
    
        if res['success_flag'] == 1 and res['image_info']['face_count'] == 1:
            if int(res['image_info']['angle']) > 0:
                face_rot = int(res['image_info']['angle'])
                timefacedet = time.perf_counter() - start
                return -3 , timefacedet, face_features_str, face_rot,json_dict
            
            # -3 is for face_rotated images.
    
    if res['success_flag'] == 1 and res['image_info']['face_count'] == 1:
        #print('Inside the face_count 1 is --> ')
        face_features_str = res['face_info'][0]['features']
        
        if app_params['is_face_rotation_flag'] == True:
            face_rot = int(res['image_info']['angle'])
            
        return 1, timefacedet, face_features_str, face_rot,json_dict
    
    # 1 is for image found successfully.
            
    if res['success_flag'] == 1 and res['image_info']['face_count'] > 1:
        timefacedet = time.perf_counter() - start
        return res['image_info']['face_count'] , timefacedet, face_features_str, face_rot,json_dict
    




