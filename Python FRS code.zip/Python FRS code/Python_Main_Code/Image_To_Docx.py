import pandas as pd
from docx import Document
from docx.shared import Inches

# Read the CSV file
def read_csv_and_filter(csv_file_path):
    # Read the CSV file into a DataFrame
    df = pd.read_csv(csv_file_path)
    
    # Initialize an empty list to store image paths
    image_paths = []
    
    # Iterate through rows and check the condition
    for index, row in df.iterrows():
        image_match_count = row['Image_match_Count']
        image_path = row['Image_Path_x']
        print(f'image_match_count:::::::: {image_match_count}')
        print(f'image_path:::::::: {image_path}')
        
        # Check if the Image_match_Count is less than 5
        if image_match_count < 5:
            # Add the Image_Path_x value to the list
            image_paths.append(image_path)
    
    return image_paths

# Function to add images to a Word document
def add_images_to_word(image_paths, output_docx):
    doc = Document()

    # Iterate through the image paths and add each image to the document
    for image_path in image_paths:
        doc.add_picture(image_path, width=Inches(4), height=Inches(3))
        doc.add_paragraph()  # Add a paragraph between images (optional)

    # Save the Word document
    doc.save(output_docx)

if __name__ == "__main__":
    csv_file_path = 'C:\\Users\\pratik\\Desktop\\FRS_Python_Code\\One_N_Output_File_Path\\Reports\\One_N_Final_Report.csv'  # Replace with your CSV file path
    
    # Call the function to read and filter the CSV file
    filtered_image_paths = read_csv_and_filter(csv_file_path)
    print(f"filtered_image_paths :::::::::: {filtered_image_paths}")
    
    # Print the filtered image paths
    print("Image Paths with Image_match_Count < 5:")
    for image_path in filtered_image_paths:
        print(f"Image paths ::::::::::::: {image_path}")




