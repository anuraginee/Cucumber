import argparse
import Image_Metadata as Img_Data
import benchmarking_service_call as benchmarking_service_call
import One_N_Final as OneN
# import Query_Set as QS
from app_config import app_params
from os.path import exists

#Variable for Image_Metadata.py file
Input_Sheet = app_params["Input_Sheet"]
folder_path = app_params["folder_path"]
Folder_Path_Enroll = app_params["Folder_Path_Enroll"]
CSV_File_Path = app_params["CSV_File_Path"]
Enroll_Text_File = app_params["Enroll_Text_File"]
File_Path = app_params["file_path"]



#Variable for Quer_set.py file
# File_Path = app_params["file_path"]

#Variable for benchmarking_service_call.py file
match = app_params["match"]
text_path = app_params["text_file_path"]
input_paths = app_params["input_directory_path"]
output_paths = app_params["output_directory_path"]
ap = argparse.ArgumentParser()
ap.add_argument("-repeat", "--repeat-pairs", help="repeat number of pairs")
args = vars(ap.parse_args())
repeat_pairs = args["repeat_pairs"]




#Variable for One_N_Final.py file
# Input_Sheet = app_params["Input_Sheet"]
Text_File = app_params["One_To_N_Text_File"]
No_Face_File = app_params["No_Face_Text_File"]
Multiface_File = app_params["Multiface_Text_File"]
Final_Report_File = app_params["Final_Report_File"]
Multiface_CSV_File = app_params["Multiface_CSV_File"]
No_Face_CSV_File = app_params["No_Face_CSV_File"]
One_N_Result_CSV_File = app_params["One_N_Result_CSV_File"]
Invalid_CSV_File = app_params["Invalid_CSV_File"]
Invalid_File = app_params["Invalid_File"]


# Image_Metadata.py functions
image_info_dict_list = Img_Data.get_image_info_dict_list(folder_path)
Img_Data.write_image_info_dict_to_csv(image_info_dict_list, CSV_File_Path)
Img_Data.Read_Image_Name_Enroll(Folder_Path_Enroll,Enroll_Text_File)
# Img_Data.Read_Image_Name_Probe(CSV_File_Path,Probe_Text_File)
# print("Image File Names present in "+'\033[1m' + '\033[4m'+ "Probe_Image_Data_Set Folder"+ "\033[0m"+f" is added successfully into {Probe_Text_File}")
print(f"{Input_Sheet} CSV file is created successfully")
print("Image File Names present in "+'\033[1m' + '\033[4m'+ "Enroll_Image_Data_Set Folder"+ "\033[0m"+f" is added successfully into {Enroll_Text_File}")
jpg_files_list = Img_Data.get_jpg_files(folder_path)
Img_Data.add_list_to_text_file(File_Path,jpg_files_list)
print("Image File Names present in "+'\033[1m' + '\033[4m'+ "Probe_Image_Data_Set Folder"+ "\033[0m"+f" is added successfully into query_set file")



#benchmarking_service_call.py Functions
if match == 'p':
    print(f"Executing benchmarking service call function for {match}")
    benchmarking_service_call.runOnetoOne(input_paths, text_path, repeat_pairs, output_paths)
        
if match == "rq":
    print(f"Executing benchmarking service call function for {match}")
    benchmarking_service_call.runOnetoN(input_paths, text_path, repeat_pairs, output_paths)




# One_N_Final.py functions
Image_Match_count = OneN.Convert_text_file_to_csv(Text_File,One_N_Result_CSV_File)
OneN.Merge_CSV(Input_Sheet,One_N_Result_CSV_File,Final_Report_File,Image_Match_count)
file_exists = exists(Invalid_File)
if file_exists:
    print("Executed the Invalid_Face Python File")
    OneN.Invalid_CSV(Invalid_File,Invalid_CSV_File)
else :
    print(f"Inavlid file does not exist in {Invalid_File}")

file_exists_No_Face = exists(No_Face_File)
if file_exists_No_Face:
    print("Executed the No_Face Python File")
    OneN.No_Face_CSV(No_Face_File,No_Face_CSV_File)
else :
    print(f"No Face file does not exist in {No_Face_File}")

file_exists_Multiple_Faces = exists(Multiface_File)
if file_exists_Multiple_Faces:
    print("Executed the Multi_face Python File")
    OneN.MultiFace_CSV(Multiface_File,Multiface_CSV_File)
else :
    print(f"No Face file does not exist in {Multiface_File}")


OneN.Image_Remarks(Final_Report_File,No_Face_CSV_File,Multiface_CSV_File,Invalid_CSV_File,OneN.Header)
OneN.Hide_column(Final_Report_File)
print("FRS ------ One to N ------ "+'\033[1m' + '\033[4m'+ "FINAL REPORT CSV file"+ "\033[0m"+f" is created successfully under File Location --> {Final_Report_File}")



