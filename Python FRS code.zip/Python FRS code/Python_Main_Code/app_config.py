import yaml
#import config

config_file_name = "app_config.yaml"
with open(config_file_name) as file:
    app_params = yaml.load(file, Loader=yaml.FullLoader)

