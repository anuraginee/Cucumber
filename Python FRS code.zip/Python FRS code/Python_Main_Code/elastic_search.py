import os
import time
import numpy as np
import pickle
import glob
from operator import itemgetter
from elasticsearch import Elasticsearch
from elasticsearch.client import IndicesClient
from elasticsearch.helpers import parallel_bulk


def init_elastic_search(es_ip_address):
    try:
        #print(f'init_elastic_search start')
        es = Elasticsearch(es_ip_address,
                            request_timeout = 60000,
                            max_retries=1000,
                            retry_on_timeout=True)
        #print(f'init_elastic_search ping :: {es.ping()}')
        #print(f'init_elastic_search info :: {es.info()}')
    except Exception as e:
        print(f'ERROR :: {e}')

    return es

def get_all_index_names(es_ip_address):
    es = init_elastic_search(es_ip_address)
    #index_names = es.indices.get_alias("*")    
    #index_names = es.indices.get_alias().keys()
    indices_names = []
    for elem in es.cat.indices(format="json"):
        indices_names.append( elem['index'] )
    return indices_names

def call_get_count_in_index(es_ip_address,index_name):

    es = init_elastic_search(es_ip_address)
    es.indices.refresh(index = index_name)

    ic = IndicesClient(es)
    stats = ic.stats(index = index_name)
    tc = stats['_all']['primaries']['docs']['count']
    return tc

#def call_add_items_to_index(host,port,scheme,ca_certs,basic_auth_user,basic_auth_pass,index_name,_id,face_embeddings,filter_1="",filter_2="",filter_3="",filter_4="",filter_5=""):
def call_add_items_to_index(es_ip_address,index_name,_id,face_embeddings,**kwargs):
    
    es = init_elastic_search(es_ip_address)

    #def filterDict(**kwargs):
    doc = dict(filter(itemgetter(1), kwargs.items()))

    doc['face_embeddings'] = face_embeddings
    #print(f'doc :: {doc}')

    resp = es.index(index = index_name,id=_id, body = doc)
    es.indices.refresh(index = index_name)
    return resp

def call_delete_item_from_index(es_ip_address,index_name,_id):
    es = init_elastic_search(es_ip_address)
    #print(index_name)
    resp = es.delete(index = index_name, id = _id, refresh = True)
    return resp

def convert_threshold_es_l2(thresh):
    return (1 / thresh) - 1

def call_search_index_knn(es_ip_address,index_name,features,top_k,threshold):
    es = init_elastic_search(es_ip_address)

    items = []
    distances = []

    for j in range(len(features)):
        res_ids = []
        res_distances = []
        vec = features[j]
        #print(f"vec is :: {vec}")
        query = {
            "knn": {
            "field": "face_embeddings",
            "query_vector": list(vec),
            "k": top_k,
            "num_candidates": 200
            }
        }

        output = es.knn_search(index = index_name, body = query)

        for i in output['hits']['hits']:
            res = dict()
            candidate_score = i["_score"]
            _id = i['_id']
            candidate_score = convert_threshold_es_l2(candidate_score)
            if candidate_score <= threshold: #threshold:
                res['_id'] = _id
                for key in i['_source'].keys():
                    if key != "face_embeddings":
                        res[key] = i['_source'][key]
                res_ids.append(res)
                res_distances.append(candidate_score)
            #else:
            #    res['_id'] = "-1"
            #    res_ids.append(res)
            #    res_distances.append(candidate_score)

        #if len(res_ids) > 0:
        items.append(res_ids)
        distances.append(res_distances)
    return items,distances  

def get_items_for_parallel_bulk(data_lst):
    #print("*"*60)
    for i in range(len(data_lst)):
        #print(data_lst[i])
        yield data_lst[i]
    #print("*"*60)
        
def call_add_bulk_items(es_ip_address,chunk_size,data_lst):
    es = init_elastic_search(es_ip_address)
    failed_id_list = []
    success_id_list = []
    try:
        for success, info in parallel_bulk(es, get_items_for_parallel_bulk(data_lst), chunk_size = chunk_size, thread_count=20, max_chunk_bytes=524288000):
            #print(f'success :: {success}')
            #print(f"info :: {info['index']['_id']}")
            if success:
                success_id_list.append(info['index']['_id'])
            else:
                failed_id_list.append(info['index']['_id'])
        es.indices.refresh(index = data_lst[0]['_index'])
        return success_id_list,failed_id_list
    except Exception as e:
        print(f'ERROR :: {e}')
        return success_id_list,failed_id_list
