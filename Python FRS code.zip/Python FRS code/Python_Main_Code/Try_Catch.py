import os

def execute_function_if_file_exists(file_path, file_name, function):
    full_file_path = os.path.join(file_path, file_name)
    
    if os.path.isfile(full_file_path):
        function()
    else:
        print("File not generated")

# Example usage:
def my_function():
    print("File_Exist")

file_path = "C:\\Users\\pratik\\Desktop\\FRS_Python_Code\\Old_Code\\One_N_Output_File_Path_Copy"
file_name = 'query_set_noface.txt'

execute_function_if_file_exists(file_path, file_name, my_function)

