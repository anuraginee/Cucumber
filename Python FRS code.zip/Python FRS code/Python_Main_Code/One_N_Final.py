import csv
import pandas as pd
from app_config import app_params
import numpy as np
import warnings
from service_call import call_service
import glob
from os.path import exists

warnings.filterwarnings("ignore")

""" YAML variable call using app_params """ 

Input_Sheet = app_params["Input_Sheet"]
Text_File = app_params["One_To_N_Text_File"]
Invalid_File = app_params["Invalid_File"]
No_Face_File = app_params["No_Face_Text_File"]
Multiface_File = app_params["Multiface_Text_File"]
Final_Report_File = app_params["Final_Report_File"]
Multiface_CSV_File = app_params["Multiface_CSV_File"]
No_Face_CSV_File = app_params["No_Face_CSV_File"]
Invalid_CSV_File = app_params["Invalid_CSV_File"]
One_N_Result_CSV_File = app_params["One_N_Result_CSV_File"]

Top_K = app_params["top_k"]

# Variables/lists used to read data from CSV and Text file
Invalid_value_New=[]
NoFace_value=[]
Invalid_value=[]
MultiFace_value=[]
Image_Match_Count=[]
Header = ['Image_Path']
image_name=[]

# Convert 1_To_N_Result Text File to CSV File
def Convert_text_file_to_csv(Text_File,One_N_Result_CSV_File):
    Output_value=[]
    # print(Text_File)
    with open(Text_File, 'r') as input_file:
        for line in input_file:
            data = line.strip().split('	')
            Output_value.append(data)
    # for i in range(len(Output_value)):
    #     for j in range(len(Output_value[i])):
    #         # print(Output_value[i][j])
    for sub_list in Output_value:
        count = len(sub_list)
        Image_Match_Count.append(str(count-1))
    # print(len(Image_Match_Count), Image_Match_Count)
    for i in range(1,Top_K+1):
        Header.append('Reference_Result-'+str(i))
    # print(Header)
    df = pd.read_csv(Text_File, sep="\t", names=Header)
    Header.append('Image_match_Count')
    # print(f"Image_Match_Count :: {Image_Match_Count}")
    df['Image_match_Count'] = Image_Match_Count
    df.to_csv(One_N_Result_CSV_File,index=False)
    df=pd.read_csv(One_N_Result_CSV_File)
    specific_column=df["Image_Path"]
    # print("The column is:")
    for i in specific_column:
        image_name.append(i.strip().split("\\")[-1])
    # print(image_name)
    # df['Image_Name'] = image_name
    df.insert(loc = 1,column = 'Image_Name',value=image_name)
    print(df)
    df.to_csv(One_N_Result_CSV_File,index=False)

    return Image_Match_Count

# Merge two CSV Files
def Merge_CSV(Input_Sheet,One_N_Result_CSV_File,Final_Report_File,Image_Match_Count):
    Input_Sheet = pd.read_csv(Input_Sheet)
    Final_Sheet = pd.read_csv(One_N_Result_CSV_File)
    Final_Report = pd.merge(Input_Sheet, Final_Sheet, on = 'Image_Name',how= 'outer')
    Final_Report.to_csv(Final_Report_File,index=False)
    with open(Final_Report_File, 'w', newline='') as Final_Result:
        write = csv.writer(Final_Result)
        write.writerow(Image_Match_Count)
    Final_Report.to_csv(Final_Report_File, index=False)

# Get the list of Invalid image names from No_Face.txt and append those values into CSV file
def Invalid_CSV(Invalid_File,Invalid_CSV_File):
    image_name_Invalid =[]
    with open(Invalid_File, 'r') as IF:
        for line in IF:
            data = line.strip().split('/')[-1]
            Invalid_value.append(data)
    # Open the New Invalid sheet file with Invalid_Value list value
    with open(Invalid_CSV_File, 'w', newline='') as Invalid_file:
        writer = csv.writer(Invalid_file)
        writer.writerow(['Image_Path'])
        for item in Invalid_value:
            writer.writerow([item])
    df=pd.read_csv(Invalid_CSV_File)
    specific_column=df["Image_Path"]
    # print("The column is:")
    for i in specific_column:
        image_name_Invalid.append(i.strip().split("\\")[-1])
    print(image_name_Invalid)
    print(len(image_name_Invalid))
    # df['Image_Name'] = image_name
    df.insert(loc = 1,column = 'Image_Name',value=image_name_Invalid)
    print(df)
    df.to_csv(Invalid_CSV_File,index=False)


# Get the list of No_Face image names from No_Face.txt and append those values into CSV file
def No_Face_CSV(No_Face_File,No_Face_CSV_File):
    image_name_No_Face =[]
    with open(No_Face_File, 'r') as IF:
        for line in IF:
            data = line.strip().split('/')[-1]
            NoFace_value.append(data)
    # Open the New No_Face_Sheet file with Invalid_Value list value
    with open(No_Face_CSV_File, 'w', newline='') as NoFace_file:
        writer = csv.writer(NoFace_file)
        writer.writerow(['Image_Path'])
        for item in NoFace_value:
            writer.writerow([item])
    df=pd.read_csv(No_Face_CSV_File)
    specific_column=df["Image_Path"]
    print("The column is:")
    for i in specific_column:
        image_name_No_Face.append(i.strip().split("\\")[-1])
    print(image_name_No_Face)
    # df['Image_Name'] = image_name
    df.insert(loc = 1,column = 'Image_Name',value=image_name_No_Face)
    # print(df)
    df.to_csv(No_Face_CSV_File,index=False)



# Get the list of Multiface image names from query_set_multifaces.txt and append those values into CSV file
def MultiFace_CSV(Multiface_File,Multiface_CSV_File):
    image_name_Multiface_Face=[]
    with open(Multiface_File, 'r') as MF:
        for line in MF:
            data = line.strip().split('/')[-1]
            MultiFace_value.append(data)
    # Open the New Multiface_Sheet file with MultiFace_Value list value
    with open(Multiface_CSV_File, 'w', newline='') as multiface_file:
        writer = csv.writer(multiface_file)
        writer.writerow(['Image_Path'])
        for item in MultiFace_value:
            writer.writerow([item])

    df=pd.read_csv(Multiface_CSV_File)
    specific_column=df["Image_Path"]
    # print("The column is:")
    for i in specific_column:
        image_name_Multiface_Face.append(i.strip().split("\\")[-1])
    # print(image_name)
    # df['Image_Name'] = image_name
    df.insert(loc = 1,column = 'Image_Name',value=image_name_Multiface_Face)
    # print(df)
    df.to_csv(Multiface_CSV_File,index=False)

# Append Invalid_Image_Remarks and MultiFace_Image_Remarks header into Header List

def Image_Remarks(Final_Report_File,No_Face_CSV_File,Multiface_CSV_File,Invalid_CSV_File,Header):
    df1 = pd.read_csv(Final_Report_File)
    column_name = 'Image_Name'
    Header.append('Remarks')
    # Read the data from the CSV(finalresult.csv,Invalid_Sheet.csv,Multiface_Sheet.csv) file for Image coloumn and print those in list variable
    df1_column = df1[column_name]

    file_exists = exists(Invalid_File)
    if file_exists:
        df4 = pd.read_csv(Invalid_CSV_File)
        # print(f"value for df4 csv file {df4}")
        column_name = 'Image_Name'
        Header.append('Remarks')
        df4_column = df4[column_name]
            # Compare the two CSV(finalresult.csv,Invalid_Face.csv) files with same coloumn name(Image_Name) and print Remark messages into the FINAL REPORT CSV file
        for img_name in df4_column:
            # print(img_name)
            df1.loc[df1_column == img_name, 'Remarks'] = "Invalid Image Test Data Set"  
        with open(Final_Report_File, 'w', newline='') as Final_Result:
            write = csv.writer(Final_Result)
            write.writerow(Image_Match_Count)   
        # Print the Final Results Sheet
        df1.to_csv(Final_Report_File, index=False)

    file_exists = exists(No_Face_CSV_File)
    if file_exists:
        df2 = pd.read_csv(No_Face_CSV_File)
        # print(f"value for df4 csv file {df4}")
        column_name = 'Image_Name'
        Header.append('Remarks')
        df2_column = df2[column_name]
            # Compare the two CSV(finalresult.csv,No_Face.csv) files with same coloumn name(Image_Name) and print Remark messages into the FINAL REPORT CSV file
        for img_name in df2_column:
            # print(img_name)
            df1.loc[df1_column == img_name, 'Remarks'] = "No Face Image Test Data Set"  
        with open(Final_Report_File, 'w', newline='') as Final_Result:
            write = csv.writer(Final_Result)
            write.writerow(Image_Match_Count)   
        # Print the Final Results Sheet
        df1.to_csv(Final_Report_File, index=False)
    file_exists = exists(Multiface_CSV_File)
    if file_exists:
        df3 = pd.read_csv(Multiface_CSV_File)
        # print(f"value for df4 csv file {df4}")
        column_name = 'Image_Name'
        Header.append('Remarks')
        df3_column = df3[column_name]
            # Compare the two CSV(finalresult.csv,No_Face.csv) files with same coloumn name(Image_Name) and print Remark messages into the FINAL REPORT CSV file
        for img_name in df3_column:
        # print(img_name)
            df1.loc[df1_column == img_name, 'Remarks'] = "Image Test dataset has Multiple Faces" 
        with open(Final_Report_File, 'w', newline='') as Final_Result:
            write = csv.writer(Final_Result)
            write.writerow(Image_Match_Count)   
        # Print the Final Results Sheet
        df1.to_csv(Final_Report_File, index=False)

    with open(Final_Report_File, 'w', newline='') as Final_Result:
            write = csv.writer(Final_Result)
            write.writerow(Image_Match_Count)   
        # Print the Final Results Sheet
    df1.to_csv(Final_Report_File, index=False)

def Hide_column(Final_Report_File):
    # Step 3: Read the CSV file
    df = pd.read_csv(Final_Report_File)

    # Step 4: Hide the column(s)
    columns_to_hide = ['Image_Path_y']
    df = df.drop(columns_to_hide, axis=1)

    # Step 5: Save the modified DataFrame to a new CSV file
    df.to_csv(Final_Report_File, index=False)

    

"""
# def execute_function_if_file_exists(file_path, file_name, function):
#     file_pattern = file_path + '/' + file_name
    
#     if glob.glob(file_pattern):
#         function()
#     else:
#         print("File not generated")

# # Example usage:
# def my_function():
#     print("Executing function...")

# file_path = '/path/to/folder'
# file_name = 'example.txt'

# execute_function_if_file_exists(file_path, file_name, my_function)

"""

"""Main function call """


# Convert_text_file_to_csv(Text_File,One_N_Result_CSV_File)
# Merge_CSV(Input_Sheet,One_N_Result_CSV_File,Final_Report_File,Image_Match_Count)
# Invalid_CSV(Invalid_File,Invalid_CSV_File)
# No_Face_CSV(No_Face_File,No_Face_CSV_File)
# MultiFace_CSV(Multiface_File,Multiface_CSV_File)
# Image_Remarks(Final_Report_File,No_Face_CSV_File,Multiface_CSV_File,Invalid_CSV_File,Header)
# Hide_column(Final_Report_File)
# print("Final One to N results CSV file is generated")


