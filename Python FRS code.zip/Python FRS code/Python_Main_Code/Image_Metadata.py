import os
from PIL import Image
import pandas as pd
from app_config import app_params
import service_call as service_call
import glob


""" YAML variable call using app_params """

# folder_path = app_params["folder_path"]
# Folder_Path_Enroll = app_params["Folder_Path_Enroll"]
# CSV_File_Path = app_params["CSV_File_Path"]
# Enroll_Text_File = app_params["Enroll_Text_File"]
# File_Path = app_params["file_path"]


def get_image_info_dict_list(folder_path):
    image_name_path = []
    image_info_dict_list = []
    json_dict_value ={}
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            image_name_path.append(os.path.join(root, file))

    
    for image_path in image_name_path:
        image = Image.open(image_path)
        res, timefacedet, face_features_str, face_rot,json_dict = service_call.get_Face_features(image_path)
        # print(f'res :::::::::::: {res}')
        # print(f'timefacedet :::::::::::::::: {timefacedet}')
        # print(f'face_rot :::::::::::::::: {face_rot}')
        # print(f'image features ::::::::::::::::::{json_dict}')
        image_info_dict = {
            "Image_Path": image.filename,
            "Image_Name": image.filename.strip().split("\\")[-1],
            "Obstacles": image.filename.strip().split("\\")[-2],
            "Looking_Up_Straight_Down": image.filename.strip().split("\\")[-3],
            "Face_Angle": image.filename.strip().split("\\")[-4],
            "Covered_OR_Uncovered": image.filename.strip().split("\\")[-5],
            "Clear_Blurred_Morphed": image.filename.strip().split("\\")[-6],
            "Multiple_Single_Face": image.filename.strip().split("\\")[-7],
            "Image_Height": image.size[1],
            "Image_Width": image.size[0]

        }
        for i,j in json_dict.items():
            if i == 'img_base64':
                continue
            image_info_dict[i]=j

        """
        #exifdata = image.getexif()
        img_w, img_h = image.size
        print(f"img_w :: {img_w}, img_h :: {img_h}")
        #print(c, img_h, img_w)
        continue
        for tag_id in exifdata:
            tag = TAGS.get(tag_id, tag_id)
            data = exifdata.get(tag_id)
            if isinstance(data, bytes):
                data = data.decode()
            image_info_dict[tag] = data   
        """
        image_info_dict_list.append(image_info_dict)
        # image_info_dict_list.append(json_dict_value)
        # print(image_info_dict_list)

    return image_info_dict_list
# print(image_info_dict_list)
#Input_sheet_generated
def write_image_info_dict_to_csv(image_data, csv_file_path):
    df = pd.DataFrame(image_data)
    df.to_csv(csv_file_path, header=True, index_label='index')

# Reference_set file generated
def Read_Image_Name_Enroll(Folder_Path_Enroll,Enroll_Text_File):
    # Get a list of all image files from Enroll Image Folder
    Image_files_Enroll = [f for f in os.listdir(Folder_Path_Enroll) if f.endswith(".jpg") or f.endswith(".png")]
    # Open a text file for writing the image names from Image_files_Enroll
    with open(Enroll_Text_File, "w") as f:
    # Write each image name to the text file
        for image_file in Image_files_Enroll:
            f.write(image_file + "\n")
    # print("Entered Image Name :: Enroll Folder :: Reference Set File")

# def Read_Image_Name_Probe(CSV_File_Path,Probe_Text_File):
#     df = pd.read_csv(CSV_File_Path, usecols=["Image_Name"])
#     # Append the selected data into a text file
#     with open(Probe_Text_File, 'w') as f:
#         for index, row in df.iterrows():
#             f.write(f"{row['Image_Name']}\n")
#     # print("Entered Image Name :: Enroll Folder :: Reference Set File")



def get_jpg_files(folder_path):
    jpg_files = []
    
    for file_path in glob.iglob(os.path.join(folder_path, '**/*.jpg'), recursive=True):
        relative_path = os.path.relpath(file_path, folder_path)
        jpg_files.append(relative_path)
    
    return jpg_files

def add_list_to_text_file(file_path,jpg_files):
    with open(file_path, 'w+') as file:
        for item in jpg_files:
            file.write(str(item) + '\n')




"""Main function call """

# image_info_dict_list = get_image_info_dict_list(folder_path)
# write_image_info_dict_to_csv(image_info_dict_list, CSV_File_Path)
# Read_Image_Name_Enroll(Folder_Path_Enroll,Enroll_Text_File)
# # Read_Image_Name_Probe(CSV_File_Path,Probe_Text_File)
# print(f"{CSV_File_Path} CSV file is created successfully")
# jpg_files_list = get_jpg_files(folder_path)
# # print(jpg_files_list)
# print(len(jpg_files_list))
# add_list_to_text_file(File_Path,jpg_files_list)
# print("Image File Names present in "+'\033[1m' + '\033[4m'+ "Enroll_Image_Data_Set Folder"+ "\033[0m"+f" is added successfully into {Enroll_Text_File}")
# print("Image File Names present in "+'\033[1m' + '\033[4m'+ "Probe_Image_Data_Set Folder"+ "\033[0m"+f" is added successfully into query_set file")




        


    
