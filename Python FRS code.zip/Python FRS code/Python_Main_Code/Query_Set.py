import glob
import os

def get_jpg_files(folder_path):
    jpg_files = []
    
    for file_path in glob.iglob(os.path.join(folder_path, '**/*.jpg'), recursive=True):
        relative_path = os.path.relpath(file_path, folder_path)
        jpg_files.append(relative_path)
    
    return jpg_files


def add_list_to_text_file(file_path,jpg_files):
    with open(file_path, 'a') as file:
        for item in jpg_files:
            file.write(str(item) + '\n')

folder_path = 'C:/Users/pratik/Desktop/FRS_Python_Code/Input_File_Path/Image_data_set/Probe_Image_Data_Set'
file_path ='C:/Users/pratik/Desktop/FRS_Python_Code/Input_File_Path/query_set.txt'
jpg_files_list = get_jpg_files(folder_path)
print(jpg_files_list)
print(len(jpg_files_list))
add_list_to_text_file(file_path,jpg_files_list)
print("Added list value into query_set.txt File")


