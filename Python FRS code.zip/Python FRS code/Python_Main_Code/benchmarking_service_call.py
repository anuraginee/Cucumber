#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri August 05

@author: KapilM
"""

import sys
from app_config import app_params
import os
import time
import numpy as np
import argparse
import json
import pickle as pkl
from pickle import load,dump,HIGHEST_PROTOCOL
import requests
import base64
import warnings
warnings.filterwarnings("ignore")
import pickle
from service_call import get_Face_features
from elastic_search import call_add_items_to_index, call_search_index_knn

# ap = argparse.ArgumentParser()


# ap.add_argument("-repeat", "--repeat-pairs", help="repeat number of pairs")
"""
ap.add_argument("-match", "--match", help="Specify which match pairs(p) or reference/query(rq)", required=True)
ap.add_argument("-path", "--text-file-path",
                help="path to folder where pairs | reference and query set is present",
                required =True)
ap.add_argument("-i", "--input-directory-path",
                help="path to the input file directory for images",
                required=True)
ap.add_argument("-o", "--output-directory-path",
                help="path to the output files directory",
                required=True)
"""
			
def write_output_file(output, file_path):
    with open(file_path, 'w') as f:
        for line in output:
            f.write(line)
            f.write('\n')
            
def write_pickle_file(vectors, file_path):
    with open(file_path, 'wb') as files:
        pkl.dump(vectors, files)
        
def create_json_dict(**data):
    return data

def call_service(json_dict, headers, service_name):
    print(f'the service_name is :: {service_name}')
    r = requests.post(f'{service_name}', verify=False,
                      headers = headers,
                      json = json_dict)
    res = r.json()
    print(res)
    return res

"""
def insert_face_features(face_features_str, unique_id = time.time()):
    
    json_dict = create_json_dict(index_name = app_params['index_name'], unique_id = unique_id, face_embedding = face_features_str)
    start = time.perf_counter()
    res = call_service(json_dict, {"x-api-key" : app_params['x-api-key']}, app_params['elastic_api_ip_address'] + app_params['es_api_get_insert_or_update_into_index'])
    
ṭ    if res['success_flag'] == 1:
        timefacefet = time.perf_counter() - start
        es_id = res['resp']['_id']
        result = res['resp']['result']
        return es_id, result, res['success_flag'], timefacefet
    else:
        timefacefet = time.perf_counter() - start
        return 0, 'failed', res['success_flag'], timefacefet
    
    timefacefet = time.perf_counter() - start
    
    return 0, res['resp']['result'], res['success_flag'], timefacefet   
"""

def insert_face_features(es_ip_address,index_name,_id,face_embeddings):
    start_time = time.time()
    
    try:
        resp = call_add_items_to_index(es_ip_address,index_name,_id,face_embeddings)
        #print(f"insert face features")
    except Exception as e:
        timefacefet = time.time() - start_time
        return -1, 'exception occured.', -1, timefacefet
    timefacefet = time.time() - start_time
    return _id, 'successfully ingested.', 1, timefacefet

def getFaceRecoCompareScore(entries, features_dictionary):

    output_pairs = []

    timefacematch = 0
    
    for index, entry in enumerate(entries):
        start = time.perf_counter()
        if index % 10000 == 9999 and index != 0:
            print(f"10,000 pairs have been verified.")
        imagepairs = entry.rstrip().split('\t')

        try:
            facial_features_flag1, face_features_list1 = features_dictionary[str(imagepairs[0])][0], features_dictionary[str(imagepairs[0])][1]
        except:
            facial_features_flag1, face_features_list1 = -1, ""
        try:
            facial_features_flag2, face_features_list2 = features_dictionary[str(imagepairs[1])][0], features_dictionary[str(imagepairs[1])][1]
        except:
            facial_features_flag2, face_features_list2 = -1, ""
            

        score = ""
        flag = ""
        if type(face_features_list1) is str and facial_features_flag1 == -1:
            #print(f"inside -1")
            score += "invalid\t"
        elif type(face_features_list1) is str and facial_features_flag1 == -2:
            #print(f"inside -2")
            score += "noface\t"
        elif type(face_features_list1) is str and facial_features_flag1 == -3:
            #print(f"inside -2")
            score += "rotated\t"
        elif isinstance(face_features_list1,str) and facial_features_flag1 > 1:
            #print(f"inside > 1")
            score += "multiface\t"
        #elif type(facial_features1).__module__ == np.__name__:
        elif isinstance(face_features_list1, str) and facial_features_flag1 == 1:
            #print(f"inside 1")
            flag += "face_"
            score += imagepairs[0] + "\t"

        if type(face_features_list2) is str and facial_features_flag2 == -1:
            #print(f"inside -1")
            score += "invalid\t-1"
        elif type(face_features_list2) is str and facial_features_flag2 == -2:
            #print(f"inside -2")
            score += "noface\t-1"
        elif type(face_features_list2) is str and facial_features_flag2 == -3:
            #print(f"inside -2")
            score += "rotated\t-1"
        elif isinstance(face_features_list2,str) and facial_features_flag2 > 1:
            #print(f"inside > 1")
            score += "multiface\t-1"            
        #elif type(facial_features2).__module__ == np.__name__:
        elif isinstance(face_features_list2,str) and facial_features_flag2 == 1:
            #print(f"inside 1")
            flag += "face"
            score += imagepairs[1] + "\t-1"

        if flag == "face_face":
            #print(f"inside face_face")

            json_dict = create_json_dict(feature1 = str(json.loads(face_features_list1)), feature2 = str(json.loads(face_features_list2)))
            
            res = call_service(json_dict, {"x-api-key" : app_params['x-api-key']}, app_params['frs_api_ip_address'] + app_params['frs_api_get_compare_features'])
            
            if int(res['success_flag']) == 1:
                #print(f"inside success_flag")
                distance = res['distance']
            end=time.perf_counter()
            timefacematch += (end - start)
            score = imagepairs[0] + "\t" + imagepairs[1] + "\t" + str(distance)
        output_pairs.append(score)
    
    return output_pairs, timefacematch

def get_Face_Reco_Embeddings_and_Class(entries, input_paths):
    
    start=time.perf_counter()

    invalid = []
    nofaces = []
    multifaces = []
    valid = []
    rotated = []
    img_ids = []
    img_features = []
    timefacedet = 0
    timefacefet = 0
    for i,entry in enumerate(entries):
        #print(f"the entry name during ingestion is :: {entry}")
        #print(f"the input path for enrolled image is :: {input_paths}")

        if i%10000 == 0 and i != 0:
            print("Images done {}".format(i))

        imagepairs = entry.rstrip()
        print(f" Image imagepairs ::::::::::: {imagepairs}")
        # print(f"before get_face_features..................!!")
        facial_features_flag, timefacedet1, face_features_str, face_rot, json_dict = get_Face_features(os.path.join(input_paths,imagepairs))
        
        # print(f"after get_face_features..................!!")
        timefacedet += timefacedet1
        
        if facial_features_flag == -1: # this is for invalid
            invalid.append(imagepairs)
        elif facial_features_flag == -2: # this is for no_face
            nofaces.append(imagepairs)
        elif facial_features_flag == -3: # this is for rotated
            rotated.append(imagepairs)
        elif facial_features_flag > 1: # this is for multifaces
            multifaces.append(imagepairs)
            if app_params['face_features_flag'] == 3:
                for feat in facial_features_flag:
                    valid.append(imagepairs)
                    
        elif facial_features_flag == 1: # this is the desired case, where successfully image is getting called and we are getting it's feat.
            # valid.append(imagepairs)
            unique_ids = imagepairs
            #es_id, result, success_flag, timefacefet1 = insert_face_features(face_features_str, unique_id = unique_ids)
            #print(f"features.shape :: {np.array(json.loads(face_features_str)).shape}")
            es_id, result, success_flag, timefacefet1 = insert_face_features(app_params['elastic_ip_address'],app_params['index_name'],unique_ids,np.array(json.loads(face_features_str)))
            timefacefet += timefacefet1
            if success_flag == 1:
               valid.append(imagepairs)
               img_ids.append(es_id)
               face_features_list = np.array(json.loads(face_features_str))
               img_features.append(face_features_list)
               
            # print("Insert facial features 1 when facial_features == 1")
    print(f"invalid face_features are : {len(invalid)}")
    return invalid, nofaces, multifaces, valid, timefacedet, img_ids, img_features, timefacefet, rotated
    
"""
def run_Query_set(entries, filepath):

    invalid = []
    no_face = []
    multi_faces = []
    rotated = []
    predOut = []
    start= time.perf_counter()
    for entry in entries:
        print(f"the entry name is :: {entry}")
        img_ids = []
        features = []

        facial_features, timefacefet1, face_features_str, face_rot, json_dict = get_Face_features(entry)
        #print(f"the facial features value is :: {facial_features}")
        
        if facial_features == -1:
            invalid.append(entry)
        elif facial_features == -2:
            no_face.append(entry)
        elif facial_features == -3:
            rotated.append(entry)
        elif facial_features > 1:
            multi_faces.append(entry)
        
        elif facial_features == 1:
            #print(f'type(face_features_str), {type(face_features_str)}')
            features = [json.loads(face_features_str)]
            #print(f'type(features), {type(features)}')
            #vec = np.array(r,dtype='float32')
            #features.append(vec)
            #print(type(features), features)
            
            json_dict = create_json_dict(face_embeddings = str(features), top_k = app_params['top_k'],
                                         index_name = app_params['index_name'])
                                         
            #print(json_dict)
            
            url = app_params['elastic_api_ip_address'] + app_params['es_api_get_search']
            
            res = call_service(json_dict, {"x-api-key" : app_params['x-api-key']}, url)

            #print(res)
                
            #print(f'res is {res}')                   
            if int(res['success_flag']) == 1:
                if int(res['msg'][-1]) == 1:
                    img_ids.append(f"{entry.split('/')[-1]}")
                    valuess = res['labels']
                    # print(f"values is :: {values}")
                    for values in valuess:
                        for value in values:
                            #print(f"value is :: {value['_id']}")
                            img_ids.append(value['_id'])
                        # print(f"img_ids :: {img_ids}")
                        predOut.append("\t".join(img_ids))
                        # print(f'predOut :: {predOut}')
            else:
                invalid.append(entry)
    try:
        with open(filepath, 'w') as files1:
            for items in predOut: 
                files1.write('%s\n' % items)
    except Exception as e:
        print(f'exception occured as {e} at writing 1_N_results.txt')
    end= time.perf_counter()
    
    return (end-start)/len(entries), invalid, no_face, multi_faces, rotated
"""

def run_Query_set(entries, filepath):
    
    invalid = []
    no_face = []
    multi_faces = []
    rotated = []
    predOut = []
    start= time.perf_counter()
    for entry in entries:
        #print(f"the entry name is :: {entry}")
        img_ids = []
        features = []

        facial_features, timefacefet1, face_features_str, face_rot, json_dict = get_Face_features(entry)
        #print(f"the facial features value is :: {facial_features}")
        
        if facial_features == -1:
            invalid.append(entry)
        elif facial_features == -2:
            no_face.append(entry)
        elif facial_features == -3:
            rotated.append(entry)
        elif facial_features > 1:
            multi_faces.append(entry)
        
        elif facial_features == 1:
            #print(f'type(face_features_str), {type(face_features_str)}')
            #features = [json.loads(face_features_str)]
            features = np.array(json.loads(face_features_str))
            #print(f'type(features), {type(features)}')
            #vec = np.array(r,dtype='float32')
            #features.append(vec)
            #print(type(features), features)
            
            try:
                features.resize(1,512)
                #print(f"features :: {features}")
                #print(f"len(features) :: {features.shape}")
                items, distances = call_search_index_knn(app_params['elastic_ip_address'],app_params['index_name'],features,app_params['top_k'],app_params['threshold'])
                img_ids.append(f"{entry.split('/')[-1]}")

                if items is not None:    
                    for itemss in items:
                        for item in itemss:
                            #print(f"item is :: {item}")
                            img_ids.append(item['_id'])
                    # print(f"img_ids :: {img_ids}")
                    predOut.append("\t".join(img_ids))
                    #print(f"predOut is :: {predOut}")
                    #print(items, distances)
            except Exception as e:
                print(f"INFO :: exception occured :: {e}")
                invalid.append(entry)
    #print(f"predout final is :: {predOut}")
    try:
        with open(filepath, 'w') as files1:
            for items in predOut: 
                files1.write('%s\n' % items)
    except Exception as e:
        print(f'exception occured as {e} at writing 1_N_results.txt')
    end= time.perf_counter()

    #print(f"invalid faces are :: {len(invalid)}")
    print(f"invalid list is :: {invalid}")
    
    return (end-start)/len(entries), invalid, no_face, multi_faces, rotated

def create_dictionary(names_list, input_paths):
    pickle_dict = {}
    timefacefeat = 0
    for index, entry in enumerate(names_list):
        if index % 10000 == 9999 and index !=  0:
            print(f"10000 images features has been calculated.")
        values = []
        facial_features_flag, timefacefet1, face_features_str, face_rot, json_dict  = get_Face_features(os.path.join(input_paths,entry))
        timefacefeat += timefacefet1
        values.append(facial_features_flag)
        values.append(face_features_str)
        
        pickle_dict[entry] = values       
    return pickle_dict, timefacefeat

def create_unique_list(names_list):
    myset1 = set(names_list)
    list1 = list(myset1)
    #list1 = natsorted(list1)
    return list1  

def create_pickle_files(text_path, repeat_pairs, input_paths):
    
    entries = open(os.path.join(text_path,"1to1pairs.txt"),"r").readlines()
    if repeat_pairs is not None:
        entries = entries[:int(repeat_pairs)]
        #entries = entries * int(repeat_pairs)
    
    list1 = []   
    
    for entry in entries:
        list1.append(entry.split('\t')[0])
        list1.append(entry.split('\t')[1].split('\n')[0])
        
    start_unique_time = time.perf_counter()
    list1 = create_unique_list(list1)
    end_unique_time = time.perf_counter()
   
    start_dict_time = time.perf_counter()
    features_dictionary, timefacefeat = create_dictionary(list1, input_paths)
    end_dict_time = time.perf_counter()
    print(f"time taken in creating the dictionary is :: {end_dict_time - start_dict_time:.2f}s")
  
    return features_dictionary, entries, timefacefeat

def runOnetoOne(input_paths, text_path, repeat_pairs, output_paths):
    start=time.perf_counter()
    if not os.path.isdir(input_paths):
        print('Directory path error!!')
        sys.exit()
        
    if not os.path.isdir(output_paths):
        os.makedirs(output_paths)
        print(f"output_directory_path created sucessfully.!!")
    else:
        print(f"output_directory_path already created.")
    
    features_dictionary, entries, timefacefeat = create_pickle_files(text_path, repeat_pairs, input_paths)
    
    print(f"list of unique sets available :: {len(features_dictionary)}")
    
    print('No. of pairs : ', len(entries))

    output_pairs, timefacematch = getFaceRecoCompareScore(entries, features_dictionary)
    end=time.perf_counter()

    timepairs = list("Time for Face Reco: {0}\nTime for face matching: {1}\nTime for Whole Program: {2}"\
                        .format(round(timefacefeat,2), round(timefacematch,2),round(end-start,2)).split("\n"))

    write_output_file(output_pairs, os.path.join(output_paths,"output_pairs_distances.txt"))
    write_output_file(timepairs, os.path.join(output_paths,"output_pairs_timings.txt"))

    print('Program executed on {} pairs took {} seconds'.format(len(entries),round(end-start,2)))
    
def runOnetoN(input_paths, text_path, repeat_pairs, output_paths):
    start=time.perf_counter()

    if not os.path.isdir(input_paths):
        print('Directory path error!!')
        sys.exit()
        
    if not os.path.isdir(output_paths):
        os.makedirs(output_paths)
        print(f"output_directory_path created sucessfully.!!")
    else:
        print(f"output_directory_path already created.")

    entries = open(os.path.join(text_path,"reference_set.txt"),"r").readlines()
    print(f"the len of reference set is :: {len(entries)}")

    if repeat_pairs is not None:
        entries = entries[:int(repeat_pairs)]

    print('No. of Images in Reference set:',len(entries))

    start=time.perf_counter()
    enrolled_path = app_params['enroll_image_folder_name']

    print(f"inside.......OneToN.......enrolled path :: {enrolled_path}")
    print(f"inside.......OneToN....input_paths :: {input_paths}")
    search_path = app_params['search_image_folder_name']
    invalid, nofaces, multifaces, valid, timefacefet, img_ids, img_features, timefacedet, face_rot = get_Face_Reco_Embeddings_and_Class(entries,input_paths + '/' + enrolled_path)
    end = time.perf_counter()
    
    #sys.exit()
    
    img_features_1 = np.array(img_features, dtype="float32")
    write_output_file(valid, f'{output_paths}labels.txt')
    write_pickle_file(img_features_1, f'{output_paths}embeddings.vec')
    print(f"the img_features_1.shape is :: {img_features_1.shape}")
    timepairs = list("Time for face detection: {0}\nTime for Whole Program: {1}\nTime for feature ingestion: {2}"\
                        .format(round(timefacedet,2), round(end-start,2), round(timefacefet, 2)).split("\n"))

    write_output_file(timepairs, os.path.join(output_paths,"output_reference_timings.txt"))
    if len(invalid) > 0:
        write_output_file(invalid, os.path.join(output_paths,"reference_set_invalid.txt"))
    if len(nofaces) > 0:
        write_output_file(nofaces, os.path.join(output_paths,"reference_set_noface.txt"))
    if len(multifaces) > 0:
        write_output_file(multifaces, os.path.join(output_paths,"reference_set_multifaces.txt"))
    if len(face_rot) > 0:
        write_output_file(face_rot, os.path.join(output_paths,"reference_set_rotated.txt"))

    print('Reference set executed on {} images took {} seconds'.format(len(entries),round(end-start,2)))

    start=time.perf_counter()
        
    with open(os.path.join(text_path,"query_set.txt"), 'r') as files1:
        entries = []
        # the .readlines() function uses.....!! \n in the list which we do not want
        # so we are using the list comprehension to get the list of labels and we are using rstrip function to 
        # remove the \n from the lines, that are stored in .txt file.
        for entry in files1:
            entries.append(input_paths + '/' + search_path + '/' + entry.rstrip())
    # entries = [entry.rstrip() for entry in file_open]
    print('No. of Images in Query set:',len(entries))

    startQuery=time.perf_counter()
    avgQueryTime, invalid, noface, multifaces, rotated = run_Query_set(entries,  os.path.join(output_paths, "1_to_N_results.txt"))
    endQuery=time.perf_counter()
    
    end = time.perf_counter()

    timepairs = list("Time for query output: {0}\nAvg Time for Single query: {1}\nTime for Whole Program: {2}"\
                        .format(round(endQuery - startQuery,2), round(avgQueryTime,6), round(end-start,2)).split("\n"))

    write_output_file(timepairs, os.path.join(output_paths,"output_query_timings.txt"))

    if len(invalid) > 0:
        print(f"the invalid list after query set  :: {len(invalid)}")
        write_output_file(invalid, os.path.join(output_paths,"query_set_invalid.txt"))
    if len(noface) > 0:
        write_output_file(nofaces, os.path.join(output_paths,"query_set_noface.txt"))
    if len(multifaces) > 0:
        write_output_file(multifaces, os.path.join(output_paths,"query_set_multifaces.txt"))
    if len(rotated) > 0:
        write_output_file(multifaces, os.path.join(output_paths,"query_set_rotated.txt"))
        
    end=time.perf_counter()
    print('Query set executed on {} images took {} seconds'.format(len(entries),round(end-start,2)))
    

#  def main():

    
#      args = vars(ap.parse_args())
#      repeat_pairs = args["repeat_pairs"]
# #     # match = args["match"]
# #     # text_path = args["text_file_path"]
# #     # input_paths = args["input_directory_path"]
# #     # output_paths = args["output_directory_path"]
#      #repeat_pairs = app_params["repeat_pairs"]
#      match = app_params["match"]
#      text_path = app_params["text_file_path"]
#      input_paths = app_params["input_directory_path"]
#      output_paths = app_params["output_directory_path"]

#      print(match)
#      print(repeat_pairs)

#      sys.stdout.flush()

#      if match == 'p':
#          runOnetoOne(input_paths, text_path, repeat_pairs, output_paths)
        
#      if match == "rq":
#          runOnetoN(input_paths, text_path, repeat_pairs, output_paths)
    
#  if __name__ == '__main__':
#      main()

