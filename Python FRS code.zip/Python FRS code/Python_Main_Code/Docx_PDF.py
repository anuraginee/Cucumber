from docx import Document
from docx.shared import Inches
from pathlib import Path
from PIL import Image
import pandas as pd
from PIL import Image, UnidentifiedImageError
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH


def read_csv_and_filter(csv_file_path):
    df = pd.read_csv(csv_file_path)
    image_paths = []
    Remarks = []
    Image_Match_Count = []
    for index, row in df.iterrows():
        image_match_count = row['Image_match_Count']
        image_path = row['Image_Path_x']
        Remark = row['Remarks']
        if image_match_count < 5:
            image_paths.append(image_path)
            Remarks.append(Remark)
            Image_Match_Count.append(image_match_count)
    
    return image_paths, Remarks, Image_Match_Count

def image_to_jpg(image_path):
    print(f"Image_Paths::::::::::::: {image_path}")
    path = Path(image_path)
    if path.suffix not in {'.jpg', '.png', '.jfif', '.exif', '.gif', '.tiff', '.bmp'}:
        jpg_image_path = f'{path.parent / path.stem}_result.jpg'
        Image.open(image_path).convert('RGB').save(jpg_image_path)
        return jpg_image_path
    return image_path

def generate_docx_with_images(List_Image_Paths,Remarks,Image_Match_Count,output_file):
    doc = Document()
    title = doc.add_heading('Probe Image data set with Remarks', level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph = doc.add_paragraph('')
    run_value = paragraph.add_run("Probe Image data set with Image match count(top_k=5) Less than 5")
    # bold_format = run.font
    run_value.bold = True
    run_value.underline = True
    run_value.italic = True
    for image_path,Remarks,Image_Match_Count in zip(List_Image_Paths,Remarks,Image_Match_Count):
        try:
            # Add the image to the document
            # img = Image.open(image_paths)
            # img_width, img_height = img.size
            # max_width = Inches(10)  # Maximum width for the image
            # if img_width > max_width:
            #     img_width, img_height = max_width, max_width * img_height / img_width
            Image_Name = image_path.strip().split("\\")[-1]
            paragraph = doc.add_paragraph('Image Name ----> ')
            run = paragraph.add_run(Image_Name)
            # bold_format = run.font
            run.bold = True
            run.underline = True
            # run.italic = True
            doc.add_picture(image_path, width=Inches(4), height=Inches(3))
            doc.add_paragraph(f'**Remarks:- {Remarks} \n')
            doc.add_paragraph(f' Image_Match_Count ----------> {Image_Match_Count} \n')
            print(f'Image added successfully into PDF file ----------> {Image_Name} \n')
            doc.save(output_file)


        except UnidentifiedImageError:
            print(f"Error: UnrecognizedImageError occurred for '{image_path}'. Skipping this image. \n")
            
        except Exception as e:
            print(f"Error: An unexpected error occurred for '{image_path}': {str(e)} \n")

if __name__ == "__main__":
    csv_file_path = 'C:\\Users\\pratik\\Desktop\\FRS_Python_Code\\One_N_Output_File_Path\\Reports\\One_N_Final_Report.csv'
    output_file = 'C:\\Users\\pratik\\Desktop\\FRS_Python_Code\\One_N_Output_File_Path\\Reports\\Images_Reference_4_PDF.docx'
    filtered_image_paths,Remarks,Image_Match_Count = read_csv_and_filter(csv_file_path)
    print(f'Length of filtered_image_paths:::::::::: {len(filtered_image_paths)}')
    print(f'filtered_image_paths:::::::::: {filtered_image_paths}')
    # print(f'Remarks list :::::::::::: {Remarks}')
    # Converted_Image = image_to_jpg(Image_path)    
    generate_docx_with_images(filtered_image_paths,Remarks,Image_Match_Count,output_file)
    print("Output File generated Successfully!!")