# Name : Gandiva UI Automation Framework
## Authors and acknowledgment
#### Author : Prashant Deshmukh (QA Lead)
#### Contributors : Anuraginee B , Somnath J
#### Special Thanks to : Shiva K , Shailendra H, Swati Maam

## Description
Gandiva UI Automation framework is Build using following tols:
Java, Sel
enium, Selenide, Cucumber , Maven , Jenkins, Page Object Model,
Gherkin ,gitlab , Excel and chrome browser.

## Integrate with your tools
we have integrated the Project with Jenkins .
user will be able to  run the Test as per the Suite he selects.
the suite name parameter is sent to the command line in the form of cucumber tags.
Refer configuration of job :
http://192.168.181.34:8080/view/Gandiva_Automation/job/gandiva_UIAutomation

## Coding Guidelines for QA :
1. Never use Thread.sleep Instead use Should(Condition.enabled/appears) from selenide or you can increase or decrease the Configuration.Timeout
2. For every Scenario you should have a then clause which implements at leaset one Assertion
3. The Test scenarios that are not complete yet can be marked as @disabled
4. Every Feature file should have (Author:    Dated :   Total Scenarios :   Automated :)
5. For highlighting any Element to see if it is getting identified you can use Highlighter
   highlight(SelenideElement.should(appear));
   or highlight(SelenideElement,String color) ;
6. 

## How To
1. Take ScreenShot :
   Usage :
   import static steps.CommonStepDef.TakeScreenshot;
   TakeScreenshot();
2. Take ElementScreenShot :
   Usage :
   import static steps.CommonStepDef.ElementScreenshot;
   ElementScreenshot(SelenideElement);
3. Writing into Cucumber Step the Logs
   Usage :
   // Use Below lines of code for writing into the Cucumber StepDef File.
   // Example : scenario.log("Your Text here . . .");
   Scenario scenario;
   @Before
   public void beforeScenario(Scenario scenario) {
   this.scenario = scenario;
   }
   scenario.log("Case Name : " + Case_Name);
4. Run Only Smoke Test Scenarios:
   mvn clean test -Dcucumber.filter.tags=@smoke
5. Run Only regression Test Scenarios:
   mvn clean test -Dcucumber.filter.tags=@regression


## Usage
mvn clean test -Dcucumber.filter.tags=<@TAG_NAME>

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin http://192.168.60.21/agency22/gandiva/gandiva-automation/gandiva.git
git branch -M main
git push -uf origin main
```


## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Automatically merge when pipeline succeeds](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)


## Support
Defect Tracker for Logging Defects related to Automation :
http://bugzilla.local/ you may need to have user and host file entry in the host file.

## References:
1. https://cucumber.io/docs/cucumber/
2. https://selenide.org/documentation.html
3. https://selenide.org/documentation/selenide-vs-selenium.html
4. https://www.miquido.com/blog/cucumber-features/
## Roadmap
Phase 1 :
Design and Implementation of Ui Automation Framework. 
Phase 2 :
Target to achieve at least smoke scenarios of Gandiva Ui Application.
Phase 3 : 
End to End Scenarios which will add Business value .
Phase 4 : 
Increase the number of End to End Scenario to increase coverage.



## License
Confidential and should not be used outside C-DAC.

## Project status
Automation In Progress.