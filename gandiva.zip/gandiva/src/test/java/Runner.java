/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 18-07-2023
*/

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty", "html:target/cucumber/reports.html", "json:target/cucumber/cucumber.json", "rerun:target/failedrerun.txt"},
        features = "src/test/resources/features/UAPortal",
        glue = "steps",
        tags = "@UA14",
        dryRun = false,
        snippets = CucumberOptions.SnippetType.CAMELCASE)
public class Runner{
}
