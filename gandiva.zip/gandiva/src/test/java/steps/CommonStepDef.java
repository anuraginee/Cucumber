/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.springframework.beans.factory.annotation.Autowired;
import utils.ScenarioContext;

import java.io.File;
import java.io.IOException;

import static com.codeborne.selenide.Selenide.actions;

/**
 * Common Step definitions for Some of the common things
 * for e.g Takescreenshot e.t.c
 */
@ExtendWith({ScreenShooterExtension.class})
public class CommonStepDef {

    @Autowired
    private CommonElements CommonElements;

    @Autowired
    private UA_dashboard ua_dashboard;

    public static String portalName;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    static Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext sc = new ScenarioContext();

    /**
     * Method to Take ScreenShot.
     */
    public static void TakeScreenshot() {
        TakesScreenshot ts = (TakesScreenshot) WebDriverRunner.getWebDriver();
        byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
        scenario.attach(screenshot, "image/png", scenario.getName());
    }

    /**
     * Method to Take Element ScreenShot.
     *
     * @param element SelenideElement
     */
    public static void ElementScreenshot(SelenideElement element) {
        byte[] srcFile = element.getScreenshotAs(OutputType.BYTES);
        scenario.attach(srcFile, "image/png", scenario.getName());
    }

}//class



