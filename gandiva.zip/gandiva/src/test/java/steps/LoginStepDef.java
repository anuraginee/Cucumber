/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps;

import PageObject.AdminPortal.AdminLoginPage;
import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.PushNotifications.PushNotifications;

import static com.codeborne.selenide.Selenide.executeJavaScript;

import PageObject.Common.CommonElements;
import PageObject.Common.ProfileUpdate;
import PageObject.POPortal.POLoginPage;
import PageObject.POPortal.PO_dashboard;
import PageObject.UserAgentPortal.UALoginPage;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import utils.*;
import utils.Context.Context;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;
import static utils.RandomUtils.getVerificationCode;
import static utils.WebDriverFactory.FirstTimeLogin;

@ExtendWith({ScreenShooterExtension.class})

public class LoginStepDef {
    public static String apiEndPointUri;
    public static String CONTENT_TYPE;
    public static String STATUS_CODE;
    public static Response response;
    @Autowired
    private UALoginPage uaLoginPage;
    @Autowired
    private AdminLoginPage adminLoginPage;
    @Autowired
    private POLoginPage poLoginPage;
    @Autowired
    private UA_dashboard ua_dashboard;
    @Autowired
    private PO_dashboard po_dashboard;
    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private PushNotifications pushNotifications;

    @Autowired
    private ProfileUpdate profileUpdate;
    @Autowired
    private CommonElements commonElements;
    public static String verificationCode;
    Boolean codeFound = false;
    public static String portalName;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext sc = new ScenarioContext();

    @BeforeEach
    public void Open(String portal) {
        this.portalName = portal;
        if (portal.equals("ADMIN")) {
            adminLoginPage = open(PropertyUtils.getAdminPortalBaseUrl(), AdminLoginPage.class);
        }
        if (portal.equals("UA")) {
            uaLoginPage = open(PropertyUtils.getUAPortalBaseUrl(), UALoginPage.class);
        }
        if (portal.equals("PO")) {
            poLoginPage = open(PropertyUtils.getPOPortalBaseUrl(), POLoginPage.class);
        }
        WebDriverRunner.getWebDriver().manage().window().maximize();
    }

    @Given("user opens the {string} portal and logins with username {string} and password {string}")
    public void userLogins(String portalname, String username, String password) throws InterruptedException {
        // Check if Already login
        if (FirstTimeLogin == true) {
            // Logout
            System.out.println("Login -> FirstTimeLogin is :" + FirstTimeLogin.toString());
            logout(portalname);
            WebDriverFactory.closeWebDriverInstance();
            adminLoginPage = null;
            uaLoginPage = null;
            poLoginPage = null;
//            WebDriverFactory.quitWebDriverInstance();
        }
        Open(portalname);
        theUserEntersTheUserPass(username, password);
    }

    @Then("user validates the notification for every user on UserPortal with User and UsersPassword")
    public void validateNotification(DataTable dataTable) throws InterruptedException {

        List<Map<String, String>> listdata = dataTable.asMaps(String.class, String.class);


        for (int i = 0; i <= listdata.size(); i++) {
            System.out.println("Username :" + listdata.get(i).get("User"));
            System.out.println("Password :" + listdata.get(i).get("UsersPassword"));

            Open("UA");
            theUserEntersTheUserPass(listdata.get(i).get("User"), listdata.get(i).get("UsersPassword"));

            String notification_Content = sc.getContext(Context.NOTIFICATION_CONTENT).toString();
            System.out.println("NOT : " + notification_Content);

            pushNotifications.uaNotificationIcon.click();
            // get 1st element
            String first_Notification = pushNotifications.firstNotification.getText();
            ElementScreenshot(pushNotifications.firstNotification);
            System.out.println(first_Notification);
            Assert.assertTrue(first_Notification.contains(notification_Content));


        }

    }   // UA portal notification
    // Need to implement PO portal notification

    @And("Nodal will login to {string} with username {string} and password {string}")
    public void nodalLogin(String PortalName, String Nodal, String NodalPassword) throws InterruptedException {

        Open(PortalName);
        theUserEntersTheUserPass(Nodal, NodalPassword);
    }

/*
 Scenarios handled by "user logout from portal {string}" are:
    * If user wants to log in into Admin, then Logout --> UA
     * If user wants to log in into UA, then Logout --> ADMIN
 */

    @And("user logout from portal {string}")
    public void logout(String portalName) throws InterruptedException {
        executeJavaScript("arguments[0].click();", profileUpdate.officerName.shouldBe(Condition.visible));
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", profileUpdate.LogOut);

        FirstTimeLogin = false;
        System.out.println("logout -> FirstTimeLogin is :" + FirstTimeLogin.toString());
    }


    //    @When("the user enters username {string} and password {string}")
    public void theUserEntersTheUserPass(String username, String password) throws InterruptedException {
        if (!(adminLoginPage == null)) {
            // admin login page is present.
            adminLoginPage.usernameField.sendKeys(PropertyUtils.getPropString(username));
            adminLoginPage.passwordField.sendKeys(PropertyUtils.getPassword());

            String Admin_captchaTxt = adminLoginPage.adminCaptchaField.getText();
            RandomUtils.sendHumanKeys(adminLoginPage.adminCaptchaTextField, Admin_captchaTxt);
            //  adminLoginPage.adminCaptchaTextField.should(visible).sendKeys(Admin_captchaTxt);

            if (adminLoginPage.loginButton.isEnabled()) {
                // Get the Network Logs Response
                WebDriver driver = WebDriverRunner.getWebDriver();
                adminLoginPage.adminLogin();
                adminLoginPage.verificationCodeTextField.should(appear);// Wait for the Verification Text field to come so that you get the latest Token.

                verificationCode = getVerificationCode(portalName, PropertyUtils.getPropString(username), PropertyUtils.getPassword());
                if (!(verificationCode.equalsIgnoreCase(""))) {
                    codeFound = true;
                } else {
                    codeFound = false;
                }
                // Login with Verification Code
                if (codeFound == true) {

                    adminLoginPage.verificationCodeTextField.sendKeys(verificationCode.toString());
                    verificationCode = "";
                    adminLoginPage.loginButton.should(Condition.enabled).click();
                    codeFound = false;
                }//if
            }//if
        } //if adminLoginPage
        else if (!(uaLoginPage == null)) {
            // ua login page is present.

            WebDriver driver = WebDriverRunner.getWebDriver();
            new WebDriverWait(driver, Duration.ofMinutes(3)).until(
                    webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));

            $(By.xpath("//div[contains(@class,'rounded')]")).shouldBe(visible, Duration.ofMinutes(3));
            if ($(By.xpath("//div[contains(@class,'rounded')]")).isDisplayed()) {
                if (uaLoginPage.Attention_heading.isDisplayed()) {
                    uaLoginPage.Attention_heading.shouldBe(visible, Duration.ofMinutes(3));
                    highlight(uaLoginPage.Ok_Button, "Green");
                    executeJavaScript("arguments[0].click();", uaLoginPage.Ok_Button.shouldBe(enabled));
                }
            }
            Thread.sleep(5000);
            uaLoginPage.UA_Portal_Page_Image.shouldBe(visible, Duration.ofMinutes(3));
            uaLoginPage.usernameField.sendKeys(PropertyUtils.getPropString(username));
            uaLoginPage.passwordField.sendKeys(PropertyUtils.getPassword());
            String ua_captcha_txt = uaLoginPage.uaCaptchaField.getText();
            uaLoginPage.uaCaptchaTextField.sendKeys(ua_captcha_txt);
            if (uaLoginPage.signInButton.isEnabled()) {
                highlight(uaLoginPage.signInButton, "Green");
                executeJavaScript("arguments[0].click();", uaLoginPage.signInButton);
//                uaLoginPage.signInButton.click();
                Thread.sleep(3000);
                uaLoginPage.verificationCodeTextField.should(appear);// Wait for the Verification Text field to come so that you get the latest Token.
                verificationCode = getVerificationCode(portalName, PropertyUtils.getPropString(username), PropertyUtils.getPassword());
                if (!(verificationCode.equalsIgnoreCase(""))) {
                    codeFound = true;
                } else {
                    codeFound = false;
                }
                // Login with Verification Code
                if (codeFound == true) {
                    uaLoginPage.Disclaimer.should(visible);
                    uaLoginPage.Agree_checkbox.click();
                    uaLoginPage.verificationCodeTextField.sendKeys(verificationCode.toString());
                    verificationCode = "";
                    uaLoginPage.loginButton.should(Condition.enabled).click();
//                    Thread.sleep(3000);
//                    uaLoginPage.loginButton.should(Condition.enabled).click();
                    codeFound = false;
                }//if
            }//if
        }// if uaLoginPage
        else if (!(poLoginPage == null)) {
            // ua login page is present.
            poLoginPage.usernameField.sendKeys(PropertyUtils.getPropString(username));
            poLoginPage.passwordField.sendKeys(PropertyUtils.getPOPassword());
            String po_captcha_txt = uaLoginPage.uaCaptchaField.getText();
            poLoginPage.poCaptchaTextField.sendKeys(po_captcha_txt);// Wait for the Verification Text field to come so that you get the latest Token.
            if (poLoginPage.loginButton.isEnabled()) {
                // Get the Network Logs Response
                WebDriver driver = WebDriverRunner.getWebDriver();
                poLoginPage.poLogin();
                poLoginPage.verificationCodeTextField.should(appear);
                verificationCode = getVerificationCode(portalName, PropertyUtils.getPropString(username), PropertyUtils.getPOPassword());
                System.out.println("Verification Code : " + verificationCode);
                if (!(verificationCode.equalsIgnoreCase(""))) {
                    codeFound = true;
                } else {
                    codeFound = false;
                    // Put Assert to validate Key Clock Response . It does not give 200 ok Assert will Terminate the Step.
                }
                // Login with Verification Code
                if (codeFound == true) {

                    poLoginPage.verificationCodeTextField.sendKeys(verificationCode.toString());
                    verificationCode = "";
                    poLoginPage.loginButton.should(Condition.enabled).click();
                    codeFound = false;
                }//if
            }//if
        }// poLoginPage

    }//method

    @Then("User should get logged in to the application successfully and lands on {string} dashboard page")
    public void theUserShouldTheDashboardPage(String portalName) throws InterruptedException {
        if (portalName.equalsIgnoreCase("ADMIN")) {
            admin_dashboard.bar_dashboard.should(appear, Duration.ofMinutes(1));
            Assert.assertTrue(admin_dashboard.bar_dashboard.isDisplayed());
            FirstTimeLogin = true;
            System.out.println("Admin Dashboard FirstTimeLogin is :" + FirstTimeLogin.toString());
            commonElements.Vertical_Loader.shouldNotBe(visible);
        }//if
        if (portalName.equalsIgnoreCase("UA")) {

            WebDriver driver = WebDriverRunner.getWebDriver();
            new WebDriverWait(driver, Duration.ofMinutes(10)).until(
                    webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));

            ua_dashboard.bar_dashboard.should(appear, Duration.ofMinutes(1));
            Thread.sleep(5000);
            Assert.assertTrue(ua_dashboard.bar_dashboard.isDisplayed());
            if (ua_dashboard.Notification_Window.isDisplayed()) {
                ua_dashboard.Notification_Window_Close.shouldBe(Condition.visible).click();
            }//if

            FirstTimeLogin = true;
//            refresh();
//            ua_dashboard.bar_dashboard.should(appear, Duration.ofMinutes(1));
//            Thread.sleep(3000);
            System.out.println("Dashboard -> FirstTimeLogin is :" + FirstTimeLogin.toString());
            commonElements.Vertical_Loader.shouldNotBe(visible);
        }//if
        if (portalName.equalsIgnoreCase("PO")) {
            po_dashboard.Dashboard.should(appear, Duration.ofMinutes(1));
            Assert.assertTrue(po_dashboard.Dashboard.isDisplayed());
            commonElements.Vertical_Loader.shouldNotBe(visible);
//            FirstTimeLogin = true;
//            System.out.println("FirstTimeLogin is :" + FirstTimeLogin.toString());
        }//if


    }//method

    @Given("{string} login to the Application")
    public void UserLogin(String username) throws InterruptedException {
        if (username.equalsIgnoreCase("Natgrid_Admin_Officer")) {
            // Check if Already login
            if (FirstTimeLogin == true) {
                // Logout
                System.out.println("Login -> FirstTimeLogin is :" + FirstTimeLogin.toString());
                logout("ADMIN");
                WebDriverFactory.closeWebDriverInstance();
                adminLoginPage = null;
                uaLoginPage = null;
                poLoginPage = null;
//            WebDriverFactory.quitWebDriverInstance();
            }
            Open("ADMIN");
            theUserEntersTheUserPass(username, PropertyUtils.getPassword());
        } else if (username.equalsIgnoreCase("PO_Nodal_Officer")) {
            // Check if Already login
            if (FirstTimeLogin == true) {
                // Logout
                System.out.println("Login -> FirstTimeLogin is :" + FirstTimeLogin.toString());
                logout("PO");
                WebDriverFactory.closeWebDriverInstance();
                adminLoginPage = null;
                uaLoginPage = null;
                poLoginPage = null;
//            WebDriverFactory.quitWebDriverInstance();
            }
            Open("PO");
            theUserEntersTheUserPass(username, PropertyUtils.getPassword());
        } else {
            // Check if Already login
            if (FirstTimeLogin == true) {
                // Logout
                System.out.println("Login -> FirstTimeLogin is :" + FirstTimeLogin.toString());
                logout("UA");
                WebDriverFactory.closeWebDriverInstance();
                adminLoginPage = null;
                uaLoginPage = null;
                poLoginPage = null;
//            WebDriverFactory.quitWebDriverInstance();
            }
            Open("UA");
            theUserEntersTheUserPass(username, PropertyUtils.getPassword());

        }
    }


    public void LoginWithTempCredentials(String loginID, String password) throws InterruptedException {

        if (!(uaLoginPage == null)) {
            // ua login page is present.
            if ($(By.xpath("//div[contains(@class,'rounded')]")).isDisplayed()) {
                uaLoginPage.Attention_heading.shouldBe(visible);
                uaLoginPage.Ok_Button.shouldBe(enabled).click();
                Thread.sleep(2000);
            }
            uaLoginPage.usernameField.sendKeys(loginID);
            uaLoginPage.passwordField.sendKeys(password);
            String ua_captcha_txt = uaLoginPage.uaCaptchaField.getText();
            uaLoginPage.uaCaptchaTextField.sendKeys(ua_captcha_txt);
            if (uaLoginPage.signInButton.isEnabled()) {
                // Get the Network Logs Response
                WebDriver driver = WebDriverRunner.getWebDriver();
                uaLoginPage.uaLogin();
                uaLoginPage.verificationCodeTextField.should(appear);// Wait for the Verification Text field to come so that you get the latest Token.
                verificationCode = getVerificationCode(portalName, loginID, password);
                if (!(verificationCode.equalsIgnoreCase(""))) {
                    codeFound = true;
                } else {
                    codeFound = false;
                }
                // Login with Verification Code
                if (codeFound == true) {
                    uaLoginPage.Disclaimer.should(visible);
                    uaLoginPage.Agree_checkbox.click();
                    uaLoginPage.verificationCodeTextField.sendKeys(verificationCode.toString());
                    verificationCode = "";
                    uaLoginPage.loginButton.should(Condition.enabled).click();
                    codeFound = false;
                }//if
            }//if
        }// if uaLoginPage

    }

}//Class


