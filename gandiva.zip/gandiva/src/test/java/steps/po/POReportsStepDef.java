package steps.po;

import PageObject.POPortal.POReports;
import com.codeborne.selenide.Condition;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.TakeScreenshot;

public class POReportsStepDef {


@Autowired
private POReports poReports;



    @Then("user loads report with default values on PO")
    public void userLoadsReportWithDefaultValuesPO() throws InterruptedException {
       // poReports.submitBtn.should(Condition.appear).click();
        executeJavaScript("arguments[0].click();",poReports.SubmitBtn);
        Thread.sleep(2000);
        poReports.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible, Duration.ofMinutes(5));
        TakeScreenshot();

    }


    @Then("user loads error report with default values on PO")
    public void userLoadsErrorReportWithDefaultValuesPO() throws InterruptedException {
        // poReports.submitBtn.should(Condition.appear).click();
        executeJavaScript("arguments[0].click();",poReports.errorSubmitBtn);
        Thread.sleep(2000);
        poReports.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible, Duration.ofMinutes(5));
        TakeScreenshot();

    }


}
