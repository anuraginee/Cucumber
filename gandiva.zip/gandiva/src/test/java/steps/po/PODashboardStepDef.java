/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 25-08-2023
*/
package steps.po;

import PageObject.Common.CommonElements;
import PageObject.POPortal.PO_dashboard;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import utils.enums.DASHBOARD_WIDGETS;

import static com.codeborne.selenide.Selenide.executeJavaScript;


/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class PODashboardStepDef {
    @Autowired
    private PO_dashboard po_dashboard;

    @Autowired
    private UA_dashboard ua_dashboard;

    @Autowired
    private CommonElements commonElements;

    @When("user navigates to PO_Portal -> Dashboard")
    public void userNavigatesToPO_Dashboard() throws InterruptedException {
        Thread.sleep(3000);
        po_dashboard.Dashboard.should(Condition.enabled).click();
    }

    @When("user navigates to PO_Portal -> Request Response")
    public void userNavigatesToRequest_Response() {
        po_dashboard.Request_Response.should(Condition.enabled).click();
    }

    @When("user navigates to PO_Portal -> Request Response -> All Requests")
    public void userNavigatesToPO_All_Requests() {
        if (po_dashboard.All_Requests.isDisplayed()) {
            po_dashboard.All_Requests.should(Condition.enabled).click();
        } else {
            po_dashboard.Request_Response.should(Condition.enabled).click();
            po_dashboard.All_Requests.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Request Response -> Request Response Pending")
    public void userNavigatesToPO_Request_Response_Pending() {
        if (po_dashboard.Request_Response_Pending.isDisplayed()) {
            po_dashboard.Request_Response_Pending.should(Condition.enabled).click();
        } else {
            po_dashboard.Request_Response.should(Condition.enabled).click();
            po_dashboard.Request_Response_Pending.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Reports")
    public void userNavigatesToPO_Reports() {
        po_dashboard.Reports.should(Condition.enabled).click();
    }

    @When("user navigates to PO_Portal -> Reports -> UA Wise Requests")
    public void userNavigatesToPO_Reports_UAWiseRequests() {
        if (po_dashboard.Reports_UA_Wise_Requests.isDisplayed()) {
            po_dashboard.Reports_UA_Wise_Requests.should(Condition.enabled).click();
        } else {
            po_dashboard.Reports.should(Condition.enabled).click();
            po_dashboard.Reports_UA_Wise_Requests.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Reports -> UA Wise Response Summary")
    public void userNavigatesToPO_Reports_UAWiseResponseSummary() {
        if (po_dashboard.Reports_UA_Wise_Response_Summary.isDisplayed()) {
            po_dashboard.Reports_UA_Wise_Response_Summary.should(Condition.enabled).click();
        } else {
            po_dashboard.Reports.should(Condition.enabled).click();
            po_dashboard.Reports_UA_Wise_Response_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Reports -> Type of Requests")
    public void userNavigatesToPO_Reports_Type_of_Requests() {

        if (po_dashboard.Reports_Type_of_Requests.isDisplayed()) {
            po_dashboard.Reports_Type_of_Requests.should(Condition.enabled).click();
        } else {
            po_dashboard.Reports.should(Condition.enabled).click();
            po_dashboard.Reports_Type_of_Requests.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Reports -> Time Taken to Serve Requests")
    public void userNavigatesToPO_Reports_Time_Taken_to_Serve_Requests() {
        if (po_dashboard.Reports_Time_Taken_to_Serve_Requests.isDisplayed()) {
            po_dashboard.Reports_Time_Taken_to_Serve_Requests.should(Condition.enabled).click();
        } else {
            po_dashboard.Reports.should(Condition.enabled).click();
            po_dashboard.Reports_Time_Taken_to_Serve_Requests.should(Condition.enabled).click();
        }
    }

    @When("user navigates to PO_Portal -> Reports -> Error Report")
    public void userNavigatesToPO_ReportsErrorReport() {
        if (po_dashboard.Reports_Error_Report.isDisplayed()) {
            po_dashboard.Reports_Error_Report.should(Condition.enabled).click();
        } else {
            po_dashboard.Reports.should(Condition.enabled).click();
            po_dashboard.Reports_Error_Report.should(Condition.enabled).click();
        }
    }


    @When("PO officer clicks view all link on requests received widget")
    public void organizationsRequestsReceived() throws InterruptedException {

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Requests_Received.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Requests_Received.getWidgetName()));

        Thread.sleep(3000);
    }

    @When("PO officer clicks view all link on requests responded widget")
    public void organizationsRequestsResponded() throws InterruptedException {

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Requests_Responded.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Requests_Responded.getWidgetName()));
        Thread.sleep(3000);
    }

    @When("PO officer clicks view all link on pending requests widget")
    public void organizationsPendingRequests() throws InterruptedException {

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Pending_Requests.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Pending_Requests.getWidgetName()));
        Thread.sleep(3000);
    }


    @When("PO officer clicks view all link on error requests widget")
    public void organizationsErrorRequests() throws InterruptedException {

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Error_Requests.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Error_Requests.getWidgetName()));
        Thread.sleep(3000);
    }

}