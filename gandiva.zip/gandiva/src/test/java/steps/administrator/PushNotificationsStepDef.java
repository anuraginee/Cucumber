package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.PushNotifications.PushNotifications;
import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import gherkin.lexer.Th;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import static com.codeborne.selenide.Condition.appear;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.actions;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;

@ExtendWith({ScreenShooterExtension.class})
public class PushNotificationsStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private PushNotifications pushNotifications;

    @Autowired
    private UA_dashboard ua_dashboard;
    @Autowired
    private SelectDropDownValue selectDropDownValue;

    @Autowired
    private CommonElements commonElements;


    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext sc = new ScenarioContext();


    @And("User clicks on all NG IT users selects Notification mode {string} of notification")
    public void user_clicks_on_all_NG_IT_users_and_select_mode_of_notification(String NotificationMode) throws InterruptedException {

        highlight(pushNotifications.allNGITUsers.should(appear), "green").click();
        Thread.sleep(3000);
        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(NotificationMode).shouldBe(visible).click();



    }


    @And("User clicks on All Nodal Officers selects Notification mode {string} of notification")
    public void select_mode_of_notification(String NotificationMode) throws InterruptedException {

        highlight(pushNotifications.allNodalOfficers.should(appear), "green").click();
        Thread.sleep(3000);
        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(NotificationMode).shouldBe(visible).click();
    }

    @And("User clicks on specific Officers selects ua category {string}, user agency {string}, role {string}, Notification Mode {string}")
    public void Specific_user_select_mode_of_notification(String UACategory,String UserAgency,String Role, String Mode) throws InterruptedException {

        highlight(pushNotifications.RolesSpecificUA.should(appear), "green").click();
        Thread.sleep(3000);
        pushNotifications.UserAgencyCategory.click();
        pushNotifications.User_Agency_Category(UACategory).shouldBe(visible).click();
        pushNotifications.UserAgency.shouldBe(visible).click();
        pushNotifications.UserAgency.sendKeys(UserAgency);
        pushNotifications.Select_User_Agency(UserAgency).shouldBe(visible).click();

        pushNotifications.SelectRole.click();
        pushNotifications.Select_User_Role(Role).shouldBe(visible).click();
        Thread.sleep(1000);
//        actions().moveToElement(pushNotifications.notContent.shouldBe(visible)).click();
        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(Mode).shouldBe(visible).click();
        highlight(pushNotifications.Start_Date_calender.shouldBe(Condition.visible), "green");
        executeJavaScript("arguments[0].click();", pushNotifications.Start_Date_calender.shouldBe(visible));
        pushNotifications.currentDate.click();
       // pushNotifications.SelectDate("10", "JUN", "2024");
        pushNotifications.fromTime.setValue("0000");
        pushNotifications.toTime.setValue("0600");
        pushNotifications.send.should(appear).click();
    }

    @And("Select the Notification Mode {string} , the notification content, config type {string} and click on send button")
    public void Sendnotification(String NotificationMode, String ConfigType) throws InterruptedException {
        String Content = "UA Portal is under maintenance" + RandomUtils.generateUniqueAlphabetName();

        Thread.sleep(3000);

        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(NotificationMode).shouldBe(visible).click();
        pushNotifications.Not_Content_Field.click();

        pushNotifications.Not_Content_Field.sendKeys(Content);
        pushNotifications.configType.click();
        pushNotifications.Configuration(ConfigType).shouldBe(visible).click();


        if (ConfigType.equalsIgnoreCase("Date Range")) {
            highlight(pushNotifications.Start_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.Start_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
          //  pushNotifications.SelectDate("11", "JUN", "2024");
            highlight(pushNotifications.End_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.End_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
          //  pushNotifications.SelectDate("11", "JUN", "2024");

            TakeScreenshot();

            executeJavaScript("arguments[0].click();", pushNotifications.send.should(appear));
        }
        // Validate created notification.
        sc.setContext(Context.NOTIFICATION_CONTENT, Content);
    }


    @And("Enter the notification content for nodal, config type {string} and click on send button")
    public void nodalSendnotification(String ConfigType) throws InterruptedException {
        String Content = "UA Portal is under maintenance" + RandomUtils.generateUniqueAlphabetName();
        pushNotifications.nodalNotContent.should(appear).setValue(Content);
        pushNotifications.nodalConfigType.click();
        selectDropDownValue.toSelectDropDown(pushNotifications.configList, ConfigType);
        if (ConfigType.equalsIgnoreCase("Date Range")) {

            pushNotifications.calendarIcon.should(Condition.visible).click();
            pushNotifications.currentDate.click();
            pushNotifications.calendarIcontodate.should(Condition.visible).click();
            pushNotifications.currentDate.click();
            pushNotifications.send.should(appear).click();

        } else {
            pushNotifications.send.should(appear).click();
        }
        // Validate created notification.
        sc.setContext(Context.NOTIFICATION_CONTENT, Content);
    }

    @And("user clicks on All Nodal Officers and select {string} of notification")
    public void user_clicks_on_All_Nodal_Officers_and_select_of_notification(String Mode) {

        pushNotifications.allNGITUsers.click();
        pushNotifications.notificationMode.setValue(Mode);
        pushNotifications.smsDropdown.click();

    }

    @Then("Admin user should get success message stating notification created successfully")
    public void notificationCreatedSuccessfully() {

        String successToastMessage = pushNotifications.toastMessage.getText();
        ElementScreenshot(pushNotifications.toastMessage);
        Assert.assertEquals("Notification Created successfuly", successToastMessage);

    }

    @Then("Admin user should get success message stating notification created successfully for all nodal")
    public void notificationCreatedSuccessfullyforAllNodal() {

        String successToastMessage = pushNotifications.toastMessage.getText();
        ElementScreenshot(pushNotifications.toastMessage);
        Assert.assertEquals("Notification Created successfuly", successToastMessage);

    }


    @And("User clicks on All Nodal Officers and Select the Notification Mode {string} , the notification content, config type {string} and click on send button")
    public void allNodalofficers(String Mode, String AgencyType) throws InterruptedException {

        highlight(pushNotifications.allNodalOfficers.should(appear), "green").click();

        String Content = "UA Portal is under maintenance" + RandomUtils.generateUniqueAlphabetName();

        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(Mode).shouldBe(visible).click();
        pushNotifications.Not_Content_Field_Nodal.click();

        pushNotifications.Not_Content_Field_Nodal.sendKeys(Content);
        pushNotifications.configType_Nodal.click();
        pushNotifications.Configuration(AgencyType).shouldBe(visible).click();


        if (AgencyType.equalsIgnoreCase("Date Range")) {
            highlight(pushNotifications.Start_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.Start_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
         //   pushNotifications.SelectDate("11", "JUN", "2024");
            highlight(pushNotifications.End_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.End_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
          //  pushNotifications.SelectDate("11", "JUN", "2024");

            TakeScreenshot();

            executeJavaScript("arguments[0].click();", pushNotifications.send.should(appear));
        } else {
            pushNotifications.send.should(appear).click();
        }
        // Validate created notification.
        sc.setContext(Context.NOTIFICATION_CONTENT, Content);


//        selectDropDownValue.toSelectDropDown(pushNotifications.agencyList, AgencyType);
//        pushNotifications.nodalNotMode.click();
//        selectDropDownValue.toSelectDropDown(pushNotifications.modeList, Mode);

    }

    @And("User clicks on specific Officers selects ua category {string}, user agency {string}, role {string}, the Notification Mode {string} , notification content, config type {string} and click on send button")
    public void specificUsers(String UACategory, String UserAgency, String Role ,String Mode, String AgencyType) throws InterruptedException {
        String Content = "UA Portal is under maintenance" + RandomUtils.generateUniqueAlphabetName();
        pushNotifications.RolesSpecificUA.click();
        pushNotifications.UserAgencyCategory.click();
        pushNotifications.User_Agency_Category(UACategory).shouldBe(visible).click();
        pushNotifications.UserAgency.shouldBe(visible).click();
        pushNotifications.UserAgency.sendKeys(UserAgency);
        pushNotifications.Select_User_Agency(UserAgency).shouldBe(visible).click();

        pushNotifications.SelectRole.click();
        pushNotifications.Select_User_Role(Role).shouldBe(visible).click();
        Thread.sleep(1000);
        actions().moveToElement(pushNotifications.notContent.shouldBe(visible)).click();
        pushNotifications.notContent.should(appear).click();
        pushNotifications.Notification_Mode(Mode).shouldBe(visible).click();
        pushNotifications.Not_Content_Field_Specific.click();

        pushNotifications.Not_Content_Field_Specific.sendKeys(Content);
        pushNotifications.configType_Specific.click();
        pushNotifications.Configuration(AgencyType).shouldBe(visible).click();


        if (AgencyType.equalsIgnoreCase("Date Range")) {
            highlight(pushNotifications.Start_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.Start_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
          //  pushNotifications.SelectDate("11", "JUN", "2024");
            highlight(pushNotifications.End_Date_calender.shouldBe(Condition.visible), "green");
            executeJavaScript("arguments[0].click();", pushNotifications.End_Date_calender.shouldBe(visible));
            pushNotifications.currentDate.click();
          //  pushNotifications.SelectDate("11", "JUN", "2024");

            TakeScreenshot();

            executeJavaScript("arguments[0].click();", pushNotifications.send.should(appear));
        }

    }

    @And("Enter the notification content for specific officer, config type {string} and click on send button")

    public void specificUserNotification(String ConfigType) throws InterruptedException {

        String Content = "UA Portal is under maintenance" + RandomUtils.generateUniqueAlphabetName();
        pushNotifications.specificUserContent.should(appear).setValue(Content);
        pushNotifications.specificUserConfigType.click();
        selectDropDownValue.toSelectDropDown(pushNotifications.configList, ConfigType);
        if (ConfigType.equalsIgnoreCase("Date Range")) {

            pushNotifications.calendarIcon.should(Condition.visible).click();
            pushNotifications.currentDate.click();
            pushNotifications.calendarIcontodate.should(Condition.visible).click();
            pushNotifications.currentDate.click();
            pushNotifications.send.should(appear).click();

        } else {
            pushNotifications.send.should(appear).click();
        }

        // Validate created notification.
        sc.setContext(Context.NOTIFICATION_CONTENT, Content);
    }


    @And("Select date and time to send SMS notification")
    public void SelectDateAndTimeForAllUsers() {

        highlight(pushNotifications.Start_Date_calender.shouldBe(Condition.visible), "green");
        executeJavaScript("arguments[0].click();", pushNotifications.Start_Date_calender.shouldBe(visible));
        pushNotifications.currentDate.click();
      //  pushNotifications.SelectDate("10", "JUN", "2024");
        pushNotifications.fromTime.setValue("0000");
        pushNotifications.toTime.setValue("0600");
        pushNotifications.send.should(appear).click();
    }


    @And("Select date and time to send SMS notification for all nodal users")
    public void SelectDateAndTimeForAllNodalUsers() {

        pushNotifications.calendarIcon.should(Condition.visible).click();
        pushNotifications.currentDate.click();
        pushNotifications.fromTimeNodal.setValue("0000");
        pushNotifications.toTimeNodal.setValue("0600");
        pushNotifications.send.should(appear).click();

    }


    @And("Select date and time to send SMS notification for specific users")
    public void SelectDateAndTimeForSpecificUsers() {

        pushNotifications.calendarIcon.should(Condition.visible).click();
        pushNotifications.currentDate.click();
        pushNotifications.fromTimeSpecific.setValue("0000");
        pushNotifications.toTimeSpecific.setValue("0600");
        pushNotifications.send.should(appear).click();

    }


}
