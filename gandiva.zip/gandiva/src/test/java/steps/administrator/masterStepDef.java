/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.Masters.*;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.commands.TakeScreenshot;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.openqa.selenium.TakesScreenshot;
import org.springframework.beans.factory.annotation.Autowired;
import steps.CommonStepDef;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import javax.swing.plaf.PanelUI;

import static com.codeborne.selenide.Selenide.$;
import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class masterStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private Masters masters;

    @Autowired
    private ManageInputType manageInputType;

    @Autowired
    private FeedbackCategory feedbackcategory;

    @Autowired
    private RequestResponseType requestResponseType;

    @Autowired
    private ParameterValidation parameterValidation;

    @Autowired
    private SelectDropDownValue selectDropDwonValue;

    @Autowired
    private ManageTerminal manageTerminal;
    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;
    ScenarioContext scenarioContext = new ScenarioContext();
    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


    @When("user navigates to AdminPortal -> Masters -> Manage Input Type")
    public void userNavigatesToMasters_Manage_Input_Type() throws InterruptedException {
        if (masters.Manage_Input_Type.isDisplayed()) {
            masters.Manage_Input_Type.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Manage_Input_Type.should(Condition.enabled).click();
        }
        Thread.sleep(20000);
    }

    @When("user navigates to AdminPortal -> Masters -> Parameter Validation")
    public void userNavigatesToMasters_Parameter_Validation() {
        if (masters.Parameter_Validation.isDisplayed()) {
            masters.Parameter_Validation.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Parameter_Validation.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> PO API Configuration")
    public void userNavigatesToMasters_PO_API_Configuration() {
        if (masters.PO_API_Configuration.isDisplayed()) {
            masters.PO_API_Configuration.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.PO_API_Configuration.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> Request_Response Type")
    public void userNavigatesToMasters_Request_Response_Type() {
        if (masters.Request_Response_Type.isDisplayed()) {
            masters.Request_Response_Type.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Request_Response_Type.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> Notification Event")
    public void userNavigatesToMasters_Notification_Event() {
        if (masters.Notification_Event.isDisplayed()) {
            masters.Notification_Event.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Notification_Event.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> Notification Mode")
    public void userNavigatesToMasters_Notification_Mode() {
        if (masters.Notification_Mode.isDisplayed()) {
            masters.Notification_Mode.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Notification_Mode.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> Notification Recipient")
    public void userNavigatesToMasters_Notification_Recipient() {
        if (masters.Notification_Recipient.isDisplayed()) {
            masters.Notification_Recipient.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Notification_Recipient.should(Condition.enabled).click();
        }
    }


//    @When("user navigates to AdminPortal -> Masters -> Feedback Type")
//    public void userNavigatesToMasters_Feedback_Type() {
//        if (masters.Feedback_Type.isDisplayed()) {
//            masters.Feedback_Type.should(Condition.enabled).click();
//        } else {
//            admin_dashboard.masters.should(Condition.enabled).click();
//            masters.Feedback_Type.should(Condition.enabled).click();
//        }
//    }

    @When("user navigates to AdminPortal -> Masters -> Feedback Category")
    public void userNavigatesToMasters_Feedback_Category() {
        if (masters.Feedback_Category.isDisplayed()) {
            masters.Feedback_Category.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Feedback_Category.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Masters -> Feedback Sub Module")
    public void userNavigatesToMasters_Feedback_Sub_Module() {
        if (masters.Feedback_Sub_Module.isDisplayed()) {
            masters.Feedback_Sub_Module.should(Condition.enabled).click();
        } else {
            admin_dashboard.masters.should(Condition.enabled).click();
            masters.Feedback_Sub_Module.should(Condition.enabled).click();
        }
    }



    @Then("user should be able to add input type and user get appropriate message")
    public void user_should_be_able_to_add_and_should_able_to_search_existing_input_type() throws InterruptedException {
        String InputType = "Input "+ RandomUtils.generateOrgName();
//        manageInputType.searchInputType.setValue(InputType);
//
//        boolean found_y_n = false;
//        Thread.sleep(3000);
//        for (SelenideElement e : manageInputType.inputTypeList) {
//            System.out.println(e.getText());
//            if (e.getText().equalsIgnoreCase(InputType)) {
//                found_y_n = true;
//                break;
//            } else {
//                found_y_n = false;
//            }//else
//
//        }//for
//        // creation
//        if (!found_y_n) {
            manageInputType.addInputTypeBtn.click();
            manageInputType.inputType.setValue(InputType);
            manageInputType.submitInputType.click();
            String successToastMessage = manageInputType.ToastMessage.getText();
      //      Assert.assertEquals(successToastMessage, "Input Type Created Successfully");

    }

    @Then("user should be able to add val name, val error, val regex {string} should get appropriate message")
    public void AddParameterValidation(String ValRegex) throws InterruptedException {

        String ValidationName = "Parameter"+ RandomUtils.generateOrgName();
        String ValErrMsg = "Enter Valid Information "+ RandomUtils.generateOrgName();
//        parameterValidation.searchInputType.setValue(ValidationName);
//
//        boolean found_y_n = false;
//        Thread.sleep(3000);
//
//        for (SelenideElement e : ParameterValidation.parametersList) {
//            System.out.println(e.getText());
//            if (e.getText().equalsIgnoreCase(ValidationName)) {
//                found_y_n = true;
//                break;
//            } else {
//                found_y_n = false;
//            }//else
//
//        }//for
//        // creation
//        if (found_y_n) {
//
//            System.out.println("Parameter found");
//
//        } else {

            parameterValidation.addParameterValidation.shouldBe(Condition.visible).click();
            parameterValidation.validationName.setValue(ValidationName);
            parameterValidation.valiationErrMsg.setValue(ValErrMsg);
            parameterValidation.validationRegex.setValue(ValRegex);
            parameterValidation.valParamSubmit.shouldBe(Condition.appear).click();
            String successToastMessage = parameterValidation.ToastMessage.getText();
     //       Assert.assertEquals(successToastMessage, "Validations Created Successfully");
            ElementScreenshot(parameterValidation.ToastMessage);


    }

    @And("Add new Feedback Category and sub-category")
    public void addNewFeedbackCategory() {

        String FeedbackCategory = "Feedback"+ RandomUtils.generateOrgName();
        String FeedbackCatDes = "Feedback"+ RandomUtils.generateOrgName();
        String FeedbackSubCat = "Feedback"+ RandomUtils.generateOrgName();
        String FeedbackSubCatDes = "Feedback"+ RandomUtils.generateOrgName();

        feedbackcategory.FeedbackCategoryTitle.shouldBe(Condition.visible);
        feedbackcategory.Add_New_Feedback_Category.shouldBe(Condition.visible).click();
        feedbackcategory.New_Feedback_Category_Title.should(Condition.appear);
        feedbackcategory.CategoryName.sendKeys(FeedbackCategory);
        feedbackcategory.CategoryDescription.sendKeys(FeedbackCatDes);
        feedbackcategory.feedbackCatSubmit.should(Condition.enabled).click();
        feedbackcategory.feedbackSubCat.sendKeys(FeedbackSubCat);
        feedbackcategory.feedbackSubCatDes.sendKeys(FeedbackSubCatDes);
        feedbackcategory.feedbackSubCatSubmit.should(Condition.enabled).click();

        scenarioContext.setContext(Context.feedbackCategory, FeedbackCategory);
        scenarioContext.setContext(Context.feedbackCatDes,FeedbackCatDes);

    }

    @Then("Admin user should get success message after adding feedback category and sub-category")
    public void feedbackCategorySuccessMessage(){

        String successToastMessage = feedbackcategory.ToastMessage.getText();
        Assert.assertEquals(successToastMessage, "Feedback Category Created Successfully");
        ElementScreenshot(feedbackcategory.ToastMessage);


    }

    @Then("Verify that admin user should get success message after adding PO API Summary")
    public void apiSummaryCreatedSuccessfully(){

        String successToastMessage = feedbackcategory.ToastMessage.getText();
        ElementScreenshot(feedbackcategory.ToastMessage);
        Assert.assertEquals("API Summary Created Successfully",successToastMessage );


    }
    @Then("Verify that admin user should get success message after adding PO API Configuration")
    public void apiConfigurationCreatedSuccessfully(){

        String successToastMessage = feedbackcategory.ToastMessage.getText();
        ElementScreenshot(feedbackcategory.ToastMessage);
        Assert.assertEquals("API Configuration Created Successfully", successToastMessage);
    }

    @Then("Verify added feedback category on feedback category screen")
    public void verifyFeedbackCategoryOnScreen() throws InterruptedException {

        String feedbackCat = scenarioContext.getContext(Context.feedbackCategory).toString();
        String feedbackCatDes = scenarioContext.getContext(Context.feedbackCatDes).toString();

        RandomUtils.sendHumanKeys(feedbackcategory.feedbackSearch, feedbackCat);
        highlight(feedbackcategory.feedbackSearch,"green");
        Thread.sleep(3000);
        highlight($(By.xpath("//table[@id='table_hide']//tbody//tr[1]")),"green");
        CommonStepDef.TakeScreenshot();

    }

    @Then("user should be able to add ReqResp Type and user should get appropriate message")
    public void addRequestResponseType() throws InterruptedException {
        String ReqRespType = "ReqResp "+ RandomUtils.generateOrgName();
//        requestResponseType.searchInputType.setValue(ReqRespType);
//
//        boolean found_y_n = false;
//        Thread.sleep(3000);
//        int size = requestResponseType.reqResList.size();
//        if (size >= 1) {
//            found_y_n = true;
//
//        } else {
//            found_y_n = false;
//        }//else
////        for (SelenideElement e : requestResponseType.reqResList) {
////            System.out.println(e.getText());
////            if (e.getText().equalsIgnoreCase(ReqRespType)) {
////
////            }
////        }//for
//        // creation
//        if (found_y_n == Boolean.TRUE) {
            requestResponseType.addReqResButton.should(Condition.appear).click();
            requestResponseType.reqResName.setValue(ReqRespType);
            requestResponseType.reqResSubmit.should(Condition.appear).click();
            String successToastMessage = requestResponseType.ToastMessage.getText();
//            Assert.assertEquals("Request Response Type Created Successfully", successToastMessage);


    }

    @Then("user should be able to add uacategory {string}, useragency {string}, macaddress {string} and should able to search existing mac and user should get appropriate message")
    public void addmacaddress(String UACategory, String UserAgency, String MacAddress) throws InterruptedException {

        manageTerminal.searchInputType.setValue(MacAddress);
        Thread.sleep(3000);
        boolean found_y_n = false;

        for (SelenideElement e : manageTerminal.macIdList) {
            System.out.println(e.getText());
            if (e.getText().equalsIgnoreCase(MacAddress)) {
                found_y_n = true;
                break;
            } else {
                found_y_n = false;
            }//else

        }//for
        // creation
        if (!found_y_n) {

            manageTerminal.addManageTerminal.should(Condition.appear).click();
            manageTerminal.selectUaCategory.should(Condition.appear).click();
            Thread.sleep(3000);
            SelectDropDownValue.toSelectDropDown(manageTerminal.uaCategoryList,UACategory);
            manageTerminal.selectUA.should(Condition.appear).click();
            Thread.sleep(3000);
            SelectDropDownValue.toSelectDropDown(manageTerminal.uaList,UserAgency);
            highlight(manageTerminal.macAddress,"green").should(Condition.visible).click();
            manageTerminal.macAddress.setValue(MacAddress);
            Thread.sleep(3000);
            manageTerminal.manageFlag.click();
            SelectDropDownValue.toSelectDropDown(manageTerminal.manageFlagList,"true");
            manageTerminal.manageTerminalSubmit.click();
        }

    }
















}



