package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.manageTerminal.ManageTerminal;
import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.actions;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;

public class ManageTerminalStepDef {

@Autowired
private ManageTerminal manageTerminal;

@Autowired
private Admin_dashboard admin_dashboard;

    ScenarioContext scenarioContext = new ScenarioContext();


    @When("user navigates to AdminPortal -> Manage Terminal-Admin -> Approve Terminal")
    public void userNavigatesToMasters_Manage_Terminal_Approve_Terminal() {
        if (manageTerminal.approveTerminal.isDisplayed()) {
            manageTerminal.approveTerminal.should(Condition.enabled).click();
        } else {
            admin_dashboard.manageTerminalMenu.should(Condition.enabled).click();
            manageTerminal.approveTerminal.should(Condition.enabled).click();
        }
    }

        @When("user navigates to AdminPortal -> Manage Terminal-Admin -> Register Terminal")
        public void userNavigatesToMasters_Manage_Terminal_Register_Terminal() {
            if (manageTerminal.registerTerminal.isDisplayed()) {
                manageTerminal.registerTerminal.should(Condition.enabled).click();
            } else {
                admin_dashboard.manageTerminalMenu.should(Condition.enabled).click();
                manageTerminal.registerTerminal.should(Condition.enabled).click();
            }

        }

         @Then("user should be display existing terminal table")
         public void userShouldDisplayExistingTerminal(){
         manageTerminal.existingTerminal.should(Condition.visible).click();
         manageTerminal.terminalTable.should(Condition.visible);

        }


        @Then("Enter the required field information on add manage terminal screen")
        public void nodalEntersDetailsOnAddManageTerminalScreen(){

        String ipAddress = RandomUtils.generateRandomIPAddress();
        String macAddress = RandomUtils.generateRandomMACAddress();
        String officeLocation = "Office"+RandomUtils.generateUniqueAlphabetName();
        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();

       // manageTerminal.addManageTerminal.should(Condition.visible).click();
        executeJavaScript("arguments[0].click();",manageTerminal.addManageTerminal);
        manageTerminal.ipAddress.clear();
        manageTerminal.ipAddress.setValue(ipAddress);
        RandomUtils.sendHumanKeys(manageTerminal.macAddress,macAddress);
        manageTerminal.officeLocation.setValue(officeLocation);
        manageTerminal.remarksManageTerminal.setValue(Remarks);
       // manageTerminal.createbtn.should(Condition.enabled).click();
        executeJavaScript("arguments[0].click();",manageTerminal.createbtn);
        scenarioContext.setContext(Context.macAddress, macAddress);
        scenarioContext.setContext(Context.officeLocation, officeLocation);

        }

        @Then("Admin user approves the mac request")
        public void approveMacAddressRequest(){

          String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();
          String officeLocation = scenarioContext.getContext(Context.officeLocation).toString();
          manageTerminal.searchField.setValue(officeLocation);

          // manageTerminal.approveBtn.should(Condition.visible).click();
          executeJavaScript("arguments[0].click();",manageTerminal.approveBtn);
          manageTerminal.approvalRemark.setValue(Remarks);
          manageTerminal.yesBtn.should(Condition.enabled).click();
        }


        @And("Admin user should get success toast message after approving mac request")
        public void successMessageAfterMacApproval(){

            String successToastMessage = manageTerminal.ToastMessage.getText();
            ElementScreenshot(manageTerminal.ToastMessage);
            Assert.assertEquals("Terminal details Approved successfully.", successToastMessage);

        }


        @Then("Admin user rejects the mac request")
        public void rejectMacAddressRequest(){

        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();
        String officeLocation = scenarioContext.getContext(Context.officeLocation).toString();
        manageTerminal.searchField.setValue(officeLocation);
        executeJavaScript("arguments[0].click();",manageTerminal.rejectBtn);
        //manageTerminal.rejectBtn.should(Condition.visible).click();
        manageTerminal.approvalRemark.setValue(Remarks);
        manageTerminal.yesBtn.should(Condition.enabled).click();
    }


    @And("Admin user should get success toast message after rejecting mac request")
    public void successMessageAfterMacReject(){

        String successToastMessage = manageTerminal.ToastMessage.getText();
        ElementScreenshot(manageTerminal.ToastMessage);
        Assert.assertEquals("Terminal details Rejected successfully.", successToastMessage);

    }


    @Then("Admin user clicks on add terminal button and enter required details user agency category {string}, User Agency {string}")
    public void registerTerminal(String UACategory, String UserAgency) throws InterruptedException {

        String ipAddress = RandomUtils.generateRandomIPAddress();
        String macAddress = RandomUtils.generateRandomMACAddress();
        String officeLocation = "Office"+RandomUtils.generateUniqueAlphabetName();
        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();

        manageTerminal.addMangeTerminalAdmin.should(Condition.enabled).click();
       // manageTerminal.selectUACategory.click();
        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();",manageTerminal.selectUACategory);
        Thread.sleep(2000);
        SelectDropDownValue.toSelectDropDown(manageTerminal.elementList, UACategory);
       // manageTerminal.selectUA.click();
        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();",manageTerminal.selectUA);
        Thread.sleep(2000);
        SelectDropDownValue.toSelectDropDown(manageTerminal.elementList, UserAgency);
        manageTerminal.ipAddress.clear();
        manageTerminal.ipAddress.setValue(ipAddress);
        RandomUtils.sendHumanKeys(manageTerminal.macAddress,macAddress);
        manageTerminal.officeLocationAdmin.setValue(officeLocation);
        manageTerminal.remarksRegisterTerminal.setValue(Remarks);
        manageTerminal.submit.should(Condition.enabled).click();

    }

@And("Admin user should get success toast message after registration of mac request")
    public void registerSuccessMessage(){

    String successToastMessage = manageTerminal.ToastMessage.getText();
    ElementScreenshot(manageTerminal.ToastMessage);
    Assert.assertEquals("Manage Terminal Created Successfully", successToastMessage);

}


}
