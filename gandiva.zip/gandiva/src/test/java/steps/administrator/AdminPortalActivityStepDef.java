package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.UserActivityLogs.AdminPortalActivity;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import utils.PropertyUtils;
import utils.RandomUtils;
import utils.SelectDropDown.SelectDropDownValue;
import utils.WebDriverFactory;

import static com.codeborne.selenide.Condition.appear;
import static utils.Highlighter.highlight;
import static utils.RandomUtils.getVerificationCode;
import static utils.RandomUtils.getVerificationCodeForUserActivity;

@ExtendWith({ScreenShooterExtension.class})
public class AdminPortalActivityStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private AdminPortalActivity adminPortalActivity;

    @Autowired
    private SelectDropDownValue selectDropDownValue;


    public static String verificationCode;

    public static String portalName;
    Boolean codeFound = false;

         @And("user selects organization type {string}, user name {string} and clicks on submit button")
         public void user_selects_organization_type_and_clicks_on_submit_button(String OrgType, String UserName) throws InterruptedException {
             adminPortalActivity.orgType.click();
         selectDropDownValue.toSelectDropDown(adminPortalActivity.orgTypesList, OrgType);
         adminPortalActivity.adminUser.click();
         selectDropDownValue.toSelectDropDown(adminPortalActivity.adminUserList, UserName);
         adminPortalActivity.submitActivityPage.should(Condition.enabled).click();

        }


    @And("user selects organization type {string}, org name {string} and clicks on submit button")
    public void selectOrgTypeAndOrgName(String OrgType, String OrgName) throws InterruptedException {
             Thread.sleep(3000);
             adminPortalActivity.orgType.click();
             selectDropDownValue.toSelectDropDown(adminPortalActivity.orgTypesList, OrgType);
             Thread.sleep(3000);
             adminPortalActivity.orgName.click();
             adminPortalActivity.search.setValue(OrgName);
             selectDropDownValue.toSelectDropDown(adminPortalActivity.adminUserList, OrgName);
             Thread.sleep(3000);
             adminPortalActivity.submitActivityPage.should(Condition.enabled).click();

    }


        @And("Enters nodal username {string} and password to view activity logs of organization")
        public void enterNodalCredentialsToViewActivityLogs(String NodalUser){

             adminPortalActivity.nodalUserID.sendKeys(PropertyUtils.getPropString(NodalUser));
             adminPortalActivity.nodalPassword.sendKeys(PropertyUtils.getPassword());

             String Admin_captchaTxt = adminPortalActivity.userActivityCaptcha.getText();
             adminPortalActivity.userActivityCptchaField.sendKeys(Admin_captchaTxt);

             adminPortalActivity.verifybtn.should(Condition.enabled).click();

             adminPortalActivity.otpField.should(appear);// Wait for the Verification Text field to come so that you get the latest Token.

            verificationCode = getVerificationCodeForUserActivity(PropertyUtils.getPropString(NodalUser), PropertyUtils.getPassword());

            adminPortalActivity.otpField.sendKeys(verificationCode);

            adminPortalActivity.verifybtn.should(Condition.enabled).click();

        }



        @Then("user should land on activity logs page")
        public void VerifyUserLandOnActivityLogPage(){
        String pageName = adminPortalActivity.activityLogPage.getText();
        Assert.assertEquals(pageName,"User Activity Logs");
        adminPortalActivity.activityLogTable.should(Condition.appear);

        }



        @Then("Admin user should displayed activity logs of respective organizations")
        public void verifyUserLandOnOrganizationActivityPage(){
            String pageName = adminPortalActivity.activityLogPage.getText();
            Assert.assertEquals(pageName,"User Activity Logs");
            adminPortalActivity.activityLogTable.should(Condition.appear);

        }

    }
