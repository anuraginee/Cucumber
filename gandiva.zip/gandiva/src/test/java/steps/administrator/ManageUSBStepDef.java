package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.ManageUSB.ManageUSB;
import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;

public class ManageUSBStepDef {


    @Autowired
    private ManageUSB manageUSB;

    @Autowired
    private Admin_dashboard admin_dashboard;

    ScenarioContext scenarioContext = new ScenarioContext();


    @When("user navigates to AdminPortal -> Manage USB -> Approve USB")
    public void userNavigatesToManageUSB() {
        if (manageUSB.approveUSB.isDisplayed()) {
            manageUSB.approveUSB.should(Condition.enabled).click();
        } else {
            admin_dashboard.manageUSBMenu.should(Condition.enabled).click();
            manageUSB.approveUSB.should(Condition.enabled).click();
        }
    }

    @Then("user should be display existing USB Devices")
    public void userShouldDisplayExistingUSBDevices(){
        manageUSB.existingUSB.should(Condition.visible).click();
        manageUSB.terminalTable.should(Condition.visible);

    }

    @Then("Enter the required field information on add USB screen")
    public void nodalEntersDetailsOnAddUSBScreen(){


        String pid = RandomUtils.generateRandompid();
        String vid = RandomUtils.generateRandompid();
        String officeLocation = "Office"+RandomUtils.generateUniqueAlphabetName();
        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();

        scenarioContext.setContext(Context.vid, vid);

        //manageUSB.addUSBUA.should(Condition.visible).click();
        executeJavaScript("arguments[0].click();",manageUSB.addUSBUA);
        manageUSB.pid.setValue(pid);
        manageUSB.vid.setValue(vid);
        manageUSB.officeLocation.setValue(officeLocation);
        manageUSB.remarksNodal.setValue(Remarks);
       // manageUSB.createBtn.should(Condition.enabled).click();
        executeJavaScript("arguments[0].click();",manageUSB.createBtn);

    }

    @Then("Admin user approves the USB request")
    public void approveUSBRequest(){

        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();
        String vid = scenarioContext.getContext(Context.vid).toString();

        manageUSB.searchFeild.setValue(vid);
      //  manageUSB.approveBtn.should(Condition.visible).click();
        executeJavaScript("arguments[0].click();",manageUSB.approveBtn);
        manageUSB.approvalRemark.setValue(Remarks);
        manageUSB.yesBtn.should(Condition.enabled).click();
    }


    @And("Admin user should get success toast message after approving USB request")
    public void successMessageAfterUSBApproval(){

        String successToastMessage = manageUSB.ToastMessage.getText();
        ElementScreenshot(manageUSB.ToastMessage);
        Assert.assertEquals("USB details Approved successfully.", successToastMessage);

    }


    @Then("Admin user rejects the USB request")
    public void rejectUSBRequest(){

        String Remarks = "Remarks"+RandomUtils.generateUniqueAlphabetName();
        String vid = scenarioContext.getContext(Context.vid).toString();

        manageUSB.searchFeild.setValue(vid);

        executeJavaScript("arguments[0].click();",manageUSB.rejectBtn);
       //manageUSB.rejectBtn.should(Condition.visible).click();
        manageUSB.approvalRemark.setValue(Remarks);
        manageUSB.yesBtn.should(Condition.enabled).click();
    }

    @And("Admin user should get success toast message after rejecting USB request")
    public void successMessageAfterUSBReject(){

        String successToastMessage = manageUSB.ToastMessage.getText();
        ElementScreenshot(manageUSB.ToastMessage);
        Assert.assertEquals("USB details Rejected successfully.", successToastMessage);

    }



}