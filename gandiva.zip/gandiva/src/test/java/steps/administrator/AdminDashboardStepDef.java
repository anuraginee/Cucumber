/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.JavascriptExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import utils.enums.DASHBOARD_WIDGETS;

import static com.codeborne.selenide.Selenide.executeJavaScript;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class AdminDashboardStepDef {
    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private CommonElements commonElements;

    @Autowired
    private UA_dashboard ua_dashboard;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    @When("user navigates to AdminPortal -> Dashboard")
    public void userNavigatesToMenuDashboard() {
        admin_dashboard.bar_dashboard.should(Condition.enabled).click();
    }

    /**
     *
     */
    @When("user navigates to AdminPortal -> Organization Type Management")
    public void userNavigatesToOrgTypeMgmt() {
        admin_dashboard.bar_OrganizationTypeManagement.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Portal Management")
    public void userNavigatesToPortalManagement() {
        admin_dashboard.bar_PortalManagement.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Role Management")
    public void userNavigatesToRoleManagement() {
        admin_dashboard.bar_RoleManagement.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Organization Management")
    public void userNavigatesToOrganizationManagement() {
        admin_dashboard.bar_OrganizationManagement.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> User Management")
    public void userNavigatesToUserManagement() {
        admin_dashboard.bar_UserManagement.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Workflow Management")
    public void userNavigatesToWorkflowManagement() throws InterruptedException {
        admin_dashboard.workflow_Management.should(Condition.enabled).click();

    }

    @When("user navigates to AdminPortal -> Use Case Management")
    public void userNavigatesToUseCaseManagement() {
        admin_dashboard.use_Case_Management.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Activty Notifications")
    public void userNavigatesToActivityNotifications() {
        admin_dashboard.activity_Notifications.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Push Notifications")
    public void userNavigatesToPushNotifications() {
        admin_dashboard.push_Notifications.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Masters")
    public void userNavigatesToMasters() {
        admin_dashboard.masters.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Query Approval")
    public void userNavigatesToQueryApproval() {
        admin_dashboard.queryApproval.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> User Activity Logs")
    public void userNavigatesToUserActivityLogs() {
        admin_dashboard.user_Activity_Logs.should(Condition.enabled).click();
    }

    @When("user navigates to AdminPortal -> Feedback")
    public void userNavigatesToManageFeedback() throws InterruptedException {
        admin_dashboard.Feedback.should(Condition.enabled).click();
        CommonElements.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible);
    }

    @When("user navigates to AdminPortal -> Attention")
    public void userNavigatesToAttention() throws InterruptedException {
        admin_dashboard.attention.should(Condition.enabled).click();
        CommonElements.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible);
    }

    @When("user navigates to AdminPortal -> Reports")
    public void userNavigatesToReports() {
        admin_dashboard.reports.should(Condition.enabled).click();
    }

    //    @And("Logout from the ADMIN portal")
    public void logoutFromTheADMINPortal() throws InterruptedException {
        if (commonElements.popup_Close.isDisplayed()) {
            commonElements.popup_Close.click();
        }
        // Logout
        admin_dashboard.User_role.shouldBe(Condition.visible).click();
        admin_dashboard.Logout.shouldBe(Condition.visible).click();
        Assert.assertEquals("You have successfully logged out !", admin_dashboard.LogoutText.getText());
    }


    @When("Admin user clicks view all link on Organizations Enrolled widget")
    public void organizationsEnrolledWidget(){

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Organizations_Enrolled_Total.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Organizations_Enrolled_Total.getWidgetName()) );


    }


    @When("Admin user clicks view all link on Total Nodal Officers widget")
    public void totalNodalOfficersWidget(){

      //  ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Total_Nodal_Officers.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Total_Nodal_Officers.getWidgetName()));
    }


    @When("Admin user clicks view all link on Total User widget")
    public void totalUsersWidget(){

    //    ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Total_User.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Total_User.getWidgetName()));

    }


    @When("Admin user clicks view all link on Action Pending on QR Requests with Admin widget")
    public void action_Pending_on_QR_Requests_with_Admin(){

      //  ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Action_Pending_on_QR_Requests_with_Admin.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Action_Pending_on_QR_Requests_with_Admin.getWidgetName()));
    }

    @When("Admin user clicks view all link on Cases widget")
    public void casesWidget(){

       // ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
    }

    @When("Admin user clicks view all link on QR Requests widget")
    public void qrRequestsWidget(){

     //   ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.QR_Requests_Initiated.getWidgetName()).click();
        executeJavaScript("arguments[0].click();",ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.QR_Requests_Initiated.getWidgetName()));
    }

    @When("Admin user clicks view all link on Approval Awaited On Highly Sensitive Query At PO widget")
    public void approval_Awaited_On_Highly_Sensitive_Query_At_PO_Widget(){

      //  ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Approval_Awaited_On_Highly_Sensitive_Query_At_PO.getWidgetName()).click();
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Approval_Awaited_On_Highly_Sensitive_Query_At_PO.getWidgetName()));
    }

    @When("Admin user clicks view all link on Action Pending On Profile Update Request widget")
    public void action_Pending_On_Profile_Update_Request_Widget(){

      //  ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Action_Pending_On_Profile_Update_Request.getWidgetName()).click();
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Action_Pending_On_Profile_Update_Request.getWidgetName()));
    }

    @When("Admin user clicks view all link on Ingested Data Requests widget")
    public void ingested_Data_Requests_Widget(){

     //   ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Ingested_Data_Requests_ER.getWidgetName()).click();
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Ingested_Data_Requests_ER.getWidgetName()));
    }

    @When("Admin user clicks view all link on Scheduled Query Requests widget")
    public void scheduled_Query_Requests_Widget(){

      //  ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Scheduled_Query_Requests_Total.getWidgetName()).click();
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Scheduled_Query_Requests_Total.getWidgetName()));
    }






}