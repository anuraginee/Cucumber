package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.OrgTypeMgmt.AddOrgTypeMgmt;
import PageObject.AdminPortal.OrgTypeMgmt.OrgTypeMgmt;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import utils.RandomUtils;

import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;

@ExtendWith({ScreenShooterExtension.class})
public class OrgTypeManagementStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private AddOrgTypeMgmt addOrgTypeMgmt;

    @Autowired
    private OrgTypeMgmt orgTypeMgmt;

    @Autowired
    private CommonElements commonElements;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }



    @Then("verify that user get record already exists message") // verify toast message record already exists
    public void verify_that_user_get_record_already_exists_message() {
        String RecordAlreadyExistsToastMessage = addOrgTypeMgmt.ToastMessage.getText();
        Assert.assertEquals(RecordAlreadyExistsToastMessage, "Record already exists");
        ElementScreenshot(addOrgTypeMgmt.ToastMessage);
    }


    @And("Admin user should able to redirect on Add Org Type screen")
    public void AdminRedirectonAddOrgTypeScreen(){
        addOrgTypeMgmt.btn_AddOrgType.click();
        addOrgTypeMgmt.OrgType.should(Condition.appear);
        String orgType = "";
        String alias = "";
        String description = "";

        if (orgType.equalsIgnoreCase("") && alias.equalsIgnoreCase("")) {
            // Mandatory filed not entered . check for the Error messages.
            addOrgTypeMgmt.OrgType.click();
            addOrgTypeMgmt.Alias.click();
            addOrgTypeMgmt.Description.click();
        } else {

            RandomUtils.sendHumanKeys(addOrgTypeMgmt.OrgType, orgType);
            RandomUtils.sendHumanKeys(addOrgTypeMgmt.Alias, alias);
            RandomUtils.sendHumanKeys(addOrgTypeMgmt.Description, description);
            addOrgTypeMgmt.Submit.click();
        }
    }

    // Success message after creating organization type

    @And("verify that user get success toast message") // verify success toast message on creation of new org type
    public void verify_that_user_get_success_toast_message() {
        String successToastMessage = addOrgTypeMgmt.ToastMessage.getText();
        ElementScreenshot(addOrgTypeMgmt.ToastMessage);
        Assert.assertEquals("Organization Type created successfully", successToastMessage);
    }


    @Then("user validates Organisation Type field message.")
    public void verify_that_field_validation_OrgType() {
        ElementScreenshot(addOrgTypeMgmt.OrgType_fieldValidation);
        Assert.assertEquals("Organization type is required", addOrgTypeMgmt.OrgType_fieldValidation.getText());
    }

    @And("user validates Alias field message.")
    public void verify_that_field_validation_Alias() {
        Assert.assertEquals("Alias is required", addOrgTypeMgmt.Alias_fieldValidation.getText());
    }

    @Then("validate table")
    public void validateTable() {

        orgTypeMgmt.org_Type_Mgmt_table.get_Row_Counts();
        System.out.println("Row Counts : " + orgTypeMgmt.org_Type_Mgmt_table.get_Row_Counts());
        orgTypeMgmt.org_Type_Mgmt_table.get_Column_Counts();
        System.out.println("Column Counts : " + orgTypeMgmt.org_Type_Mgmt_table.get_Row_Counts());

//        int colIndex = orgTypeMgmt.org_Type_Mgmt_table.getColumnIndexByColumnName(" ORGANIZATION TYPE");
//        System.out.println("Column Index O : " + colIndex);

        int colIndexa = orgTypeMgmt.org_Type_Mgmt_table.getColumnIndexByColumnName("ALIAS");
        System.out.println("Column Index A: " + colIndexa);

        highlight(orgTypeMgmt.org_Type_Mgmt_table.get_Cell_ByIndex(2, colIndexa), "orange");

//        highlight(orgTypeMgmt.org_Type_Mgmt_table.get_Row_ByIndex(3).get(1), "blue");
//        highlight(orgTypeMgmt.org_Type_Mgmt_table.get_Column_ByIndex(3).get(1), "blue");
    }


}




