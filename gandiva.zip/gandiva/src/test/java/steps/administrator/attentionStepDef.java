package steps.administrator;

import PageObject.AdminPortal.Attention.Attention;
import com.codeborne.selenide.Condition;
import io.cucumber.java.en.And;
import org.springframework.beans.factory.annotation.Autowired;
import utils.RandomUtils;

public class attentionStepDef {



 @Autowired
 private Attention attention;





 @And("Admin user should able to add message")
 public void addMessage(){

 String title = "Title"+ RandomUtils.generateOrgName();
 String description = "The access to Gandiva will be available only on those machines that comply to these requirements. Therefore, it is once again requested update and patch the user computer system for uninterrupted connectivity with NATGRID application (Gandiva)";

 attention.addMessage.should(Condition.visible).click();
 attention.titleField.setValue(title);
 attention.descriptionField.setValue(description);
 attention.submitBtn.should(Condition.enabled).click();

 }


}
