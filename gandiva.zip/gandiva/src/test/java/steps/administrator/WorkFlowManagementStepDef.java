package steps.administrator;

import PageObject.AdminPortal.WorkFlowManagement.WorkFlowManagementFirstPage;
import PageObject.AdminPortal.WorkFlowManagement.WorkFlowManagementSecondPage;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.RandomUtils;
import utils.SelectDropDown.SelectDropDownValue;

import javax.swing.*;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;

public class WorkFlowManagementStepDef {

    @Autowired
    private WorkFlowManagementFirstPage workFlowManagementFirstPage;

    @Autowired
    private WorkFlowManagementSecondPage workFlowManagementSecondPage;

    @Autowired
    private SelectDropDownValue selectDropDownValue;




    @And("Enter details for initiator like step name {string}, step desp {string} and RoleName")
    public void EnterInitiatorDetails(String StepName, String StepDesp, DataTable dataTable) throws InterruptedException {

        workFlowManagementSecondPage.stepName.setValue(StepName);
        workFlowManagementSecondPage.stepDescription.setValue(StepDesp);
        workFlowManagementSecondPage.roleName.should(Condition.appear).click();
        Thread.sleep(3000);
        List<String> listdata = dataTable.asList(String.class);

        for(int i=0; i<=listdata.size()-1;i++){
            String roleName = listdata.get(i);
            for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
                if(e.getText().equalsIgnoreCase(roleName)){
                    e.click();
                }
            }
        }
        Thread.sleep(3000);
        workFlowManagementSecondPage.stepStatus.should(Condition.visible).doubleClick();
        workFlowManagementSecondPage.stepStatusDropdown.should(Condition.appear).click();

    }


    @And("Enter details for non sensitive step name {string}, step desp {string} and RoleName")
    public void NonSensitiveWorkFlow(String StepName, String StepDesp, DataTable dataTable) throws InterruptedException {

        workFlowManagementSecondPage.stepName.setValue(StepName);
        workFlowManagementSecondPage.stepDescription.setValue(StepDesp);
        workFlowManagementSecondPage.roleName.should(Condition.appear).click();
        Thread.sleep(3000);
        List<String> listdata = dataTable.asList(String.class);

        for(int i=0; i<=listdata.size()-1;i++){
            String roleName = listdata.get(i);
            for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
                if(e.getText().equalsIgnoreCase(roleName)){
                    e.click();
                }
            }
        }
        Thread.sleep(3000);
        workFlowManagementSecondPage.stepStatus.should(Condition.visible).doubleClick();
        workFlowManagementSecondPage.stepStatusDropdown.should(Condition.appear).click();
        workFlowManagementSecondPage.secondPageSubmit.should(Condition.appear).click();

    }


      @And("Enter details for intermidiate like StepType {string} StepName {string} StepDesp {string} StepSeq {string} RoleName")
      public void IntermediateLevelWorkFlow(String StepType, String StepName, String StepDesp, String StepSeq, DataTable datatable) throws InterruptedException {


        workFlowManagementSecondPage.addMoreLevels.should(Condition.appear).click();
        workFlowManagementSecondPage.stepTypeIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepTypeList, StepType);
        workFlowManagementSecondPage.stepNameIntermidiate.setValue(StepName);
        workFlowManagementSecondPage.stepDescriptionIntermidiate.setValue(StepDesp);
        executeJavaScript("arguments[0].click();",workFlowManagementSecondPage.stepSequneceIntermidiate);
      //  workFlowManagementSecondPage.stepSequneceIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepSeqList, StepSeq);
        workFlowManagementSecondPage.roleNameIntermidiate.should(Condition.appear).click();

          List<String> listdata = datatable.asList(String.class);

          for(int i=0; i<=listdata.size()-1;i++){
              String roleName = listdata.get(i);
              for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
                  if(e.getText().equalsIgnoreCase(roleName)){
                      e.click();
                  }
              }
          }

          workFlowManagementSecondPage.approvedStatus.should(Condition.appear).doubleClick();
          workFlowManagementSecondPage.intermRecommend.should(Condition.appear).click();
          workFlowManagementSecondPage.rejectedStatus.should(Condition.appear).click();
          workFlowManagementSecondPage.intermNotRecommend.should(Condition.appear).click();
          workFlowManagementSecondPage.intermIsMandatory.should(Condition.appear).click();
          workFlowManagementSecondPage.isMantatoryYes.should(Condition.appear).click();
          workFlowManagementSecondPage.previousStep.should(Condition.appear).click();
          Thread.sleep(3000);
          for(SelenideElement e : workFlowManagementSecondPage.previousStepList){
              e.click();
          }
          workFlowManagementSecondPage.secondPageSubmit.should(Condition.appear).doubleClick();
    }


    @And("Enter details for common mart intermidiate like StepType {string} StepName {string} StepDesp {string} StepSeq {string} RoleName")
    public void CommonMartIntermediateWorkFlow(String StepType, String StepName, String StepDesp, String StepSeq, DataTable datatable) throws InterruptedException {

        workFlowManagementSecondPage.addMoreLevels.should(Condition.appear).click();
        workFlowManagementSecondPage.stepTypeIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepTypeList, StepType);
        workFlowManagementSecondPage.stepNameIntermidiate.setValue(StepName);
        workFlowManagementSecondPage.stepDescriptionIntermidiate.setValue(StepDesp);
        executeJavaScript("arguments[0].click();",workFlowManagementSecondPage.stepSequneceIntermidiate);
       // workFlowManagementSecondPage.stepSequneceIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepSeqList, StepSeq);
        workFlowManagementSecondPage.roleNameIntermidiate.should(Condition.appear).click();

        List<String> listdata = datatable.asList(String.class);

        for(int i=0; i<=listdata.size()-1;i++){
            String roleName = listdata.get(i);
            for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
                if(e.getText().equalsIgnoreCase(roleName)){
                    e.click();
                }
            }
        }
        workFlowManagementSecondPage.recommendedStatus.scrollIntoView(true);
        workFlowManagementSecondPage.recommendedStatus.should(Condition.appear).doubleClick();
        workFlowManagementSecondPage.intermRecommend.should(Condition.appear).click();
        workFlowManagementSecondPage.notrecommendedStatus.should(Condition.appear).click();
        workFlowManagementSecondPage.intermNotRecommend.should(Condition.appear).click();
        workFlowManagementSecondPage.intermIsMandatory.should(Condition.appear).click();
        workFlowManagementSecondPage.isMantatoryNo.should(Condition.appear).click();
        workFlowManagementSecondPage.previousStep.should(Condition.appear).click();
        Thread.sleep(3000);
        for(SelenideElement e : workFlowManagementSecondPage.previousStepList){
            e.click();
        }
        workFlowManagementSecondPage.addMoreLevels.should(Condition.appear).doubleClick();
        Thread.sleep(3000);

    }

@And("Enter details for common mart terminator like StepType {string} StepName {string} StepDesp {string} StepSeq {string} RoleName")
public void CommonMartTerminatorWorkFlow(String StepType, String StepName, String StepDesp, String StepSeq ) throws InterruptedException {


    workFlowManagementSecondPage.stepTypeTerminator.should(Condition.appear).click();
    selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepTypeList, StepType);
    workFlowManagementSecondPage.stepNameTerminator.setValue(StepName);
    workFlowManagementSecondPage.stepDescriptionTerminator.setValue(StepDesp);
   // workFlowManagementSecondPage.stepSequneceTerminator.should(Condition.appear).click();
    executeJavaScript("arguments[0].click();",workFlowManagementSecondPage.stepSequneceTerminator);
    selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepSeqList, StepSeq);
    workFlowManagementSecondPage.approvedStatusTerminator.scrollIntoView(true);
    workFlowManagementSecondPage.approvedStatusTerminator.should(Condition.appear).click();
    Thread.sleep(3000);
    workFlowManagementSecondPage.intermRecommend.should(Condition.appear).click();
    workFlowManagementSecondPage.rejectedStatusTerminator.should(Condition.appear).click();
    workFlowManagementSecondPage.intermNotRecommend.should(Condition.appear).click();
    workFlowManagementSecondPage.termIsMandatory.should(Condition.appear).click();
    workFlowManagementSecondPage.isMantatoryYes.should(Condition.appear).click();
    workFlowManagementSecondPage.termPreviousStep.should(Condition.appear).click();

    Thread.sleep(3000);
    for(SelenideElement e : workFlowManagementSecondPage.previousStepList){
        e.click();
    }
    workFlowManagementSecondPage.secondPageSubmit.should(Condition.appear).doubleClick();
}



@And("Enter details for terminator like StepType {string} StepName {string} StepDesp {string} StepSeq {string} RoleName")
public void SensitiveHighSensitiveTerminatorWorkflow(String StepType, String StepName, String StepDesp, String StepSeq, DataTable datatable) throws InterruptedException {
    workFlowManagementSecondPage.stepTypeTerminator.should(Condition.appear).click();
    selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepTypeList, StepType);
    workFlowManagementSecondPage.stepNameTerminator.setValue(StepName);
    workFlowManagementSecondPage.stepDescriptionTerminator.setValue(StepDesp);
    executeJavaScript("arguments[0].click();",workFlowManagementSecondPage.stepSequneceTerminator);
   // workFlowManagementSecondPage.stepSequneceTerminator.should(Condition.appear).click();
    selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepSeqList, StepSeq);
    workFlowManagementSecondPage.roleNameTerminator.should(Condition.appear).click();

    List<String> listdata = datatable.asList(String.class);

    for(int i=0; i<=listdata.size()-1;i++){
        String roleName = listdata.get(i);
        for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
            if(e.getText().equalsIgnoreCase(roleName)){
                e.click();
            }
        }
    }
    workFlowManagementSecondPage.approvedStatusTerminator.scrollIntoView(true);
    workFlowManagementSecondPage.approvedStatusTerminator.should(Condition.appear).doubleClick();
    Thread.sleep(3000);
    workFlowManagementSecondPage.intermRecommend.should(Condition.appear).click();
    workFlowManagementSecondPage.rejectedStatusTerminator.should(Condition.appear).click();
    workFlowManagementSecondPage.intermNotRecommend.should(Condition.appear).click();
    workFlowManagementSecondPage.termIsMandatory.should(Condition.appear).click();
    workFlowManagementSecondPage.isMantatoryYes.should(Condition.appear).click();
    workFlowManagementSecondPage.termPreviousStep.should(Condition.appear).click();

    Thread.sleep(3000);
    for(SelenideElement e : workFlowManagementSecondPage.previousStepList){
        e.click();
    }
    workFlowManagementSecondPage.secondPageSubmit.should(Condition.appear).doubleClick();
    Thread.sleep(1000);


}

    @And("Enter details for intermidiate like StepType {string} StepName {string} StepDesp {string} StepSeq {string}")
    public void CaseTransferWorkflow(String StepType, String StepName, String StepDesp, String StepSeq) throws InterruptedException {


        workFlowManagementSecondPage.addMoreLevels.should(Condition.appear).click();
        workFlowManagementSecondPage.stepTypeIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepTypeList, StepType);
        workFlowManagementSecondPage.stepNameIntermidiate.setValue(StepName);
        workFlowManagementSecondPage.stepDescriptionIntermidiate.setValue(StepDesp);
        executeJavaScript("arguments[0].click();",workFlowManagementSecondPage.stepSequneceIntermidiate);
       // workFlowManagementSecondPage.stepSequneceIntermidiate.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementSecondPage.stepSeqList, StepSeq);
        workFlowManagementSecondPage.approvedStatus.should(Condition.appear).click();
        workFlowManagementSecondPage.intermRecommend.should(Condition.appear).click();
        workFlowManagementSecondPage.rejectedStatus.should(Condition.appear).click();
        workFlowManagementSecondPage.intermNotRecommend.should(Condition.appear).click();
        workFlowManagementSecondPage.intermIsMandatory.should(Condition.appear).click();
        workFlowManagementSecondPage.isMantatoryYes.should(Condition.appear).click();
        workFlowManagementSecondPage.previousStep.should(Condition.appear).click();
        Thread.sleep(3000);
        for(SelenideElement e : workFlowManagementSecondPage.previousStepList){
            e.click();
        }
        workFlowManagementSecondPage.secondPageSubmit.should(Condition.appear).doubleClick();
    }



    @Then("user should get success message and work flow should get added on screen")
    public void WorkflowSuccessfullyCreated(){

        String successToastMessage = workFlowManagementSecondPage.ToastMessage.getText();
        ElementScreenshot(workFlowManagementSecondPage.ToastMessage);
        Assert.assertEquals("Workflow Step Created Successfully", successToastMessage);
    }

    @And("user search user agency {string}, event code {string} and click on update")
    public void SearchUserAgencyAndEventCode(String UserAgency, String EventCode) throws InterruptedException {

        RandomUtils.sendHumanKeys(workFlowManagementFirstPage.workFlowSearch, UserAgency);
        highlight(workFlowManagementFirstPage.workFlowSearch,"green");
        Thread.sleep(3000);
        int colIndex = workFlowManagementFirstPage.workFlow_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = workFlowManagementFirstPage.workFlow_Mgmt_table.getRowIndexByColumnContainingText("WORK FLOW EVENT CODE", EventCode);
        workFlowManagementFirstPage.workFlow_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        Thread.sleep(5000);
    }

    @And("update RoleName details for initiator")
    public void UpdateRoleNameForInitiator(DataTable dataTable){

        workFlowManagementSecondPage.roleName.should(Condition.enabled).click();
        List<String> listdata = dataTable.asList(String.class);

        for(int i=0; i<=listdata.size(); i++){
            String roleName = listdata.get(i);
            for (SelenideElement e: workFlowManagementSecondPage.roleNameList){
                if(e.getText().equalsIgnoreCase(roleName)){
                    e.click();
                }
            }

        }

    }

}
