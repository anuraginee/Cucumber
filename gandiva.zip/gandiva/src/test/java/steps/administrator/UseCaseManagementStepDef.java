/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.OrganisationMgmt.HierarchyMgmt;
import PageObject.AdminPortal.UseCaseManagement.Parameters;
import PageObject.AdminPortal.UseCaseManagement.RequestTemplate;
import PageObject.AdminPortal.UseCaseManagement.UseCaseManagement;
import PageObject.AdminPortal.UseCaseManagement.UsecaseMapping;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.checkerframework.checker.units.qual.C;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.SelectDropDown.SelectDropDownValue;

import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class UseCaseManagementStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private UseCaseManagement useCaseManagement;

    @Autowired
    private Parameters parameters;

    @Autowired
    private SelectDropDownValue selectDropDownValue;

    @Autowired
    private CommonElements commonElements;

    @Autowired
    private HierarchyMgmt hierarchyMgmt;
    @Autowired
    private UsecaseMapping usecaseMapping;

    @Autowired
    private RequestTemplate requestTemplate;



    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    @When("user navigates to AdminPortal -> Use Case Management -> Parameters")
    public void userNavigatesToUseCaseManagement_Parameters() {
        if (admin_dashboard.use_Case_Management.is(Condition.selected)) {
            useCaseManagement.Parameters.should(Condition.enabled).click();
        } else {
            admin_dashboard.use_Case_Management.should(Condition.enabled).click();
            useCaseManagement.Parameters.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Use Case Management -> Request Templates")
    public void userNavigatesToUseCaseManagement_Request_Templates() {
        if (admin_dashboard.use_Case_Management.is(Condition.selected)) {
            useCaseManagement.Request_Templates.should(Condition.enabled).click();
        } else {
            admin_dashboard.use_Case_Management.should(Condition.enabled).click();
            useCaseManagement.Request_Templates.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Use Case Management -> Response Templates")
    public void userNavigatesToUseCaseManagement_Response_Templates() {
        if (admin_dashboard.use_Case_Management.is(Condition.selected)) {
            useCaseManagement.Response_Templates.should(Condition.enabled).click();
        } else {
            admin_dashboard.use_Case_Management.should(Condition.enabled).click();
            useCaseManagement.Response_Templates.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Use Case Management -> Use Cases")
    public void userNavigatesToUseCaseManagement_Use_Cases() {
        if (admin_dashboard.use_Case_Management.is(Condition.selected)) {
            useCaseManagement.Use_Cases.should(Condition.enabled).click();
        } else {
            admin_dashboard.use_Case_Management.should(Condition.enabled).click();
            useCaseManagement.Use_Cases.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Use Case Management -> Use Case Mapping")
    public void userNavigatesToUseCaseManagement_Use_Case_Mapping() {
        if (admin_dashboard.use_Case_Management.is(Condition.selected)) {
            useCaseManagement.Use_Case_Mapping.should(Condition.enabled).click();
        } else {
            admin_dashboard.use_Case_Management.should(Condition.enabled).click();
            useCaseManagement.Use_Case_Mapping.should(Condition.enabled).click();
        }
    }

    @And("User navigates to Hierarchy management and rights screen and define the hierarchy of providing orgnization")
    public void providingOrganizationHierarchy(DataTable dataTable) throws InterruptedException {

        List<Map<String, String>> listdata = dataTable.asMaps(String.class, String.class);

        int j = 2;
        for (int i = 0; i <= listdata.size(); i++) {
            if(i < 1){
                executeJavaScript("arguments[0].click();",hierarchyMgmt.roleId);
                Thread.sleep(3000);
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.roleIDList,listdata.get(i).get("RoleName"));
                Thread.sleep(3000);
                hierarchyMgmt.rankID.should(Condition.enabled).click();
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.rankList,listdata.get(i).get("RankName") );
                Thread.sleep(3000);
                hierarchyMgmt.addMoreLevel.should(Condition.enabled).doubleClick();

            }
            else{

                SelenideElement roleId = $(By.xpath("(//*[@formcontrolname='roleId'])["+ j +"]"));
                roleId.should(Condition.enabled).click();
                System.out.println(roleId);
                Thread.sleep(3000);
                SelenideElement roleIDList1 = $(By.xpath("(//*[@class='mdc-list-item__primary-text'])["+ j +"]"));
                System.out.println(roleIDList1.getText());
                roleIDList1.click();
                SelenideElement  rankID = $(By.xpath("(//*[@formcontrolname='roleRankName'])["+ j +"]"));
                rankID.should(Condition.enabled).click();
                System.out.println(rankID);
                Thread.sleep(3000);
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.rankList,listdata.get(i).get("RankName") );
                Thread.sleep(3000);
                hierarchyMgmt.addMoreLevel.should(Condition.enabled).doubleClick();

                j++;
                if(j==3){
                    break;
                }
            }
        }
        hierarchyMgmt.poIsNodalToggle.should(Condition.visible).click();
        Thread.sleep(3000);
        hierarchyMgmt.orgMgmtSubmit.should(Condition.visible).click();
        Thread.sleep(3000);
    }

    @Then("user should get success message after adding parameter")
    public void SuccessMessageOfParameter(){
        String successToastMessage = parameters.ToastMessage.getText();
        ElementScreenshot(parameters.ToastMessage);
        Assert.assertEquals("Parameter Created Successfully", successToastMessage);

    }


    @Then("Admin user should get success message after updating parameter")
    public void parameterUpdateSuccessMessage(){

        String successToastMessage = parameters.ToastMessage.getText();
        ElementScreenshot(parameters.ToastMessage);
        Assert.assertEquals("Parameter Updated Successfully", successToastMessage);
    }

    @And("Search request template {string} which want to update and click on edit button")
    public void searchRequestTemplate(String ReqTemp) throws InterruptedException {

        requestTemplate.reqTempSearch.sendKeys(ReqTemp);
        highlight(requestTemplate.reqTempSearch,"green");
        Thread.sleep(3000);
        int colIndex = requestTemplate.reqTempTable.getColumnIndexByColumnName("ACTION");
        int rownumber = requestTemplate.reqTempTable.getRowIndexByColumnContainingText("REQUEST TEMPLATE NAME", ReqTemp);
        requestTemplate.reqTempTable.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
    }

    @And("Admin user should able to update request template")
    public void updateRequestTemplate(){

        requestTemplate.selectParam.click();
        requestTemplate.selectInputType.click();
        requestTemplate.selectValidation.click();
        requestTemplate.paramOrder.doubleClick();
        requestTemplate.dependsOn.click();
        requestTemplate.helpText.doubleClick();
        requestTemplate.sqlQuery.click();
        requestTemplate.reqTempUpdate.should(Condition.enabled).click();

    }


    @And("Admin user should get success toast message stating Request Template Updated Successfully")
    public void requestTemplateUpdateSuccessMessage(){

        String successToastMessage = parameters.ToastMessage.getText();
        ElementScreenshot(parameters.ToastMessage);
        Assert.assertEquals("Request Template Updated Successfully", successToastMessage);

    }

    @And("Search response template {string} which want to update and click on edit button")
    public void searchResponseTemplate(String ResTemp) throws InterruptedException {

        RandomUtils.sendHumanKeys(requestTemplate.reqTempSearch, ResTemp);
        highlight(requestTemplate.reqTempSearch,"green");
        Thread.sleep(3000);
        int colIndex = requestTemplate.reqTempTable.getColumnIndexByColumnName("ACTION");
        int rownumber = requestTemplate.reqTempTable.getRowIndexByColumnContainingText("RESPONSE TEMPLATE NAME", ResTemp);
        requestTemplate.reqTempTable.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
    }

    @And("Admin user should able to update response template")
    public void updateResponseTemplate(){

        requestTemplate.selectParam.click();
        requestTemplate.paramOrder.doubleClick();
        requestTemplate.sqlQuery.click();
        requestTemplate.selectInputType.click();
        requestTemplate.reqTempUpdate.should(Condition.enabled).click();

    }

    @And("Admin user should get success toast message stating Response Template Updated Successfully")
    public void responseTemplateUpdateSuccessMessage(){

        String successToastMessage = parameters.ToastMessage.getText();
        ElementScreenshot(parameters.ToastMessage);
        Assert.assertEquals("Response Template Updated Successfully", successToastMessage);

    }

    @And("Admin user searches PO OrgName {string}, ParamName {string} and update ParamKey, ParamType {string}, IsQueryable {string}")
    public void updateParameter(String OrgName, String ParamName, String ParamType, String IsQueryable) throws InterruptedException {


        String ParamKey = RandomUtils.generateUniqueAlphabetName();
        commonElements.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible);
        parameters.paramSearch.sendKeys(OrgName);
        Thread.sleep(3000);
        highlight(parameters.paramSearch,"green");
        int colIndex = parameters.paramTable.getColumnIndexByColumnName("ACTION");
        int rownumber = parameters.paramTable.getRowIndexByColumnContainingText("PARAMETER NAME", ParamName);
        parameters.paramTable.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        parameters.param_Key.clear();
        parameters.param_Key.sendKeys(ParamKey);
        parameters.param_Type.should(Condition.appear).click();
        parameters.Param_Type(ParamType).click();
        Thread.sleep(2000);
        parameters.is_Queryable.should(Condition.appear).click();
        parameters.Is_Queryable(IsQueryable).click();
        parameters.paramUpdate.should(Condition.appear).click();

    }

    @And("Admin user should able to select PO {string} and UA {string} and update the details")
    public void updateUseCaseMapping(String POName, String UAName) throws InterruptedException {

//        executeJavaScript("arguments[0].click();",usecaseMapping.selectPO);
        Thread.sleep(3000);
        usecaseMapping.selectPO.sendKeys(POName);
        if(usecaseMapping.Select_PO_From_List.isDisplayed()) {
            usecaseMapping.Select_PO_From_List.click();
        }


//        selectDropDownValue.toSelectDropDown(usecaseMapping.poList, POName);
        usecaseMapping.selectUA.click();
        usecaseMapping.selectUA.sendKeys(UAName);
        if(usecaseMapping.Select_PO_From_List.isDisplayed()) {
            usecaseMapping.Select_PO_From_List.click();
        }


//        selectDropDownValue.toSelectDropDown(usecaseMapping.uaList, UAName);
        Thread.sleep(3000);
//        usecaseMapping.usecaseMapSubmit.should(Condition.enabled).click();
    }

    @Then("Admin user should get success message after updating mapping")
    public void updateUsecaseSuccessMessage(){

        String successToastMessage = parameters.ToastMessage.getText();
        ElementScreenshot(parameters.ToastMessage);
        Assert.assertEquals("Use Case Configuration Created Successfully", successToastMessage);

    }






}