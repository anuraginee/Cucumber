/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.Masters.POAPIConfiguration;
import PageObject.AdminPortal.OrganisationMgmt.HierarchyMgmt;
import PageObject.AdminPortal.OrganisationMgmt.MenuMapping;
import PageObject.AdminPortal.OrganisationMgmt.OrganisationMgmt;
import PageObject.AdminPortal.OrganisationMgmt.UpdateOrganisation;
import PageObject.AdminPortal.UseCaseManagement.Parameters;
import PageObject.AdminPortal.UseCaseManagement.UseCaseManagement;
import PageObject.AdminPortal.UserManagement.UserManagement;
import PageObject.AdminPortal.WorkFlowManagement.WorkFlowManagementFirstPage;
import PageObject.AdminPortal.WorkFlowManagement.WorkFlowManagementSecondPage;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Screenshots.takeScreenShot;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverRunner.addListener;
import static utils.Highlighter.highlight;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class OrgManagementStepDef {
    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private OrganisationMgmt admin_OrganisationMgmt;
    @Autowired
    private UpdateOrganisation updateOrganisation;

    @Autowired
    private OrganisationMgmt organisationMgmt;

    @Autowired
    private CommonElements commonElements;

    @Autowired
    private HierarchyMgmt hierarchyMgmt;

    @Autowired
    private SelectDropDownValue selectDropDownValue;

    @Autowired
    private MenuMapping menuMapping;

    @Autowired
    private UserManagement userManagement;

    @Autowired
    private UserManagement admin_userManagement;

    @Autowired
    private WorkFlowManagementFirstPage workFlowManagementFirstPage;

    @Autowired
    private WorkFlowManagementSecondPage workFlowManagementSecondPage;

    @Autowired
    private UseCaseManagement useCaseManagement;

    @Autowired
    private POAPIConfiguration poapiConfiguration;

    @Autowired
    private Parameters parameters;

    Scenario scenario;


    ScenarioContext scenarioContext = new ScenarioContext();


    Map<String, Integer> map_nodal = new HashMap<String, Integer>();


    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


    /**
     * @param roleName
     * @throws InterruptedException
     */
    @And("user navigates to Menu Mapping Permission Page and validates Menu Mapping for {string}")
    public void userNavigatesToMenuMappingPermissionPageAndValidatesMenuMappingFor(String roleName) throws InterruptedException {

//        admin_OrganisationMgmt.Modify.click();


        updateOrganisation.btn_Update.should(Condition.visible, Duration.ofMillis(10000)).click();
        updateOrganisation.label_Hierarchy_mgmt.should(Condition.visible);
        Thread.sleep(10000);
        //        updateOrganisation.btn_Update.should(Condition.interactable, Duration.ofMillis(10000)).click();
//        updateOrganisation.btn_Update2.click();
        for (SelenideElement e : updateOrganisation.btn_Update2) {
            if (e.isDisplayed() == true) {
                e.click();
            }
        }
        updateOrganisation.btn_NODAL_OFFICER.should(Condition.visible, Duration.ofMillis(30000)).click();

        Thread.sleep(5000);

    }

    @Then("user enters required info on onboard org form like org type {string}, portal {string}, agencytype {string}")
    public void onboardOrganization(String OrgType, String Portal, String AgencyType) throws InterruptedException {

        String OrgName = "Organization" + RandomUtils.generateOrgName();
        String Alias = "ORG" + RandomUtils.generateUniqueAlphabetName();
        String Address = "Delhi" + RandomUtils.generateUniqueAlphabetName();


        organisationMgmt.enrollOrgBtn.should(Condition.visible).click();
        organisationMgmt.enrollOrgWindowPopUp.should(Condition.visible,Duration.ofMinutes(2));
        organisationMgmt.orgType.should(Condition.visible);
        organisationMgmt.orgType.click();
        Thread.sleep(2000);
//        executeJavaScript("arguments[0].click();", organisationMgmt.orgType);
//        Thread.sleep(2000);
        SelectDropDownValue.toSelectDropDown(organisationMgmt.orgTypeList, OrgType);
        Thread.sleep(2000);
        RandomUtils.sendHumanKeys(organisationMgmt.orgName, OrgName);
        RandomUtils.sendHumanKeys(organisationMgmt.alias, Alias);

        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();", organisationMgmt.selectPortal);
        SelectDropDownValue.toSelectDropDown(organisationMgmt.portalList, Portal);
        Thread.sleep(2000);
        organisationMgmt.central.should(Condition.appear).click();
        organisationMgmt.orgAddress.should(Condition.visible).doubleClick();
        RandomUtils.sendHumanKeys(organisationMgmt.orgAddress, Address);
        Thread.sleep(2000);
        organisationMgmt.orgMgmtSubmit.click();
        Thread.sleep(2000);

        scenario.log("Newly Created Organization Name ::::::: " + OrgName);
        scenario.log("Newly Created Organization Alias ::::::: " + Alias);

        scenarioContext.setContext(Context.OrgName, OrgName);

    }


    @And("user searches for Organization Name and Organisation Type is {string}")
    public void userSearchesForOrganisationName(String orgType) throws InterruptedException {

        String orgName = scenarioContext.getContext(Context.OrgName).toString();
        RandomUtils.sendHumanKeys(admin_OrganisationMgmt.search, orgName);
        int colIndex = admin_OrganisationMgmt.org_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = admin_OrganisationMgmt.org_Mgmt_table.getRowIndexByColumnContainingText("ORGANIZATION TYPE", orgType);
        admin_OrganisationMgmt.org_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        Thread.sleep(5000);
    }

    @And("Admin user clicks on PO API Summary tab and add PO API Summary")
    public void addPOAPISummary() throws InterruptedException {

        String apiURL = "http://" + RandomUtils.generateOrgName() + "gov.in";
        String apiKey = "api" + RandomUtils.generateUniqueAlphabetName();
        String apiValue = RandomUtils.generateUniqueInt();
        String OrgName = scenarioContext.getContext(Context.OrgName).toString();

        poapiConfiguration.POAPISummaryTab.should(Condition.visible).click();
        poapiConfiguration.AddPOAPISummaryBtn.should(Condition.visible).click();
       // poapiConfiguration.selectPO.click();
        executeJavaScript("arguments[0].click();",poapiConfiguration.selectPO);
        Thread.sleep(1000);
        SelectDropDownValue.toSelectDropDown(poapiConfiguration.poList, OrgName);
        poapiConfiguration.apiURL.setValue(apiURL);
        poapiConfiguration.apiKey.setValue(apiKey);
        poapiConfiguration.apiValue.setValue(apiValue);
        poapiConfiguration.submit.should(Condition.enabled).click();
        Thread.sleep(3000);

    }

    @And("Admin user clicks on PO API Configuration tab and add PO API Configuration with required information api servive {string}")
    public void addPOAPIConfiguration(String APIService) throws InterruptedException {

        String apiURLMethod = "http://" + RandomUtils.generateOrgName() + "gov.in";
        String apiLable = "api" + RandomUtils.generateUniqueAlphabetName();
        String headerReqParam = "RequestParameter" + RandomUtils.generateUniqueAlphabetName();
        String headerResParam = "ResponseParameter" + RandomUtils.generateUniqueAlphabetName();
        String reqParamWithURL = "http://" + RandomUtils.generateOrgName();

        String POAPI = scenarioContext.getContext(Context.OrgName).toString();

        Thread.sleep(3000);
        poapiConfiguration.POAPIConfigurationTab.should(Condition.visible).click();
        poapiConfiguration.AddPOAPIConfigurationBtn.should(Condition.visible).click();
        poapiConfiguration.apiURLMethod.setValue(apiURLMethod);
        poapiConfiguration.apiLabel.setValue(apiLable);
        poapiConfiguration.headerReqParam.setValue(headerReqParam);
        poapiConfiguration.headerResParam.setValue(headerResParam);
        poapiConfiguration.apiService.click();
        SelectDropDownValue.toSelectDropDown(poapiConfiguration.apiServiceList, APIService);
        poapiConfiguration.poAPI.click();
        SelectDropDownValue.toSelectDropDown(poapiConfiguration.poList, POAPI);
        poapiConfiguration.reqParamWithURL.setValue(reqParamWithURL);
        poapiConfiguration.submit.should(Condition.enabled).click();

    }


    @And("user add parameter details ParamName, ParamKey, ParamType {string}, IsQueryable {string}")
    public void AddParameter(String ParamType, String IsQueryable) throws InterruptedException {

        String OrgName = scenarioContext.getContext(Context.OrgName).toString();
        String ParamName = "Param" + RandomUtils.generateOrgName();
        String ParamKey = "Param_" + RandomUtils.generateUniqueAlphabetName();

        useCaseManagement.Add_Parameter.should(Condition.appear).click();
        Thread.sleep(2000);
        parameters.poList.should(Condition.appear).click();
        parameters.Search_Text_Box.sendKeys(OrgName);
        parameters.Select_PO.shouldBe(Condition.visible).click();


        parameters.param_Name.sendKeys(ParamName);
        parameters.param_Key.sendKeys(ParamKey);
        parameters.param_Type.should(Condition.appear).click();

        parameters.Param_Type(ParamType).click();
        Thread.sleep(2000);
        parameters.is_Queryable.should(Condition.appear).click();
        parameters.Is_Queryable(IsQueryable).click();
//        selectDropDownValue.toSelectDropDown(parameters.commonList, IsQueryable);
        Thread.sleep(3000);
        parameters.Submit_Button.should(Condition.appear).click();

    }


    @And("User searches orgtype {string} and enters required details to create nodal officer")
    public void createNodalOfficer(String OrgType) throws InterruptedException {

        String Name = RandomUtils.generateUniqueAlphabetName() + "nodal";
        String EmailID = RandomUtils.generateRandomEmail();
        String ContactNo = RandomUtils.generateRandomMobileNumber(10);
        String Address = "Delhi" + RandomUtils.generateUniqueAlphabetName();
        String LoginID = RandomUtils.generateUniqueString() + "nodal";

        String OrgName = scenarioContext.getContext(Context.OrgName).toString();
        admin_userManagement.addNodalOfficer.should(Condition.appear).click();
        RandomUtils.sendHumanKeys(admin_userManagement.nodalName, Name);
        RandomUtils.sendHumanKeys(admin_userManagement.nodalLoginID, LoginID);
        RandomUtils.sendHumanKeys(admin_userManagement.nodalEmailId, EmailID);
        RandomUtils.sendHumanKeys(admin_userManagement.nodalContactNo, ContactNo);
        RandomUtils.sendHumanKeys(admin_userManagement.nodalAddress, Address);
        admin_userManagement.nodalOrgType.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(admin_userManagement.nodalOrgTypeList, OrgType);
        admin_userManagement.nodalOrgName.should(Condition.appear).click();
        selectDropDownValue.toSelectDropDown(admin_userManagement.nodalOrgNameList, OrgName);
        admin_userManagement.nodalPortal.should(Condition.appear).click();
        admin_userManagement.gandivaPortal.should(Condition.appear).click();
        Thread.sleep(3000);
        admin_userManagement.rankId.should(Condition.appear).click();
        admin_userManagement.nodalRank.should(Condition.appear).click();
        admin_userManagement.nodalSubmit.should(Condition.appear).click();
        scenario.log("New Nodal Officer Login ID ::::::: " + LoginID);
        scenario.log("New Nodal Officer Name ::::::: " + Name);


        scenarioContext.setContext(Context.LoginID, LoginID);

    }

    @And("Validate the newly created nodal user in users table")
    public void validateTheNewlyCreatedCaseInManageUserTable() throws InterruptedException {

        String Login_Id = scenarioContext.getContext(Context.LoginID).toString();
        int colIndex = admin_userManagement.user_Mgmt_table.getColumnIndexByColumnName("Login ID");
        int rowIndex = admin_userManagement.user_Mgmt_table.getRowIndexByColumnContainingText("Login ID", Login_Id + "@devng.in");
        System.out.println(colIndex);
        System.out.println(rowIndex);
        highlight(admin_userManagement.user_Mgmt_table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        System.out.println("Get cell by Index value :: " + admin_userManagement.user_Mgmt_table.get_Cell_ByIndex(rowIndex, colIndex));
        Assert.assertEquals(Login_Id + "@devng.in", admin_userManagement.user_Mgmt_table.get_Cell_ByIndex(rowIndex, colIndex).getText());

        int colIndex1 = admin_userManagement.user_Mgmt_table.getColumnIndexByColumnName("Password");
        int rowIndex1 = admin_userManagement.user_Mgmt_table.getRowIndexByColumnContainingText("Login ID", Login_Id + "@devng.in");
        System.out.println(colIndex1);
        System.out.println(rowIndex1);
        Thread.sleep(3000);

//        admin_userManagement.passIcon.should(Condition.appear).click();
//        String temp_Password = admin_userManagement.firstTimePassword.getText();
//        String [] arr = temp_Password.split(":");
//        String firstTimePassword = arr[1];
//        System.out.println(firstTimePassword);
//        admin_userManagement.popUpClose.click();
//        System.out.println(temp_Password);
//        scenarioContext.setContext(Context.Temp_Password,firstTimePassword);

    }


    @When("user searches for User Name")
    public void userSearchesForUserName() throws InterruptedException {

        String LoginID = scenarioContext.getContext(Context.LoginID).toString();
        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {

        } else {
            admin_userManagement.bar_UserManagement_Users.click();
        }
        RandomUtils.sendHumanKeys(admin_userManagement.search, LoginID);
        Thread.sleep(10000);

    }

    @And("user searches orgname, login id from table and update name, email, mobile and address")
    public void UpdateNodalDetails() throws InterruptedException {

        String Name = RandomUtils.generateUniqueAlphabetName();
        String EmailId = RandomUtils.generateRandomEmail();
        String Mobile = RandomUtils.generateRandomMobileNumber(10);
        String Address = RandomUtils.generateUniqueAlphabetName();

        String LoginID = scenarioContext.getContext(Context.LoginID).toString();
        String orgName = scenarioContext.getContext(Context.OrgName).toString();

//        RandomUtils.sendHumanKeys(admin_userManagement.search, orgName);
//        highlight(admin_userManagement.search,"green");
//        Thread.sleep(3000);
//        int colIndex = admin_userManagement.user_Mgmt_table.getColumnIndexByColumnName("ACTION");
//        int rownumber = admin_userManagement.user_Mgmt_table.getRowIndexByColumnContainingText("LOGIN ID", LoginID);
//        admin_userManagement.user_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();

        Thread.sleep(3000);
        $(By.xpath("//*[text()='Admin Users']")).click();
        $(By.xpath("//*[@class='mdc-tab__text-label' and text()='Nodal Officers']")).click();
        commonElements.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible);

        RandomUtils.sendHumanKeys(admin_userManagement.search, LoginID);
        int colIndex = admin_userManagement.user_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = admin_userManagement.user_Mgmt_table.getRowIndexByColumnContainingText("ORGANIZATION NAME", orgName);
        admin_userManagement.user_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();

        Thread.sleep(5000);
        admin_userManagement.nodalName.clear();
        RandomUtils.sendHumanKeys(admin_userManagement.nodalName, Name);
        admin_userManagement.nodalEmailId.clear();
        RandomUtils.sendHumanKeys(admin_userManagement.nodalEmailId, EmailId);
        admin_userManagement.nodalContactNo.clear();
        RandomUtils.sendHumanKeys(admin_userManagement.nodalContactNo, Mobile);
        admin_userManagement.nodalAddress.clear();
        RandomUtils.sendHumanKeys(admin_userManagement.nodalAddress, Address);
        admin_userManagement.nodalUpdate.should(Condition.enabled).click();

    }


    @And("user clicks on add work flow button and selects agency type {string}, event {string} and enters work flow name {string}")
    public void SelectWorkFlowEvent(String OrgType, String Event, String WorkFlowName) throws InterruptedException {

        String OrgName = scenarioContext.getContext(Context.OrgName).toString();
        workFlowManagementFirstPage.addWorkFlowBtn.should(Condition.visible).click();
        workFlowManagementFirstPage.orgType.should(Condition.visible).click();
        Thread.sleep(3000);
        selectDropDownValue.toSelectDropDown(workFlowManagementFirstPage.orgTypeList, OrgType);
        highlight(workFlowManagementFirstPage.orgType, "green");
        workFlowManagementFirstPage.selectOrgName.should(Condition.visible).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementFirstPage.orgNameList, OrgName);
        highlight(workFlowManagementFirstPage.selectOrgName, "green");
        workFlowManagementFirstPage.eventCode.should(Condition.visible).click();
        selectDropDownValue.toSelectDropDown(workFlowManagementFirstPage.eventCodeList, Event);
        highlight(workFlowManagementFirstPage.eventCode, "green");
        workFlowManagementFirstPage.workFlowName.setValue(WorkFlowName);
        highlight(workFlowManagementFirstPage.workFlowName, "green");
        workFlowManagementFirstPage.workFlowSubmit.should(Condition.enabled).click();
        Thread.sleep(3000);


    }


    @And("User navigates to Hierarchy management and rights screen and define the hierarchy of orgnization")
    public void organizationHierarchy(DataTable dataTable) throws InterruptedException {

        List<Map<String, String>> listdata = dataTable.asMaps(String.class, String.class);

        int j = 2;
        for (int i = 0; i <= listdata.size(); i++) {
            if (i < 1) {
                //  hierarchyMgmt.roleId.should(Condition.enabled).click();

                executeJavaScript("arguments[0].click();", hierarchyMgmt.roleId);
                Thread.sleep(3000);
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.roleIDList, listdata.get(i).get("RoleName"));
                Thread.sleep(3000);
                hierarchyMgmt.rankID.should(Condition.enabled).click();
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.rankList, listdata.get(i).get("RankName"));
                Thread.sleep(3000);
                hierarchyMgmt.addMoreLevel.should(Condition.enabled).doubleClick();

            } else {

                SelenideElement roleId = $(By.xpath("(//*[@formcontrolname='roleId'])[" + j + "]"));
                roleId.should(Condition.enabled).click();
                System.out.println(roleId);
                Thread.sleep(3000);
                SelenideElement roleIDList1 = $(By.xpath("(//*[@class='mdc-list-item__primary-text'])[" + j + "]"));
                System.out.println(roleIDList1.getText());
                roleIDList1.click();
                SelenideElement rankID = $(By.xpath("(//*[@formcontrolname='roleRankName'])[" + j + "]"));
                rankID.should(Condition.enabled).click();
                System.out.println(rankID);
                Thread.sleep(3000);
                selectDropDownValue.toSelectDropDown(hierarchyMgmt.rankList, listdata.get(i).get("RankName"));
                Thread.sleep(3000);
                hierarchyMgmt.addMoreLevel.should(Condition.enabled).doubleClick();

                j++;
                if (j == 6) {
                    break;
                }
            }
        }
        hierarchyMgmt.isNodalToggle.should(Condition.visible).click();
        Thread.sleep(3000);
        hierarchyMgmt.orgMgmtSubmit.should(Condition.visible).click();
        Thread.sleep(3000);
    }


    @And("user navigates to Menu Mapping Permission Page and gives Menu Mapping for roles")
    public void menuMappingAndPermissions() {

        menuMapping.MenuMappingSubmit.should(Condition.visible).click();
    }

}