package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.OrganisationMgmt.OrganisationMgmt;
import PageObject.AdminPortal.PortalMgmt.PortalMgmt;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.RandomUtils;
import utils.SelectDropDown.SelectDropDownValue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$$;
import static steps.CommonStepDef.ElementScreenshot;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;

@ExtendWith({ScreenShooterExtension.class})
public class PortalManagementStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private CommonElements commonElements;
    @Autowired
    private PortalMgmt portalMgmt;

    @Autowired
    private OrganisationMgmt admin_OrganisationMgmt;

    @Autowired
    private SelectDropDownValue selectDropDownValue;

    public static  List<SelenideElement>  portalMenuList;

    public static  List<SelenideElement>  orgMenuList;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    @And("user update portal {string} Alias {string} menu {string} and Description {string} which already exists")
    public void user_update_Alias_and_Description_which_already_exists(String portal, String alias, String description, String menu) throws InterruptedException {

        portalMgmt.portalMgmt_btn.click();
        Thread.sleep(2000);

        if (portal.equalsIgnoreCase("PO Portal")) {
            portalMgmt.PO_btn_Update.click();
        } else if (portal.equalsIgnoreCase("GANDIVA")) {
            portalMgmt.Gandiva_btn_Update.click();
        } else if (portal.equalsIgnoreCase("SUDARSHAN")) {
            portalMgmt.Sudarshan_btn_Update.click();
        }
        portalMgmt.aliasField.clear();
        RandomUtils.sendHumanKeys(portalMgmt.aliasField, alias);
        portalMgmt.descriptionField.clear();
        RandomUtils.sendHumanKeys(portalMgmt.descriptionField, description);
        Thread.sleep(2000);

        for (SelenideElement e:portalMgmt.menuAndPermissions){
            System.out.println(e.getText());
            if(e.getText().equalsIgnoreCase(menu)){
                e.click();
            }
        }
        Thread.sleep(2000);


        portalMgmt.btn_Update.should(Condition.appear).click();

    }


    @And("user update portal {string} which already exists and user update menu {string} on portal management")
    public void userUpdateAliasAndDescription(String portal, String menu) throws InterruptedException {

        portalMgmt.portalMgmt_btn.click();
        Thread.sleep(2000);

        if (portal.equalsIgnoreCase("PO Portal")) {
            portalMgmt.PO_btn_Update.click();
        } else if (portal.equalsIgnoreCase("GANDIVA")) {
            portalMgmt.Gandiva_btn_Update.click();
        } else if (portal.equalsIgnoreCase("SUDARSHAN")) {
            portalMgmt.Sudarshan_btn_Update.click();
        }

        Thread.sleep(2000);

        for (SelenideElement e:portalMgmt.menuAndPermissions){
            System.out.println(e.getText());
            if(e.getText().equalsIgnoreCase(menu)){
                e.click();
            }
        }
        Thread.sleep(2000);


        portalMgmt.btn_Update.should(Condition.appear).click();


    }

    @And("verify that user get success toast message that portal updated")
    public void verify_that_user_get_success_toast_message_that_portal_updated() throws IOException {
        String PortalUpdatedSuccessfully = portalMgmt.portalToastMessage.getText();
        System.out.println(PortalUpdatedSuccessfully);
        Assert.assertEquals("Portal Updated Successfully", PortalUpdatedSuccessfully);
        ElementScreenshot(portalMgmt.portalToastMessage);
    }

    @And("Read updated menu of the portal {string}")
    public void ReadUpdatedMenu(String portal) throws InterruptedException {
        portalMgmt.portalMgmt_btn.click();
        Thread.sleep(2000);
        if (portal.equalsIgnoreCase("PO Portal")) {
            portalMgmt.PO_btn_Update.click();
        } else if (portal.equalsIgnoreCase("GANDIVA")) {
            portalMgmt.Gandiva_btn_Update.click();
        } else if (portal.equalsIgnoreCase("SUDARSHAN")) {
            portalMgmt.Sudarshan_btn_Update.click();
        }

        Thread.sleep(2000);
        portalMenuList = $$(portalMgmt.menuAndPermissions);
        System.out.println(portalMenuList.size());
        portalMgmt.btn_Update.should(Condition.appear).click();
        }

        @And("user navigates to Menu Mapping Permission Page and verify menu as per portal management")
        public void VerifyMenuMappingAndPermissions(){
            orgMenuList = $$(By.xpath("//*[@class='mat-checkbox-label']"));
            System.out.println(orgMenuList.size());
          // Need to add assertions
        }



     @Then("verify that changes done in portal management are reflecting in organization management for organization {string}")
     public void verify_that_changes_done_in_portal_management_are_reflecting_in_organization_management_for_organization(String OrgName) {

     }


     @And("verify that changes done in portal management are reflecting on UA portal for username {string} and password {string}")
     public void verify_that_changes_done_in_portal_management_are_reflecting_on_UA_portal_for_username_and_password(String UaUser, String UaPassword) {

        //need to do implementation
    }


    /*
    This is Just a Sample Code. You may delete it later or costomioze this method as well.
     */
    @Then("user validates Portal Management table")
    public void validateTable(DataTable dataTable) throws Throwable {
//        scenario.attach(screenshot(new Date().toString()).getBytes(StandardCharsets.UTF_8),"image/png",scenario.getName());
        List<Map<String, String>> list_data = dataTable.asMaps(String.class, String.class);
        for (int i = 0; i < list_data.size(); i++) {
            Thread.sleep(2000);
            String[] ColumnNames = {"PORTAL NAME", "ALIAS", "DESCRIPTION", "CREATED BY"};
            for (int j = 0; j < ColumnNames.length; j++) {
                Thread.sleep(2000);
                System.out.println("" + ColumnNames[j] + " :" + list_data.get(i).get(ColumnNames[j]));
                highlight(portalMgmt.portal_Mgmt_table.get_Cell_ByIndex(i, portalMgmt.portal_Mgmt_table.getColumnIndexByColumnName(ColumnNames[j])), "green");
//                scenario.log("Validating : " + list_data.get(i).get(ColumnNames[j]).toString());
 //               Assert.assertEquals(list_data.get(i).get(ColumnNames[j]), portalMgmt.portal_Mgmt_table.get_Cell_ByIndex(i, portalMgmt.portal_Mgmt_table.getColumnIndexByColumnName(ColumnNames[j])).getText());
            }
        }
        TakeScreenshot();
    }
}
