/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.Reports.Reports;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.TakesScreenshot;
import org.springframework.beans.factory.annotation.Autowired;
import utils.enums.DASHBOARD_WIDGETS;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.TakeScreenshot;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class ReportsStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private Reports reports;

    @Autowired
    private CommonElements commonElements;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


//    public static final SelenideElement migration_Status = $(By.xpath("//span[contains(@class,'item-label') and contains(text(),'Migration Status')]"));


    @When("user navigates to AdminPortal -> Reports -> User Agency Wise Request Response Summary")
    public void userNavigatesToReports_User_Agency_Wise_Request_Response_Summary() {
        if (reports.user_Agency_Wise_Request_Response_Summary.isDisplayed()) {
            reports.user_Agency_Wise_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.user_Agency_Wise_Request_Response_Summary.should(Condition.enabled).click();
        }
    }


    @When("user navigates to AdminPortal -> Reports -> PO Wise Request-Response")
    public void userNavigatesToReports_PO_Wise_Request_Response() {
        if (reports.po_Wise_Request_Response.isDisplayed()) {
            reports.po_Wise_Request_Response.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.po_Wise_Request_Response.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> Previous Month Request Response Summary")
    public void userNavigatesToReports_Previous_Month_Request_Response_Summary() {
        if (reports.previous_Month_Request_Response_Summary.isDisplayed()) {
            reports.previous_Month_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.previous_Month_Request_Response_Summary.should(Condition.enabled).click();

        }
    }

    @When("user navigates to AdminPortal -> Reports -> Total Request Response Summary")
    public void userNavigatesToReports_Total_Request_Response_Summary() throws InterruptedException {
        if (reports.total_Request_Response_Summary.isDisplayed()) {
            reports.total_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.total_Request_Response_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> Category Wise Request Summary")
    public void userNavigatesToReports_Category_Wise_Request_Summary() {
        if (reports.category_Wise_Request_Summary.isDisplayed()) {
            reports.category_Wise_Request_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.category_Wise_Request_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> Admin Approval Request Summary")
    public void userNavigatesToReports_Admin_Approval_Request_Summary() {
        if (reports.admin_Approval_Request_Summary.isDisplayed()) {
            reports.admin_Approval_Request_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.admin_Approval_Request_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Query Executed")
    public void userNavigatesToReports_UA_Wise_Query_Executed() {
        if (reports.ua_Wise_Query_Executed.isDisplayed()) {
            reports.ua_Wise_Query_Executed.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.ua_Wise_Query_Executed.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> Use Case Query Executed")
    public void userNavigatesToReports_Use_Case_Query_Executed() {
        if (reports.use_Case_Query_Executed.isDisplayed()) {
            reports.use_Case_Query_Executed.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.use_Case_Query_Executed.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Day Wise Request Response Summary")
    public void userNavigatesToReports_UA_Wise_Day_Wise_Request_Response_Summary() {
        if (reports.user_Agency_Wise_Day_Wise_Request_Response_Summary.isDisplayed()) {
            reports.user_Agency_Wise_Day_Wise_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.user_Agency_Wise_Day_Wise_Request_Response_Summary.should(Condition.enabled).click();
        }

    }

    @When("user navigates to AdminPortal -> Reports -> PO Wise Day Wise Request Response Summary")
    public void userNavigatesToReports_PO_Wise_Day_Wise_Request_Response_Summary() {
        if (reports.po_Wise_Request_Response_Summary.isDisplayed()) {
            reports.po_Wise_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.po_Wise_Request_Response_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> User Wise High Query Count")
    public void userNavigatesToReports_User_Wise_High_Query_Count() {
        if (reports.user_Wise_High_Query_Count.isDisplayed()) {
            reports.user_Wise_High_Query_Count.should(Condition.enabled).click();
//            Assert.assertTrue(false); // To Be Removed
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.user_Wise_High_Query_Count.should(Condition.enabled).click();
        }
    }


    @When("user navigates to AdminPortal -> Reports -> Day Wise Request Response Summary")
    public void userNavigatesToReports_Day_Wise_Request_Response_Summary() {
        if (reports.day_Wise_Request_Response_Summary.isDisplayed()) {
            reports.day_Wise_Request_Response_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.day_Wise_Request_Response_Summary.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Month Wise")
    public void userNavigatesToReports_UA_Wise_Month_Wise() {
        if (reports.ua_Wise_Month_Wise.isDisplayed()) {
            reports.ua_Wise_Month_Wise.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.ua_Wise_Month_Wise.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Data Sharing")
    public void userNavigatesToReports_UA_Wise_Data_Sharing() {
        if (reports.ua_Wise_Data_Sharing.isDisplayed()) {
            reports.ua_Wise_Data_Sharing.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.ua_Wise_Data_Sharing.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> PO Wise Month Wise")
    public void userNavigatesToReports_PO_Wise_Month_Wise() {
        if (reports.po_Wise_Month_Wise.isDisplayed()) {
            reports.po_Wise_Month_Wise.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.po_Wise_Month_Wise.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Use Case Statistics")
    public void userNavigatesToReports_UA_Wise_Case_Statistics() {
        if (reports.ua_Wise_Case_Statistics.isDisplayed()) {
            reports.ua_Wise_Case_Statistics.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.ua_Wise_Case_Statistics.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UnResponded")
    public void userNavigatesToReports_UnResponded() {
        if (reports.un_responded.isDisplayed()) {
            reports.un_responded.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.un_responded.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> Migration Status")
    public void userNavigatesToReports_Migration_Status() {
        if (reports.migration_Status.isDisplayed()) {
            reports.migration_Status.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.migration_Status.should(Condition.enabled).click();
        }
    }

    @Then("user loads report with default values")
    public void userLoadsReportWithDefaultValues() throws InterruptedException {
        Thread.sleep(5000);
        if(reports.reportSubmit.isDisplayed()) {
            executeJavaScript("arguments[0].click();",reports.reportSubmit );
        }
        Thread.sleep(2000);
        reports.SPINNER_CIRCLE_ICON.shouldNotBe(Condition.visible, Duration.ofMinutes(5));
        TakeScreenshot();

    }




    @When("user navigates to AdminPortal -> Reports -> Day Wise ER Request Summary")
    public void Day_Wise_ER_Request_Summary(){

        if (reports.Day_Wise_ER_Request_Summary.isDisplayed()) {
            reports.Day_Wise_ER_Request_Summary.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.Day_Wise_ER_Request_Summary.should(Condition.enabled).click();
        }

    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise Role Wise User Details")
    public void UA_Wise_Role_Wise_User_Details(){
        if (reports.UA_Wise_Role_Wise_User_Details.isDisplayed()) {
            reports.UA_Wise_Role_Wise_User_Details.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.UA_Wise_Role_Wise_User_Details.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports -> UA Wise PO Wise Failed Query Statistics")
    public void UA_Wise_PO_Wise_Failed_Query_Statistics(){
        if (reports.UA_Wise_PO_Wise_Failed_Query_Statistics.isDisplayed()) {
            reports.UA_Wise_PO_Wise_Failed_Query_Statistics.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.UA_Wise_PO_Wise_Failed_Query_Statistics.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports ->  Use Case Master")
    public void Use_Case_Master(){
        if (reports.Use_Case_Master.isDisplayed()) {
            reports.Use_Case_Master.should(Condition.enabled).click();
        } else {
            admin_dashboard.reports.should(Condition.enabled).click();
            reports.Use_Case_Master.should(Condition.enabled).click();
        }
    }

    @When("user navigates to AdminPortal -> Reports ->  Use Case Master ->  Use Case Master")
    public void Use_Case_Master_Tab(){

        reports.useCaseMasterTab.should(Condition.appear).click();
    }


    @When("user navigates to AdminPortal -> Reports ->  Use Case Master ->  Use Case Mapping UA Wise")
    public void Use_Case_Mapping_UA_Wise(){

        reports.Use_Case_Mapping_UA_Wise.should(Condition.appear).click();

    }

    @And("user should be able to download xlxs report")
    public void downloadXlxsReport() throws InterruptedException {
        Thread.sleep(2000);
        if(reports.xlxsReport.isDisplayed()) {
            reports.xlxsReport.should(Condition.visible).click();
        }
        else{
            scenario.log("No Data Found !!!!!!!!!!!!!!!!! ");
        }
        Thread.sleep(2000);
    }



    @And("user should be able to download pdf report")
    public void downloadPdfReport() throws InterruptedException {

        String userPassword ="Natgrid@123456";
        if(reports.xlxsReport.isDisplayed()) {

            reports.pdfReport.should(Condition.visible).click();
            reports.userPassword.setValue(userPassword);
            if(reports.saveBtn.isDisplayed()) {
                executeJavaScript("arguments[0].click();", reports.saveBtn.should(Condition.enabled));
                Thread.sleep(3000);
            }
            else{
                executeJavaScript("arguments[0].click();", reports.SaveBtn_Admin.shouldBe(Condition.enabled));
                Thread.sleep(3000);
            }
        }
        else{
            scenario.log("No Data Found !!!!!!!!!!!!!!!!! ");
        }
    }



    @And("user should be able to download pdf report save")
    public void downloadPdfReportSave() throws InterruptedException {

        String userPassword ="Natgrid@123456";
        if(reports.xlxsReport.isDisplayed()) {

            reports.pdfReport.should(Condition.visible).click();
            reports.userPassword.setValue(userPassword);
            if(reports.saveBtnPdf.isDisplayed()) {
                reports.saveBtnPdf.should(Condition.enabled).click();
                Thread.sleep(3000);
            }
            else{
                reports.SaveBtn_Admin.shouldBe(Condition.enabled).click();
                Thread.sleep(3000);
            }
        }
        else{
            scenario.log("No Data Found !!!!!!!!!!!!!!!!! ");
        }
    }




}