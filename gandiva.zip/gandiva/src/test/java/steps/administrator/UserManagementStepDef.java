/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.administrator;

import PageObject.AdminPortal.UserManagement.ProfileUpdate;
import PageObject.AdminPortal.UserManagement.Users;
import PageObject.AdminPortal.UserManagement.UserManagement;
import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import java.util.HashMap;
import java.util.Map;

import static steps.CommonStepDef.ElementScreenshot;
import static utils.Highlighter.highlight;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class UserManagementStepDef {
    @Autowired
    private Admin_dashboard admin_dashboard;
    @Autowired
    private UserManagement admin_userManagement;

    @Autowired
    private CommonElements commonElements;

    @Autowired
    private Users users;

    @Autowired
    private ProfileUpdate profileUpdate;

    @Autowired
            private SelectDropDownValue selectDropDownValue;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;



    ScenarioContext scenarioContext = new ScenarioContext();


    Map<String, Integer> map_nodal = new HashMap<String, Integer>();



    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


    @When("user navigates to AdminPortal -> User Management -> Users")
    public void userNavigatesToUserManagement_Users() throws InterruptedException {

        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {
            admin_dashboard.bar_UserManagement_Users.should(Condition.appear).click();
        } else {
            admin_dashboard.bar_UserManagement.should(Condition.appear).click();
            admin_dashboard.bar_UserManagement_Users.should(Condition.appear).click();
        }
    }

    @When("user navigates to AdminPortal -> User Management -> Users -> Admin Users")
    public void userNavigatesToUserManagement_AdminUsers() throws InterruptedException {

        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {
            admin_dashboard.bar_UserManagement_Users.should(Condition.appear).click();
        } else {
            admin_dashboard.bar_UserManagement.should(Condition.appear).click();
            admin_dashboard.bar_UserManagement_Users.should(Condition.appear).click();
        }
           admin_dashboard.adminUsers.should(Condition.appear).click();

    }


    @When("user navigates to AdminPortal -> User Management -> Profile Updates-Approvals")
    public void userNavigatesToUserManagement_Profile_Updates_Approvals() {
        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {
            admin_dashboard.profile_Updates_Approvals.should(Condition.enabled).click();
        } else {
            admin_dashboard.bar_UserManagement.should(Condition.enabled).click();
            admin_dashboard.profile_Updates_Approvals.should(Condition.enabled).click();

        }
    }

    @When("user navigates to AdminPortal -> User Management -> Unblock Users")
    public void userNavigatesToUserManagement_Unblock_Users() {
        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {
            admin_userManagement.unblockUsers.should(Condition.enabled).click();
        } else {
            admin_dashboard.bar_UserManagement.should(Condition.enabled).click();
            admin_userManagement.unblockUsers.should(Condition.enabled).click();

        }
    }

    @When("user navigates to AdminPortal -> User Management -> Password Reset Requests")
    public void userNavigatesToUserManagement_Password_Reset_Requests() {
        if (admin_dashboard.bar_UserManagement.is(Condition.selected)) {
            admin_userManagement.unblockUsers.should(Condition.enabled).click();
        } else {
            admin_dashboard.bar_UserManagement.should(Condition.enabled).click();
            admin_userManagement.unblockUsers.should(Condition.enabled).click();

        }
    }




    @And("user searches Name {string} and login id {string} from table and update NewName, email, mobile and address")
    public void UpdateAdminUser(String LoginId, String Name ) throws InterruptedException {

        String NewName = RandomUtils.generateUniqueAlphabetName();
        String EmailId = RandomUtils.generateRandomEmail();
        String Mobile = RandomUtils.generateRandomMobileNumber(10);
        String Address = RandomUtils.generateUniqueAlphabetName();

        RandomUtils.sendHumanKeys(admin_userManagement.search, Name);
        highlight(admin_userManagement.search,"green");
        Thread.sleep(3000);
        int colIndex = users.admin_user_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = users.admin_user_Mgmt_table.getRowIndexByColumnContainingText("LOGIN ID", LoginId);
        users.admin_user_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        Thread.sleep(5000);
        users.nodalName.clear();
        RandomUtils.sendHumanKeys(users.nodalName, NewName);
        users.nodalEmailId.clear();
        RandomUtils.sendHumanKeys(users.nodalEmailId, EmailId);
        users.nodalContactNo.clear();
        RandomUtils.sendHumanKeys(users.nodalContactNo, Mobile);
        users.nodalAddress.clear();
        RandomUtils.sendHumanKeys(users.nodalAddress, Address);
        users.nodalUpdate.should(Condition.enabled).click();




    }

     @Then("user should get success toast message")
       public void nodalUpdateToast(){

        String successToastMessage = admin_userManagement.ToastMessage.getText();
        ElementScreenshot(admin_userManagement.ToastMessage);
         Assert.assertEquals("User updated sucessfully", successToastMessage);

    }

    @Then("Admin user should get profile update success toast message")
    public void profileUpdateToast(){

        String successToastMessage = profileUpdate.ToastMessage.getText();
        ElementScreenshot(profileUpdate.ToastMessage);
        Assert.assertEquals("Profile update request approved sucessfully", successToastMessage);

    }

    @Then("Admin user should get success toast message")
    public void adminUpdateToast(){

        String successToastMessage = users.ToastMessage.getText();
        ElementScreenshot(users.ToastMessage);
        Assert.assertEquals("User updated sucessfully", successToastMessage);

    }

        @Then("user should get success message user created successfully")
        public void nodalCreationSuccessMessage(){

            String successToastMessage = admin_userManagement.ToastMessage.getText();
            ElementScreenshot(admin_userManagement.ToastMessage);
            Assert.assertEquals("User created sucessfully.", successToastMessage);
        }


        @And("User enters required details and click on submit to create admin user")
        public void createAdminUser(){
            String Name = RandomUtils.generateUniqueAlphabetName();
            String EmailID = RandomUtils.generateRandomEmail();
            String ContactNo = RandomUtils.generateRandomMobileNumber(10);
            String Address = RandomUtils.generateUniqueAlphabetName();
            String LoginID = RandomUtils.generateUniqueAlphabetName();

            admin_userManagement.addAdminUser.should(Condition.appear).click();
            RandomUtils.sendHumanKeys(admin_userManagement.nodalName, Name);
            RandomUtils.sendHumanKeys(admin_userManagement.nodalLoginID, LoginID);
            RandomUtils.sendHumanKeys(admin_userManagement.nodalEmailId, EmailID);
            RandomUtils.sendHumanKeys(admin_userManagement.nodalContactNo, ContactNo);
            RandomUtils.sendHumanKeys(admin_userManagement.nodalAddress, Address);
            admin_userManagement.nodalSubmit.should(Condition.appear).click();

        }

        @Then("user should get success message admin user created successfully")
        public void adminCreationSuccessMessage(){

            String successToastMessage = admin_userManagement.ToastMessage.getText();
            ElementScreenshot(admin_userManagement.ToastMessage);
            Assert.assertEquals("Admin User created sucessfully.", successToastMessage);

        }

        @When("Nodal officer update profile details enters remark {string} and send for approval to admin")
        public void NodalProfileUpdate(String remark){

            String EmailID = RandomUtils.generateRandomEmail();
            String ContactNo = RandomUtils.generateRandomMobileNumber(10);

             profileUpdate.nodalOfficer.should(Condition.appear).click();
             profileUpdate.profileMenu.should(Condition.appear).click();
             profileUpdate.editProfile.should(Condition.appear).click();
             profileUpdate.emailIDField.clear();
             profileUpdate.emailIDField.sendKeys(EmailID);
             profileUpdate.mobileField.clear();
             profileUpdate.mobileField.sendKeys(ContactNo);
             profileUpdate.profileUpdateRemark.sendKeys(remark);
             profileUpdate.profileUpdateButton.should(Condition.appear).click();
             profileUpdate.confirmationYes.should(Condition.appear).click();

            scenarioContext.setContext(Context.ContactNo, ContactNo);
        }

        @And("nodal logout from UA portal")
        public void NodalLogout(){

        profileUpdate.nodalOfficer.should(Condition.appear).click();
        profileUpdate.signoutMenu.should(Condition.appear).click();


        }

        @And("Admin user approves the request")
        public void AdminApprovesProfileUpdateRequest(){

        String ContactNo = scenarioContext.getContext(Context.ContactNo).toString();
        RandomUtils.sendHumanKeys(profileUpdate.searchField, ContactNo);
        profileUpdate.approveButton.should(Condition.appear).click();
        profileUpdate.confirmationAdminYes.should(Condition.appear).click();

        }
    @And("Admin user rejects the request")
    public void AdminRejectsProfileUpdateRequest(){

        String ContactNo = scenarioContext.getContext(Context.ContactNo).toString();
        RandomUtils.sendHumanKeys(profileUpdate.searchField, ContactNo);
        profileUpdate.rejectButton.should(Condition.appear).click();
        profileUpdate.confirmationAdminYes.should(Condition.appear).click();

    }
}