package steps.administrator;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import PageObject.AdminPortal.OrgTypeMgmt.AddOrgTypeMgmt;
import PageObject.AdminPortal.OrgTypeMgmt.OrgTypeMgmt;
import PageObject.AdminPortal.RoleMgmt.RoleMgmt;
import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;

import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.ElementScreenshot;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;
//import org.testng.Assert;

@ExtendWith({ScreenShooterExtension.class})
public class RoleMgmtStepDef {

    @Autowired
    private Admin_dashboard admin_dashboard;

    @Autowired
    private RoleMgmt roleMgmt;

    @Autowired
    private CommonElements commonElements;

    @Autowired
    private OrgTypeMgmt orgTypeMgmt;

    @Autowired
    private AddOrgTypeMgmt addOrgTypeMgmt;
    @Autowired
    private SelectDropDownValue selectDropDownValue;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;




    ScenarioContext scenarioContext = new ScenarioContext();

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    @Then("user update role for orgtype and user should get success toast message")
    public void user_update_role_authorized_officer_of_orgtype() throws InterruptedException {

        String alias = RandomUtils.generateUniqueAlphabetName();
        String description = "Description"+RandomUtils.generateUniqueAlphabetName();

        String orgType = scenarioContext.getContext(Context.orgType).toString();
        String roleName = scenarioContext.getContext(Context.roleName).toString();

        roleMgmt.btn_RoleManagement.click();
        RandomUtils.sendHumanKeys(roleMgmt.field_Search, orgType);
        highlight(roleMgmt.field_Search,"green");
        Thread.sleep(3000);
        int colIndex = roleMgmt.role_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = roleMgmt.role_Mgmt_table.getRowIndexByColumnContainingText("ROLE NAME", roleName);
        roleMgmt.role_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        Thread.sleep(3000);
        roleMgmt.field_OrgType.click();
        selectDropDownValue.toSelectDropDown(roleMgmt.orgTypeList, orgType);
        roleMgmt.field_RoleName.click();
        roleMgmt.field_RoleAlias.clear();
        roleMgmt.field_RoleAlias.setValue(alias);
        roleMgmt.field_RoleDescription.clear();
        roleMgmt.field_RoleDescription.setValue(description);
        roleMgmt.btn_Update.should(Condition.visible).click();
            String successToastMessage = roleMgmt.toastMessage.getText();
            ElementScreenshot(roleMgmt.toastMessage);
         Assert.assertEquals("Role Updated Successfully", successToastMessage);
    }

    @And("Logout from the ADMIN portal")
    public void adminLogout() throws InterruptedException {
        Thread.sleep(3000);
        roleMgmt.adminLoginTab.should(Condition.visible).click();
        roleMgmt.adminLogout.should(Condition.visible).click();

    }


    @And("Admin user should able to add new OrgType")          //user add new Org Type
    public void user_add_for_Org_Type() throws InterruptedException {
        addOrgTypeMgmt.btn_AddOrgType.click();
        addOrgTypeMgmt.OrgType.should(Condition.appear);

        String orgType = "Org Type"+RandomUtils.generateUniqueAlphabetName();
        String alias = RandomUtils.generateUniqueAlphabetName();
        String description = "Description"+RandomUtils.generateUniqueAlphabetName();

        if (orgType.equalsIgnoreCase("") && alias.equalsIgnoreCase("")) {
            // Mandatory filed not entered . check for the Error messages.
            addOrgTypeMgmt.OrgType.click();
            addOrgTypeMgmt.Alias.click();
            addOrgTypeMgmt.Description.click();
        } else {

            RandomUtils.sendHumanKeys(addOrgTypeMgmt.OrgType, orgType);
            RandomUtils.sendHumanKeys(addOrgTypeMgmt.Alias, alias);
            RandomUtils.sendHumanKeys(addOrgTypeMgmt.Description, description);
            addOrgTypeMgmt.Submit.click();

            scenarioContext.setContext(Context.orgType, orgType);
            scenarioContext.setContext(Context.alias, alias);
            scenarioContext.setContext(Context.description, description);
            Thread.sleep(2000);


        }
    }


    @And("Search created org type in table")
    public void searchCreatedOrgType(){

       String OrgType = scenarioContext.getContext(Context.orgType).toString();
       addOrgTypeMgmt.SearchOrgType.setValue(OrgType);
       highlight(addOrgTypeMgmt.firstRowofTable, "green");
        TakeScreenshot();

    }

    @And("user add Org Type, Alias and Description which already exists")
//user add for Org Type
    public void user_add_Org_Type_which_already_exists() throws InterruptedException {
        String orgType = scenarioContext.getContext(Context.orgType).toString();
        String alias = scenarioContext.getContext(Context.alias).toString();
        String description = scenarioContext.getContext(Context.description).toString();

        addOrgTypeMgmt.btn_AddOrgType.click();
        Thread.sleep(2000);
        addOrgTypeMgmt.OrgType.setValue(orgType);
        addOrgTypeMgmt.Alias.setValue(alias);
        addOrgTypeMgmt.Description.setValue(description);

        addOrgTypeMgmt.Submit.click();
    }



    @Then("user should able to add new role with details like Role name, Role level {string}")
    public void addNewRole(String RoleLevel) throws InterruptedException {

        String orgType = scenarioContext.getContext(Context.orgType).toString();
        String alias = scenarioContext.getContext(Context.alias).toString();
        String description = scenarioContext.getContext(Context.description).toString();
        String roleName = RandomUtils.generateUniqueAlphabetName()+" Officer";

        roleMgmt.btn_AddRole.should(Condition.visible).click();
        Thread.sleep(2000);
        RandomUtils.sendHumanKeys(roleMgmt.field_RoleName, roleName);
       // roleMgmt.field_OrgType.shouldNotBe(Condition.visible, Duration.ofMinutes(2));
      //  roleMgmt.field_OrgType.click();
        executeJavaScript("arguments[0].click();",roleMgmt.field_OrgType);
        Thread.sleep(2000);
        selectDropDownValue.toSelectDropDown(roleMgmt.orgTypeList, orgType);
        Thread.sleep(2000);

        executeJavaScript("arguments[0].click();",roleMgmt.drop_RoleLevel);
      //  roleMgmt.drop_RoleLevel.click();
     //   Thread.sleep(2000);
        selectDropDownValue.toSelectDropDown(roleMgmt.roleLevelList, RoleLevel);
        Thread.sleep(2000);
        RandomUtils.sendHumanKeys(roleMgmt.field_RoleAlias, alias);
        RandomUtils.sendHumanKeys(roleMgmt.field_RoleDescription, description);
        roleMgmt.btn_Submit.should(Condition.enabled).click();
        roleMgmt.proceedBtn.should(Condition.appear).click();

        scenarioContext.setContext(Context.roleName, roleName);
        scenarioContext.setContext(Context.orgType, orgType);

    }


       @And("user should able to update role details for created roles")
       public void updateRole() throws InterruptedException {

          String orgType = scenarioContext.getContext(Context.orgType).toString();
           String roleName = scenarioContext.getContext(Context.roleName).toString();

           RandomUtils.sendHumanKeys(roleMgmt.field_Search, orgType);
           highlight(roleMgmt.field_Search,"green");
           Thread.sleep(3000);
           int colIndex = roleMgmt.role_Mgmt_table.getColumnIndexByColumnName("ACTION");
           int rownumber = roleMgmt.role_Mgmt_table.getRowIndexByColumnContainingText("ROLE NAME", roleName);
           roleMgmt.role_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
           roleMgmt.field_RoleName.click();
           roleMgmt.field_OrgType.click();
           Thread.sleep(3000);
           selectDropDownValue.toSelectDropDown(roleMgmt.orgTypeList, orgType);

           roleMgmt.field_RoleAlias.click();
           roleMgmt.btn_Update.should(Condition.enabled).click();

        }




    @And("Admin user should get success toast message that role created successfully")
    public void roleCreationSuccessMessage() throws IOException {

        String successToastMessage = roleMgmt.toastMessage.getText();
        ElementScreenshot(roleMgmt.toastMessage);
        Assert.assertEquals("Role Created Successfully", successToastMessage);


    }

}
