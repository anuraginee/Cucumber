//package steps;
//
//import PageObject.*;
//import com.codeborne.selenide.Configuration;
//import com.codeborne.selenide.WebDriverRunner;
//import com.codeborne.selenide.junit5.ScreenShooterExtension;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.jupiter.api.*;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.remote.DesiredCapabilities;
//
//import java.util.HashMap;
//
//import static com.codeborne.selenide.Condition.visible;
//import static com.codeborne.selenide.Selenide.*;
//
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
//@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
//
//public class BaseTest {
//    @RegisterExtension
//    static ScreenShooterExtension screenshotEmAll = new ScreenShooterExtension(true).to("resources/screenshots");
//
//    @Before
//    void setup() {
//        WebDriverRunner.getWebDriver().manage().window().maximize();
//    }
//
//    @After
//    void tearDown() {
//        closeWebDriver();
//    }
//}