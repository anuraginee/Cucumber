/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package steps.ua;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Agency_Mart.Agency_Mart_Approval_Page;
import PageObject.UserAgentPortal.Agency_Mart.Agency_Mart_Page;
import PageObject.UserAgentPortal.CaseManagement.Advanced_Search.Advanced_Search_Page;
import PageObject.UserAgentPortal.CaseManagement.Case_Owner_Revoke;
import PageObject.UserAgentPortal.CaseManagement.Case_Participants;
import PageObject.UserAgentPortal.CaseManagement.Cases;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover.ER_Search;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover.Image_Search;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover.UseCase_Search;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.ViewCase_Discover;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.ViewCase_Entity_Profile;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.ViewCase_Notes;
import PageObject.UserAgentPortal.CaseManagement.ViewCase.ViewCase_UseCaseSearch;
import PageObject.UserAgentPortal.CaseRelatedApprovals.Case_Inititaion;
import PageObject.UserAgentPortal.CaseRelatedApprovals.Case_ReOpen;
import PageObject.UserAgentPortal.CaseRelatedApprovals.Case_Transfer;
import PageObject.UserAgentPortal.CaseRelatedApprovals.Cases_Close;
import PageObject.UserAgentPortal.Common_Mart.Common_Mart_Approval_Page;
import PageObject.UserAgentPortal.Dashboard.Cases_table;
import PageObject.UserAgentPortal.Dashboard.Pending_Case_Level_Requests;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import PageObject.UserAgentPortal.Scheduled_Query.Active_Scheduled_Queries;
import PageObject.UserAgentPortal.Scheduled_Query.Create_Scheduled_Query;
import PageObject.UserAgentPortal.Scheduled_Query.Pending_For_Approval;
import PageObject.UserAgentPortal.Scheduled_Query.Scheduled_Query;
import PageObject.UserAgentPortal.Scheduled_Query_Related_Approval.Scheduled_Query_Approval;
import PageObject.UserAgentPortal.Scheduled_Query_Related_Approval.Scheduled_Query_Recommendation;
import PageObject.UserAgentPortal.UA_Case_Management;
import PageObject.UserAgentPortal.UseCaseApprovals.CaseApproval;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.Notification.Notification;
import utils.PropertyUtils;
import utils.RandomUtils;
import utils.ScenarioContext;
import utils.SelectDropDown.SelectDropDownValue;
import utils.enums.CASE_ACTIONS;
import utils.enums.Sharing_Actions;
import utils.enums.CASE_ATTRIBUTES;
import utils.enums.DASHBOARD_WIDGETS;
import utils.enums.Notification_List;
import utils.excelRead.Excel_Hashmap;
import utils.table.tableImpl;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.executeJavaScript;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.*;
import static java.lang.Integer.parseInt;
import static steps.CommonStepDef.ElementScreenshot;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;


@ExtendWith({ScreenShooterExtension.class})
public class caseManagementStepDef {
    @Autowired
    private UA_dashboard ua_dashboard;
    @Autowired
    private Agency_Mart_Page AgencyMartPage;
    @Autowired
    private UA_Case_Management ua_Case_Management;
    @Autowired
    private Cases cases;
    @Autowired
    private Case_Inititaion case_initiation;
    @Autowired
    private Cases_Close case_close;
    @Autowired
    private Case_Transfer case_transfer;
    @Autowired
    private SelectDropDownValue selectDropDownValue;
    @Autowired
    private Pending_Case_Level_Requests pending_Case_Level_Requests;

    @Autowired
    private ViewCase_Discover viewCase_discover;
    @Autowired
    private CommonElements commonElements;

    @Autowired
    private ViewCase_Entity_Profile EntityProfile;
    @Autowired
    private Case_Owner_Revoke caseownerevoke;
    @Autowired
    private Advanced_Search_Page AdvancedSearchPage;

    @Autowired
    private Cases_table cases_table;

    @Autowired
    private ER_Search ER_search;

    @Autowired
    private Image_Search Image_search;
    @Autowired
    private ViewCase_Entity_Profile ViewCaseEntityProfile;

    @Autowired
    private Agency_Mart_Approval_Page AgencyMartApprovalPage;
    @Autowired
    private Case_ReOpen case_reopen;
    @Autowired
    private Common_Mart_Approval_Page common_mart_approval_page;

    @Autowired
    private UseCase_Search usecasesearch;
    @Autowired
    private Notification notification;
    @Autowired
    private Case_Participants caseparticipants;
    @Autowired
    private ViewCase_Notes casenotes;

    @Autowired
    private Active_Scheduled_Queries activeScheduledQueries;

    @Autowired
    private Create_Scheduled_Query CreateScheduledQuery;

    @Autowired
    private Scheduled_Query ScheduledQuery;
    @Autowired
    private Pending_For_Approval pendingForApproval;
    @Autowired
    private Scheduled_Query_Approval Query_Approval;
    @Autowired
    private Scheduled_Query_Recommendation Recommendation_Approval;
    @Autowired
    private Excel_Hashmap Excel_Reader;
    @Autowired
    private Notification_List NotificationList;
    @Autowired
    private CaseApproval Case_Approval;
    @Autowired
    private ViewCase_UseCaseSearch UseCaseSearch;


    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");


    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext scenarioContext = new ScenarioContext();

    Map<String, Integer> map_auth = new HashMap<String, Integer>();
    Map<String, Integer> map_Supervisory = new HashMap<String, Integer>();
    Map<String, Integer> map_approving = new HashMap<String, Integer>();
    Map<String, Integer> map_nodal = new HashMap<String, Integer>();
    List<Map<String, String>> Map_data = new ArrayList<>();

    @When("user navigates to UAPortal -> Case management -> Cases")
    public void userNavigatesToMenuCase_management_cases() {
        if (ua_Case_Management.Cases.isDisplayed()) {
            ua_Case_Management.Cases.should(Condition.enabled).click();
        } else {
            ua_dashboard.case_Management.should(Condition.enabled).click();
            ua_Case_Management.Cases.should(Condition.enabled).click();
        }
    }

    @And("Click on Advanced Search Button")
    public void userNavigatesToAdvanced_Search() {
        cases.Advanced_Search.should(Condition.enabled).click();
        AdvancedSearchPage.Advanced_Search_Title.should(Condition.appear);
    }

    // Create new case
    @When("{string} create a new Case")
    public void theUserCreatesNewCase(String username) throws InterruptedException {
        cases.Cases.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", cases.Initiate_Case_button);
        String Tag_Name = "Anti_Terror";
        String[] parts = username.split("_");
        String Case_Name = parts[0] + RandomUtils.getUniqueNumber();
//        String Case_Name = parts[0] + RandomUtils.generateUniqueAlphabetName();
        scenario.log("Case Name : " + Case_Name);
        String Case_Physical_Digital_ID = RandomUtils.getTimeBasedUniqueNumber();
        String CaseDescription = "New Case created with Case Name: " + Case_Name + " Case Physical Digital ID: " + Case_Physical_Digital_ID;
        Thread.sleep(3000);

        cases.Case_Name.sendKeys(Case_Name);
        cases.physical_Digital_CaseId.sendKeys(Case_Physical_Digital_ID);
        cases.Case_Description.sendKeys(CaseDescription);
        cases.Tags.should(Condition.enabled).click();
        SelectDropDownValue.toSelectDropDown(cases.Tag_list, Tag_Name);
//        cases.AddTags.sendKeys("Automation_case");
        if (cases.Checkbox.isSelected()) {
            executeJavaScript("arguments[0].click();", cases.Submit_Button);
//            cases.Submit_Button.should(Condition.enabled).click();
        } else {
            cases.Checkbox.click();
            executeJavaScript("arguments[0].click();", cases.Submit_Button);
        }
//        cases.Yes_button.should(Condition.appear).click();
        executeJavaScript("arguments[0].click();", cases.Yes_button);

        if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
            cases.All_cases.should(Condition.enabled).click();
            cases.Cases.shouldBe(Condition.visible, Duration.ofMinutes(5));
            $(By.xpath("//div[text()='" + Case_Name + "']")).shouldBe(Condition.visible);
            scenarioContext.setContext(Context.CASENAME, Case_Name);

        } else {

            cases.All_cases.should(Condition.enabled).click();
            cases.Cases.shouldBe(Condition.visible, Duration.ofMinutes(10));
            $(By.xpath("//div[text()='" + Case_Name + "']")).shouldBe(Condition.visible);
            cases.Case_Name_Validation.shouldBe(Condition.visible);
            String Case_ID_Value = cases.Case_ID(Case_Name).getText();
            scenario.log("Case ID : " + Case_ID_Value);
            String Case_Date_Time = cases.Case_Date_Time(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).shouldBe(Condition.visible).getText();
            scenario.log("Case Creation Date and Time : " + Case_Date_Time);
            scenarioContext.setContext(Context.CASENAME, Case_Name);
            scenarioContext.setContext(Context.CASEID, Case_ID_Value);
            scenarioContext.setContext(Context.Current_Date_Time, Case_Date_Time);
            cases.Cases.shouldBe(Condition.visible).click();
        }
    }


    @And("Validate the relevant error messages when user enters invalid case details or leave any of the field empty in mandatory fields as well as non-mandatory fields")
    public void ValidateErrorMessages() throws InterruptedException {
        Thread.sleep(2000);
        cases.Cases.shouldBe(Condition.visible);
//        highlight(cases.Initiate_Case_button,"Green");
        executeJavaScript("arguments[0].click();", cases.Initiate_Case_button);
        cases.Case_Name.sendKeys("");
        cases.physical_Digital_CaseId.click();
        cases.CaseName_Error_Message.should(Condition.visible);
        Assert.assertEquals("Please enter case name", cases.CaseName_Error_Message.getText());
        cases.physical_Digital_CaseId.sendKeys("");
        cases.Case_Description.click();
        cases.Physical_Digital_Case_ID_Error_message.should(Condition.visible);
        Assert.assertEquals("Please enter physical digital case ID", cases.Physical_Digital_Case_ID_Error_message.getText());
        cases.Case_Description.sendKeys("");
        cases.Tags.click();
        cases.Description_Error_Message.should(Condition.visible);
        Assert.assertEquals("Please enter description", cases.Description_Error_Message.getText());
        cases.Tags.should(Condition.enabled).sendKeys("dssssssssssssssss");
        cases.Checkbox.click();
        cases.Tags.should(Condition.enabled).sendKeys("dss");
        cases.Tag_Error_message.should(Condition.visible);
        Assert.assertEquals("Tag type name not recognized. Click one of the autocomplete options.", cases.Tag_Error_message.getText());
//        cases.Cancel_Button.should(Condition.visible).click();
        executeJavaScript("arguments[0].click();", cases.Cancel_Button);
    }

    @Then("User validates the case initiation request under Manage Case -> All Cases.")
    public void ValidateNewCase() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        scenario.log("Case Name : " + Case_Name);
        highlight(cases.Case_Name_Validation, "green").shouldBe(Condition.visible);
        if (cases.Case_Name_Validation.isDisplayed()) {
            Assert.assertEquals(Case_Name, cases.Case_Name_Validation.getText());
        }
        validateStatusOfCase();
    }

//    public void validateStatusOfCase() throws InterruptedException {
//        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
//
//        if (cases.User_role.getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {
//            Assert.assertEquals("Case Request Submitted", cases.getCaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).should(Condition.appear).getText());
//
//        } else if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
//            Assert.assertEquals("Case Approved", cases.getCaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.CASE_APPROVED.getAttributes().toString()).shouldBe(Condition.visible).getText());
//
//        } else if (cases.User_role.getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {
//            Assert.assertEquals("Case Request Submitted", cases.getCaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).shouldBe(Condition.visible).getText());
//        }
//
//    }

    public void validateStatusOfCase() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();

        if (cases.User_role.getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {
            Assert.assertEquals("Case Request Submitted", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).should(Condition.appear).getText());

        } else if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
            Assert.assertEquals("Case Approved", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_APPROVED.getAttributes().toString()).shouldBe(Condition.visible).getText());

        } else if (cases.User_role.getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {
            Assert.assertEquals("Case Request Submitted", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).shouldBe(Condition.visible).getText());
        }

    }

    @And("User searches for Case_Name under the pending_Case_for_Approval table")
    public void CaseUnderPendingCaseApprovalTable() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        if (cases.User_role.getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {
            ua_dashboard.bar_dashboard.shouldBe(Condition.visible);
            ua_dashboard.bar_dashboard.click();
            executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName()));
//            pending_Case_Level_Requests.Raised_On.shouldBe(Condition.visible).click();
//            pending_Case_Level_Requests.Raised_On.shouldBe(Condition.visible).click();
            pending_Case_Level_Requests.SPINNER_THREE_DOTS_ICON.shouldNotBe(Condition.visible, Duration.ofMinutes(5));
            cases.Search_bar.click();
            cases.Search_bar.should(Condition.enabled).sendKeys(Case_Name);
//            pending_Case_Level_Requests.Items_per_page.click();
//            pending_Case_Level_Requests.select_items_perPage("50").should(Condition.appear).click();
            // Wait for Case name to appear
            $(By.xpath("//div[contains(text(),'" + Case_Name + "')]")).should(Condition.appear);
            int colIndex = pending_Case_Level_Requests.Pending_Case_Level_Requests_table.getColumnIndexByColumnName("Case Name");
            System.out.println("Case_Name :" + Case_Name);
            int rowIndex = pending_Case_Level_Requests.Pending_Case_Level_Requests_table.getRowIndexByColumnContainingText("Case Name", Case_Name);
            System.out.println(colIndex);
            System.out.println(rowIndex);
            highlight(pending_Case_Level_Requests.Pending_Case_Level_Requests_table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(Case_Name, pending_Case_Level_Requests.Pending_Case_Level_Requests_table.get_Cell_ByIndex(rowIndex, colIndex).getText());

        }
        if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
            ua_dashboard.bar_dashboard.shouldBe(Condition.visible);
            ua_dashboard.bar_dashboard.click();
            executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
            final tableImpl Case_table = new tableImpl($(By.xpath("//*[contains(@class,'cdk-table') and @role='table']")).should(Condition.appear));
            int colIndex = Case_table.getColumnIndexByColumnName("Case Name");
            System.out.println("Case Name :" + Case_Name);
            int rowIndex = Case_table.getRowIndexByColumnContainingText("Case Name", Case_Name.toString());
            highlight(Case_table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(Case_Name, Case_table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        }
//            Comment this Section for GANDIVA UA portal Dashboard defect. Defect Ids For Dashboard: 261,262,263

//            else if (cases.User_role.getText().equalsIgnoreCase("SUPERVISORY OFFICER")){
//                highlight(ua_dashboard.bar_dashboard, "green").shouldBe(Condition.visible);
//                ua_dashboard.bar_dashboard.click();
//                cases.Super_Pending_Case_Level_Requests_ViewAll.click();
//                cases.Appr_Created_On.shouldBe(Condition.visible);
//                cases.Appr_Created_On.click();
//                cases.Appr_Created_On.click();
//                highlight(cases.Super_Physical_ID_Pending_Case_Level_Requests, "green").shouldBe(Condition.visible);
//                Assert.assertEquals(Case_Physical_Digital_ID, cases.Super_Physical_ID_Pending_Case_Level_Requests.getText());
//            }
    }

    @And("Click on My profile -> Get the Login Id Details")
    public void My_Profile() throws InterruptedException {
        cases.User_role.click();
        cases.User_Profile.click();
        cases.My_Profile_Title.should(Condition.visible);
        scenarioContext.setContext(Context.Approver_User_Role, cases.Login_ID.should(Condition.visible).getText());
    }

    @And("User takes the snapshot of all widgets count present on Dashboard page")
    public void DashboardSnapshot() throws InterruptedException {

        if (cases.User_role.isDisplayed()) {
            commonElements.Vertical_Loader.shouldNotBe(visible);
            if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

                WebDriver driver = WebDriverRunner.getWebDriver();

                new WebDriverWait(driver, Duration.ofMinutes(7)).until(
                        webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
                Thread.sleep(20000);
                map_auth.put(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
                map_auth.put(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
                map_auth.put(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
                map_auth.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
                map_auth.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getParamName()).getText()));
            } else if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

                WebDriver driver = WebDriverRunner.getWebDriver();

                new WebDriverWait(driver, Duration.ofMinutes(7)).until(
                        webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
                Thread.sleep(20000);
                map_approving.put(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName()).getText()));
                map_approving.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName()).getText()));
            } else if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

                WebDriver driver = WebDriverRunner.getWebDriver();

                new WebDriverWait(driver, Duration.ofMinutes(7)).until(
                        webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
                Thread.sleep(20000);

                map_Supervisory.put(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName()).getText()));
                map_Supervisory.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName()).getText()));
            } else if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

                WebDriver driver = WebDriverRunner.getWebDriver();

                new WebDriverWait(driver, Duration.ofMinutes(7)).until(
                        webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
                Thread.sleep(20000);
                map_nodal.put(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Initiation.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Close.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_ReOpen.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Transfer.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Transfer.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Transfer.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Transfer.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getParamName()).getText()));
                map_nodal.put(DASHBOARD_WIDGETS.TRANSFERREDCASES_Closed.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_Closed.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_Closed.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_Closed.getParamName()).getText()));
            }
        }
        TakeScreenshot();
    }


    @And("Click on Notification button, to check the Notification")
    public void UA_PortalNotification() throws InterruptedException, IOException {
        String UserRole = scenarioContext.getContext(Context.Approver_User_Role).toString();
        notification.Notification_Work_Flow();
        tableImpl Notification_Table = new tableImpl($(By.xpath("//table[@role='table' and @ng-reflect-data-source='[object Object]']")).should(Condition.appear));
        String Date_time = scenarioContext.getContext(Context.Current_Date_Time).toString();
        String Case_ID = scenarioContext.getContext(Context.CASEID).toString();
        Thread.sleep(4000);
        int Notification_colIndex = Notification_Table.getColumnIndexByColumnName("Notification");
        int Notification_rowIndex = Notification_Table.getRowIndexByColumnContainingText("Date", Date_time);
        highlight(Notification_Table.get_Cell_ByIndex(Notification_rowIndex, Notification_colIndex), "green");
        String Notification = Notification_Table.get_Cell_ByIndex(Notification_rowIndex, Notification_colIndex).getText();
        System.out.println("Notification from Application : " + Notification);
        String Module = String.valueOf(Excel_Reader.Read_Module_Names());
        if (Module.contains("Case Initiation")) {
            Case_Initiation_Notification(Notification, Case_ID, UserRole, Date_time, Notification_Table);
        } else if (Module.contains("Case Close")) {
            Case_Close_Notification(Notification, Case_ID, UserRole, Date_time, Notification_Table);
        }
        final SelenideElement Notification_Mark_As_Read = $(By.xpath("(//mat-icon[@mattooltip=\"Mark as read\"])[1]"));
        Notification_Mark_As_Read.click();
    }

    public void Case_Initiation_Notification(String Notification, String Case_ID, String UserRole, String Date_time, tableImpl Notification_Table) throws InterruptedException, IOException {
        String Case_Description_Text = "";
        String Notification_Text = "";

        if (Notification.contains(NotificationList.Case_Initiation_Request.getNotification().toString())) {
            Case_Description_Text = String.valueOf(Excel_Reader.Case_Related_Notification_From_Hashmap("Case Initiation", "Case Initiation request for Case ID", Case_ID, UserRole));
            scenario.log("Notification from Excel Sheet : " + Case_Description_Text);
            Assert.assertEquals(Case_Description_Text, Notification);
            int colIndex = Notification_Table.getColumnIndexByColumnName("Date");
            int rowIndex = Notification_Table.getRowIndexByColumnContainingText("Notification", Date_time);
            highlight(Notification_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(Date_time, Notification_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
            TakeScreenshot();
        } else if (Notification.contains(NotificationList.Case_Initiation_Request_Approved_Rejected.getNotification().toString())) {
            String Case_Status = scenarioContext.getContext(Context.Case_Status).toString();
            Case_Description_Text = String.valueOf(Excel_Reader.Case_Related_Notification_From_Hashmap("Case Initiation", "Initiation request for Case ID", Case_ID, UserRole));
            if (Case_Status.equalsIgnoreCase("Approved")) {
                Notification_Text = Case_Description_Text.replace("<<Approved/Rejected>>", Case_Status);
            } else if (Case_Status.equalsIgnoreCase("Rejected")) {
                Notification_Text = Case_Description_Text.replace("<<Approved/Rejected>>", Case_Status);
            }
            Notification_Text = Notification_Text.replace("<<Role>>", UserRole);
            scenario.log("Notification from Excel Sheet : " + Notification_Text);
            Assert.assertEquals(Notification_Text, Notification);
            int colIndex = Notification_Table.getColumnIndexByColumnName("Date");
            int rowIndex = Notification_Table.getRowIndexByColumnContainingText("Notification", Date_time);
            highlight(Notification_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(scenarioContext.getContext(Context.Current_Date_Time).toString(), Notification_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
            TakeScreenshot();
        }

    }

    public void Case_Close_Notification(String Notification, String Case_ID, String UserRole, String Date_time, tableImpl Notification_Table) throws InterruptedException, IOException {
        String Case_Description_Text = "";
        String Notification_Text = "";

        if (Notification.contains(NotificationList.Case_Close_Request.getNotification().toString())) {
            Case_Description_Text = String.valueOf(Excel_Reader.Case_Related_Notification_From_Hashmap("Case Initiation", NotificationList.Case_Close_Request.getNotification().toString(), Case_ID, UserRole));
            scenario.log("Notification from Excel Sheet : " + Case_Description_Text);
            Assert.assertEquals(Case_Description_Text, Notification);
            int colIndex = Notification_Table.getColumnIndexByColumnName("Date");
            int rowIndex = Notification_Table.getRowIndexByColumnContainingText("Notification", Date_time);
            highlight(Notification_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(Date_time, Notification_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
            TakeScreenshot();
        } else if (Notification.contains(NotificationList.Case_Close_Request_Approved_Rejected.getNotification().toString())) {
            String Case_Status = scenarioContext.getContext(Context.Case_Status).toString();
            Case_Description_Text = String.valueOf(Excel_Reader.Case_Related_Notification_From_Hashmap("Case Initiation", NotificationList.Case_Close_Request_Approved_Rejected.getNotification().toString(), Case_ID, UserRole));
            if (Case_Status.equalsIgnoreCase("Approved")) {
                Notification_Text = Case_Description_Text.replace("<<Approved/Rejected>>", Case_Status);
            } else if (Case_Status.equalsIgnoreCase("Rejected")) {
                Notification_Text = Case_Description_Text.replace("<<Approved/Rejected>>", Case_Status);
            }
            Notification_Text = Notification_Text.replace("<<Role>>", UserRole);
            scenario.log("Notification from Excel Sheet : " + Notification_Text);
            Assert.assertEquals(Notification_Text, Notification);
            int colIndex = Notification_Table.getColumnIndexByColumnName("Date");
            int rowIndex = Notification_Table.getRowIndexByColumnContainingText("Notification", Date_time);
            highlight(Notification_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
            Assert.assertEquals(scenarioContext.getContext(Context.Current_Date_Time).toString(), Notification_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
            TakeScreenshot();
        }

    }


    public void Case_Close_Notification() throws InterruptedException, IOException {

    }

    //  Check the count of Pending Case Level Requests Card component present in the UA dashboard page after creating the Case
    @And("Check the count of Pending Case Level Requests Card component present in the UA dashboard page")
    public void countPendingCaseLevelRequestsCardAfter() throws InterruptedException {

        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

            executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(20000);
            if ($(By.xpath("//div[text()='No data available']")).isDisplayed()) {
                executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));
            } else {
                int Pending_Case_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
                highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
                Assert.assertEquals(Pending_Case_Level_Total_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
                ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
            }
        }

//    No validation for Approving officer as case gets approved automatically for Approving Officer.


        else if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {
            executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Appr_Cases_Total = map_approving.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Appr_Cases_Total + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }

//            Commenting this Section for GANDIVA UA portal Dashboard defect. Defect Ids For Dashboard: 261,262,263

//        else if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {
//            highlight(ua_dashboard.bar_dashboard, "green").shouldBe(Condition.visible).click();

//       Adding sleep for system to wait till case related count in dashboard gets updated

//        Thread.sleep(8000);
//        int Pending_Case_Level_Total_Count = map_Supervisory.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()+"_"+DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
//        Assert.assertEquals(Pending_Case_Level_Total_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(),DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
//        ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
//        }
    }


    @And("Check the count of Cases Card component present in the UA dashboard page after Case Approval")
    public void countCasesCardAfterApproval() throws InterruptedException {
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Auth_Cases_Total = map_auth.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Auth_Cases_Total + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
            ;
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count_Int = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count_Int + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }

    }

    @Then("Status of the Case should be as Case Approved")
    public void statusOfTheCaseWillBeAsCaseApproved() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        executeJavaScript("arguments[0].click();", cases.Active_Cases);
        if (cases.Case_Name_Validation.isDisplayed()) {
            Assert.assertEquals(Case_Name, cases.Case_Name_Validation.getText());
        }
        highlight(cases.Case_Name_Validation, "green").shouldBe(Condition.visible);
        Assert.assertEquals("Case Approved", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_APPROVED.getAttributes().toString()).shouldBe(Condition.visible).getText());
        TakeScreenshot();
    }

    @And("User searches for Case_Name under the Cases table")
    public void CaseTableDashboard() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        ua_dashboard.bar_dashboard.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        final tableImpl Case_table = new tableImpl($(By.xpath("//*[contains(@class,'cdk-table') and @role='table']")).should(Condition.appear));
        int colIndex = Case_table.getColumnIndexByColumnName("Case Name");
        System.out.println("Case Name :" + Case_Name);
        int rowIndex = Case_table.getRowIndexByColumnContainingText("Case Name", Case_Name.toString());
        highlight(Case_table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(Case_Name, Case_table.get_Cell_ByIndex(rowIndex, colIndex).getText());

    }

    @Then("Status of the Case will be as Case Rejected")
    public void statusOfTheCaseWillBeAsCaseRejected() {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        executeJavaScript("arguments[0].click();", cases.All_cases);
        if (cases.Case_Name_Validation.isDisplayed()) {
            Assert.assertEquals(Case_Name, cases.Case_Name_Validation.getText());
        }
        highlight(cases.Case_Name_Validation, "green").shouldBe(Condition.visible);
        Assert.assertEquals("Case Rejected", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_Rejected.getAttributes().toString()).shouldBe(Condition.visible).getText());
        TakeScreenshot();

    }

    @And("Check the count of Pending Case Level Requests Card component present in the UA dashboard page after Case Approval - {string} Officer")
    public void CountOfPendingCaseLevelRequestsAfterCaseApproval(String approver) throws InterruptedException {
        executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);

            int Pending_Case_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated
            Thread.sleep(15000);
            int Pending_Case_Level_Total_Count = map_approving.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Pending_Case_Level_Total_Count = map_Supervisory.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }

    }

    @And("Check the count of Cases Card component present in the UA dashboard page after Case Approval - {string} Officer")
    public void CountOfCaseWidgetAfterCaseApproval(String approver) throws InterruptedException {
        executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);


            int Case_total_count = map_nodal.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_nodal.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {


//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count = map_approving.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_approving.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }


    }

    @When("user navigates to UAPortal -> Case_Related_Approvals -> Case_Initiation")
    public void userNavigatesToMenuCase_Related_Approvals_caseInitiation() {
        if (case_initiation.Case_Initiation.is(Condition.selected)) {
            case_initiation.Case_Initiation.should(Condition.enabled).click();
        } else {
            ua_dashboard.Case_Related_Approvals.should(Condition.enabled).click();
            case_initiation.Case_Initiation.should(Condition.enabled).click();
        }
    }


    @When("user navigates to UAPortal -> Case_Related_Approvals -> Case_Transfer")
    public void userNavigatesToMenuCase_Related_Approvals_caseTransfer() {
        if (case_transfer.Case_Transfer.is(Condition.selected)) {
            case_transfer.Case_Transfer.should(Condition.enabled).click();
        } else {
            ua_dashboard.Case_Related_Approvals.should(Condition.enabled).click();
            case_transfer.Case_Transfer.should(Condition.enabled).click();
        }
    }

    @Then("The {string} Officer approve the Case Created")
    public void theOfficerApproveTheCaseCreated(String approver_str) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_initiation.Case_Initiation_Requests_Title.shouldBe(Condition.visible);
        case_initiation.Pending_requests.click();
        Thread.sleep(5000);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        TakeScreenshot();
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        executeJavaScript("arguments[0].click();", case_initiation.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
        case_initiation.Remarks.sendKeys("");
        case_initiation.Approval_page_Case_No.click();
        case_initiation.Remarks_Error_Message.should(Condition.visible);
        Assert.assertEquals("Please enter the remarks to proceed further", case_initiation.Remarks_Error_Message.getText());
        executeJavaScript("arguments[0].click();", cases.Cancel_Button);
        executeJavaScript("arguments[0].click();", case_initiation.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
        case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
        case_initiation.Approval_page_Case_No.getText();
        case_initiation.Remarks.sendKeys("Approved the Case ---------->" + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Submit_Button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_initiation.Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).perform();
        Assert.assertEquals("Approved", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Current_Date_Time, case_transfer.ApproveDateByCaseName(Case_Name).getText());
        System.out.println("Context.Approved_Date_Time : " + case_transfer.ApproveDateByCaseName(Case_Name).getText());
        scenarioContext.setContext(Context.Case_Status, case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenario.log("Case Approved Date and Time : " + case_transfer.ApproveDateByCaseName(Case_Name).getText());
        TakeScreenshot();
    }

    @Then("The {string} Officer Rejects the Case Created")
    public void theOfficerRejectsTheCaseCreated(String Reject_str) throws InterruptedException {
        scenarioContext.setContext(Context.Approver_User_Role, cases.User_role.shouldBe(Condition.visible).getText());
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_initiation.Case_Initiation_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        executeJavaScript("arguments[0].click();", case_initiation.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_REJECT_ACTION.getAction().toString()));
        case_initiation.Rejection_Confirmation.shouldBe(Condition.visible);
        case_initiation.Remarks.sendKeys("Reject the Case ---------->" + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Yes_button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_initiation.Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).perform();
        Assert.assertEquals("Rejected", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Case_Status, case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Current_Date_Time, case_transfer.ApproveDateByCaseName(Case_Name).getText());
        scenario.log("Case Rejection Dtae and Time : " + case_transfer.ApproveDateByCaseName(Case_Name).getText());
        TakeScreenshot();
    }

    @And("Check the count of Cases Card component present in the UA dashboard page after Case Rejection - {string} Officer")
    public void CountOfCaseCardComponentInUADashboardPageRejection(String approver) throws InterruptedException {
        ua_dashboard.bar_dashboard.shouldBe(Condition.visible).click();
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);


            int Case_total_count = map_nodal.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_nodal.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count = map_approving.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_approving.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Case_Active_count = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Case_Active_count, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
    }

    @And("Check the count of Pending Case Level Requests Card component present in the UA dashboard page after Case Rejection - {string} Officer")
    public void CountOfPendingCaseLevelRequestsAfterCaseRejection(String approver) throws InterruptedException {
        ua_dashboard.bar_dashboard.shouldBe(Condition.visible).click();
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(20000);

            int Pending_Case_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("APPROVING OFFICER")) {


//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(20000);
            int Pending_Case_Level_Total_Count = map_approving.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(20000);
            int Pending_Case_Level_Total_Count = map_Supervisory.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }

    }

    @And("Check the count of Cases Card component present in the UA dashboard page after Case Rejection")
    public void CountCasesCardDashboardPageAfterRejection() throws InterruptedException {
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Auth_Cases_Total = map_auth.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Auth_Cases_Total, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Case_total_count_Int = map_Supervisory.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Case_total_count_Int, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }

    }

    @And("Check the count of Pending Case Level Requests Card component present in the UA dashboard page after Case Rejection")
    public void CountOfPendingCaseCardComponentDashboardPageAfterRejection() throws InterruptedException {
        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

            ua_dashboard.bar_dashboard.shouldBe(Condition.visible).click();

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);
            int Pending_Case_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            int Pending_Case_Level_Rejection_Count = map_auth.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getParamName()), "green");
//            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(),DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            Assert.assertEquals(Pending_Case_Level_Rejection_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_Rejected.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }

    }


    /*
    Case Close Related Step Defination declaration
     */

    @Then("User raise Case Close Request")
    public void userRaiseCaseCloseRequest() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_CLOSE.getAction().toString()).click();
        case_initiation.Remarks.sendKeys("Close the Case with CaseID" + " ---->" + Case_Name);
        executeJavaScript("arguments[0].click();", cases.submit_Button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", cases.Closed_Cases);
        executeJavaScript("arguments[0].click();", cases.Active_Cases);
        scenarioContext.setContext(Context.Current_Date_Time, cases.Case_Date_Time(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()).shouldBe(Condition.visible).getText());
        scenario.log("Case Close Request Raise Date and Time : " + cases.Case_Date_Time(Case_Name, CASE_ATTRIBUTES.CASE_REQUEST_SUBMITTED.getAttributes().toString()));
        Assert.assertEquals("Case Close Request Submitted", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.Case_Close_Request_Submitted.getAttributes().toString()).shouldBe(Condition.visible).getText());

    }

    @When("user navigates to UAPortal -> Case_Related_Approvals -> Case_Close")
    public void userNavigatesToUAPortalCase_Related_ApprovalsCase_Close() {
        if (case_close.Closed_Cases.isDisplayed()) {
            executeJavaScript("arguments[0].click();", case_close.Closed_Cases.should(Condition.enabled));
        } else {
            ua_dashboard.Case_Related_Approvals.should(Condition.enabled).click();
            executeJavaScript("arguments[0].click();", case_close.Closed_Cases.should(Condition.enabled));
        }
    }

    @Then("The {string} Officer Approve the Case Close Request")
    public void theOfficerApproveTheCaseCloseRequest(String Approve_str) throws InterruptedException {
        scenarioContext.setContext(Context.Approver_User_Role, cases.User_role.shouldBe(Condition.visible).getText());
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_close.Case_Close_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        case_initiation.Pending_requests_Requests_Case_physical_Digital.getText();
        executeJavaScript("arguments[0].click();", case_close.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
        case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
        Assert.assertEquals(Case_Name, case_initiation.Approval_page_Case_No.getText());
        case_initiation.Remarks.sendKeys("Approve the Case Close Request ------------> " + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Submit_Button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_close.Close_Approved_Rejected_Requests_Tab);

//      User is not able to view the approved/rejected Reopen request under approved/rejected Reopen request tab. Uncomment below code once the issue is fixed

//        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
//        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).perform();
//        Assert.assertEquals("Case Closed", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
//        scenarioContext.setContext(Context.Case_Status, case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
//        scenarioContext.setContext(Context.Current_Date_Time, case_close.CaseCloseApproveDateByCaseName(Case_Name).getText());
//        scenario.log("Case Close Request Approved Date and Time : " + case_close.CaseCloseApproveDateByCaseName(Case_Name).getText());
        TakeScreenshot();
//        Assert.assertEquals("Case Closed", case_close.CaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.CASE_Close_Approve.getAttributes().toString()).getText());
    }

    @And("Check the count of Close Case component in UA dashboard Page")
    public void countPendingCaseLevelRequestsCardAfterCaseClose() throws InterruptedException {

        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

            ua_dashboard.bar_dashboard.shouldBe(Condition.visible).click();

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);

            int Pending_Case_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));

            int Closed_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()), "green");
            Assert.assertEquals(Closed_Level_Total_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        }

        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("AUTHORIZED OFFICER")) {

            ua_dashboard.bar_dashboard.shouldBe(Condition.visible).click();

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);

//            int Pending_Case_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
//            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));

            int Closed_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_CLOSED.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()), "green");
            Assert.assertEquals(Closed_Level_Total_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName(), DASHBOARD_WIDGETS.CASES_CLOSED.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_CLOSED.getWidgetName()));
        }
    }

    @Then("Status of the Case will be as Case Close Approved")
    public void statusOfTheCaseWillBeAsCaseClosed() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", cases.Closed_Cases);
        if (cases.Case_Name_Validation.isDisplayed()) {
            Assert.assertEquals(Case_Name, cases.Case_Name_Validation.getText());
        }
        highlight(cases.Case_Name_Validation, "green").shouldBe(Condition.visible);


//      Commenting the below statements as status

//        executeJavaScript("arguments[0].click();",cases.Case_Status_Button);
//        Assert.assertEquals("Case Close Approved", cases.Case_Status(Case_Name, CASE_ATTRIBUTES.CASE_CLOSED.getAttributes().toString()).getText());

        TakeScreenshot();


    }

    @Then("The {string} Officer Rejects the Case Close Request")
    public void OfficerRejectsCaseCloseRequest(String Reject_str) throws InterruptedException {
        scenarioContext.setContext(Context.Approver_User_Role, cases.User_role.shouldBe(Condition.visible).getText());
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_close.Case_Close_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        case_initiation.Pending_requests_Requests_Case_physical_Digital.getText();
        executeJavaScript("arguments[0].click();", case_close.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_REJECT_ACTION.getAction().toString()));
//            case_close.Case_Close_Requests_Approve.click();
        case_initiation.Rejection_Confirmation.shouldBe(Condition.visible);
        case_initiation.Remarks.sendKeys("Reject the Case Close Request ------------> " + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Yes_button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_close.Close_Approved_Rejected_Requests_Tab);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).build().perform();
        Assert.assertEquals("Close Request Rejected", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Case_Status, case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Current_Date_Time, case_close.CaseCloseApproveDateByCaseName(Case_Name).getText());
        scenario.log("Case Close Request Rejection Date and Time : " + case_close.CaseCloseApproveDateByCaseName(Case_Name).getText());
        TakeScreenshot();
//        Assert.assertEquals("Close Request Rejected", case_close.CaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.CASE_Close_Reject.getAttributes().toString()).getText());

    }

    //    Case Transfer Step Definitions

    @Then("User raise Case Transfer Request")
    public void CaseTransferRequest() throws InterruptedException {
        String myCaseName = scenarioContext.getContext(Context.CASENAME).toString();
        executeJavaScript("arguments[0].click();", cases.getActionButtonByCaseName(myCaseName, CASE_ACTIONS.TRANSFER_CASE.getAction().toString()));
//        Assert.assertEquals("Case Transfer Request", cases.Case_Transfer_Request_PageHeading.getText());
        case_initiation.Remarks.sendKeys("Case transfer Request" + " ---->" + myCaseName);
        executeJavaScript("arguments[0].click();", cases.submit_Button);

    }


    @Then("The {string} Officer Approves the Case Transfer Request and transfer the case to {string} Officer -------> UserName::{string}")
    public void theOfficerApprovesTheCaseTransferRequest(String approver_str, String Transfer_Case, String Username) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        if (Transfer_Case.equalsIgnoreCase("Authorized")) {
            case_transfer.Case_Transfer_Requests_Title.shouldBe(Condition.visible);
            executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

            highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
            executeJavaScript("arguments[0].click();", case_transfer.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
            case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
            case_initiation.Approval_page_Case_No.getText();
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name);
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name_AUTHORIZED_OFFICER);
            executeJavaScript("arguments[0].click();", case_transfer.Transferred_User_ID);
            executeJavaScript("arguments[0].click();", case_transfer.CaseTransferID(PropertyUtils.getPropString(Username)).shouldBe(Condition.visible));
            case_initiation.Remarks.sendKeys("Aprroving the Case Transfer Request ---------->" + Case_Name + "Assigning Case to " + Transfer_Case + "Officer");
        } else if (Transfer_Case.equalsIgnoreCase("Approving")) {
            case_transfer.Case_Transfer_Requests_Title.shouldBe(Condition.visible);
            executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

            highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
            executeJavaScript("arguments[0].click();", case_transfer.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
            case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
            case_initiation.Approval_page_Case_No.getText();
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name);
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name_APPROVING_OFFICER);
            executeJavaScript("arguments[0].click();", case_transfer.Transferred_User_ID);
            executeJavaScript("arguments[0].click();", case_transfer.CaseTransferID(PropertyUtils.getPropString(Username)).shouldBe(Condition.visible));
            case_initiation.Remarks.sendKeys("Aprroving the Case Transfer Request ---------->" + Case_Name + "Assigning Case to " + Transfer_Case + "Officer");

        } else if (Transfer_Case.equalsIgnoreCase("Supervisory")) {
            case_transfer.Case_Transfer_Requests_Title.shouldBe(Condition.visible);
            executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

            highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
            executeJavaScript("arguments[0].click();", case_transfer.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
            case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
            case_initiation.Approval_page_Case_No.getText();
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name);
            executeJavaScript("arguments[0].click();", case_transfer.Role_Name_SUPERVISORY_OFFICER);
            executeJavaScript("arguments[0].click();", case_transfer.Transferred_User_ID);
            executeJavaScript("arguments[0].click();", case_transfer.CaseTransferID(PropertyUtils.getPropString(Username)).shouldBe(Condition.visible));
            case_initiation.Remarks.sendKeys("Aprroving the Case Transfer Request ---------->" + Case_Name + "Assigning Case to " + Transfer_Case + "Officer");
        }
        executeJavaScript("arguments[0].click();", cases.Submit_Button);
        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();", case_transfer.Transfer_Approved_Rejected_Requests);
        Thread.sleep(3000);

//      User is not able to view the approved/rejected Transfer request under approved/rejected Transfer request tab. Uncomment belwo code once the issue is fixed

//        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");

//        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).build().perform();
//        Assert.assertEquals("Transfer Approved", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        TakeScreenshot();
//        Assert.assertEquals("Transfer Approved", case_transfer.CaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.Transfer_Approved.getAttributes().toString()).getText());
    }

    @And("Check the count of Case Transfer component in UA dashboard Page")
    public void countPendingCaseLevelRequestsCardAfterCaseTransfer() throws InterruptedException {

        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

            executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);

            int Pending_Case_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
            int Transferred_Level_Total_Count = map_nodal.get(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Transferred_Level_Total_Count + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName()).getText()));

            int Transferred_Level_Total_Active = map_nodal.get(DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getParamName()), "green");
            Assert.assertEquals(Transferred_Level_Total_Active + 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_Active.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName()));
        }
    }

    @And("Check the count of Case component in UA dashboard Page")
    public void countCaseTotal() throws InterruptedException {

        if (cases.User_role.shouldBe(Condition.visible).getText().equalsIgnoreCase("NODAL OFFICER")) {

            executeJavaScript("arguments[0].click();", ua_dashboard.bar_dashboard.shouldBe(Condition.visible));

//       Adding sleep for system to wait till case related count in dashboard gets updated

            Thread.sleep(15000);

            int Pending_Case_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()), "green");
            Assert.assertEquals(Pending_Case_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
            int Transferred_Level_Total_Count = map_auth.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()), "green");
            Assert.assertEquals(Transferred_Level_Total_Count - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
            int Transferred_Level_Total_Active = map_auth.get(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName());
            highlight(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()), "green");
            Assert.assertEquals(Transferred_Level_Total_Active - 1, parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.CASES_ACTIVE.getParamName()).getText()));
            ElementScreenshot(ua_dashboard.getWidgetName(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        }
    }

    @Then("The {string} Officer Reject the Case Transfer Request")
    public void theOfficerRejectTheCaseTransferRequest(String Reject_str) throws InterruptedException {
        scenarioContext.setContext(Context.Approver_User_Role, cases.User_role.shouldBe(Condition.visible).getText());
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_transfer.Case_Transfer_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);

        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
//            Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        executeJavaScript("arguments[0].click();", case_transfer.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_REJECT_ACTION.getAction().toString()));
        case_initiation.Rejection_Confirmation.shouldBe(Condition.visible);
        case_initiation.Remarks.sendKeys("Reject the Case Transfer Request ---------->" + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Yes_button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_transfer.Transfer_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).build().perform();
        Assert.assertEquals("Transfer Request Rejected", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        scenarioContext.setContext(Context.Case_Status, case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        TakeScreenshot();
//        Assert.assertEquals("Transfer Request Rejected", case_transfer.CaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.Transfer_Request_Rejected.getAttributes().toString()).getText());

    }

    @Then("User validate the Case status and Click on View Case action button to view the Case Details")
    public void ViewCase() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        scenario.log("Case Name: " + Case_Name);
//        cases.ViewCaseByCaseName(Case_Name).click();
        executeJavaScript("arguments[0].click();", cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.VIEW_CASE.getAction().toString()));
    }

    @When("user select Image search and upload file {string}")
    public void UploadAFile(String file) throws InterruptedException {
        viewCase_discover.Image_Search.should(Condition.appear).click();
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Image_search.Upload_A_File.uploadFile(new File(file));
        Thread.sleep(3000);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Image_Search.Image_Processing.shouldNotBe(visible);
        Image_Search.Remove_Image.shouldBe(visible);

        executeJavaScript("arguments[0].scrollIntoView(true);", Image_search.Upload_And_Search);
        executeJavaScript("arguments[0].click();", Image_search.Upload_And_Search.should(Condition.enabled));
        Image_search.Remark.should(Condition.enabled).setValue("Remark for Case :" + scenarioContext.getContext(Context.CASENAME));
        Image_search.Declaration_text.click();
        Image_search.SUBMIT_BUTTON.should(Condition.enabled).click();
        commonElements.Vertical_Loader.shouldNotBe(visible);
    }

    @When("user is able to attach the selected searched record for Entity :::: {string} to the existing cases where parameter value is :::: {string}")
    public void ValidateUploadedImage(String PersonName,String Value) throws InterruptedException {
        Image_Search.Expand_Entity.shouldBe(visible);
        Image_search.Expand_Entity_panel.should(Condition.appear).click();
        Thread.sleep(3000);
        TakeScreenshot();
        int rowIndex = Image_search.Entities_Result_Table.getRowIndexByColumnContainingText("Mobile No", Value);
        Thread.sleep(3000);
        highlight(Image_search.Entities_Result_Table.get_Cell_ByIndex(rowIndex, 1), "green").click();
//        highlight(Image_search.Entities_Result_Table.get_Cell_ByIndex(rowIndex, 10), "green");
        Image_search.Select_All_Entities_Checkbox.click();
        Image_search.BUTTON_RESOLVE_ENTITY.should(Condition.appear).click();
        TakeScreenshot();
        Image_search.BUTTON_ATTACH_ENTITY_TO_CASE.shouldBe(visible).click();
        Thread.sleep(3000);

    }

    @When("user select Image search and upload files from folder {string}")
    public void UploadFromFolder(String folderPath) throws InterruptedException {
        viewCase_discover.Image_Search.should(Condition.appear).click();
        Image_search.Upload_A_File.uploadFile(new File(folderPath));
        Image_search.Upload_And_Search.should(Condition.enabled).click();
        Image_search.Remark.should(Condition.enabled).setValue("Remark for Case :" + scenarioContext.getContext(Context.CASENAME));
//        Image_search.Declaration_CheckBox.setSelected(true);
        Image_search.Declaration_text.click();
        Image_search.SUBMIT_BUTTON.should(Condition.enabled).click();
    }


    @Then("user should redirect on query builder screen and enter the parameters and values")
    public void ParametersAndValuesunderQueryBuilderScreen(DataTable SearchQuery) throws InterruptedException {
        Thread.sleep(3000);
        Map_data = SearchQuery.asMaps(String.class, String.class);
        for (int i = 0; i < Map_data.size(); i++) {
            AdvancedSearchPage.Select_Parameter.get(i).shouldBe(Condition.visible).click();
            AdvancedSearchPage.ER_Parameter(Map_data.get(i).get("Parameter")).shouldBe(Condition.visible).click();
            AdvancedSearchPage.Select_Operator.get(i).shouldBe(Condition.visible).click();
            AdvancedSearchPage.ER_Operator(Map_data.get(i).get("Operator")).shouldBe(Condition.visible).click();
            AdvancedSearchPage.InputElementForParam(Map_data.get(i).get("Parameter")).should(Condition.appear).sendKeys(Map_data.get(i).get("Value"));
            if (i < Map_data.size() - 1) { //if we have 3 records to be set then we need to click two times
                executeJavaScript("arguments[0].click();", AdvancedSearchPage.Add_Rule.should(Condition.enabled));
            }//for
        }


    }//method

    @And("Click on Advanced Search Radio Button")
    public void AdvancedSearchRadioButton() throws InterruptedException {
        AdvancedSearchPage.Advanced_Search_Mart.click();
        Thread.sleep(3000);

    }

    @And("verify that user should get required results under advanced search")
    public void ResultsUnderAdvancedSearch() throws InterruptedException {
        AdvancedSearchPage.Search_Button.shouldBe(Condition.enabled).click();
        Thread.sleep(4000);
        TakeScreenshot();
    }

    @Then("User raise Case Re-open Request")
    public void CaseReOpenRequest() {
        String myCaseName = scenarioContext.getContext(Context.CASENAME).toString();
        cases.getActionButtonByCaseName(myCaseName, CASE_ACTIONS.CASE_REOPEN.getAction().toString()).click();
        case_initiation.Remarks.sendKeys("Reopen the Case with CaseID" + " ---->" + myCaseName);
        executeJavaScript("arguments[0].click();", cases.submit_Button.shouldBe(Condition.enabled, Duration.ofMinutes(3)));
    }

    @When("user navigates to UAPortal -> Case_Related_Approvals -> Case_Reopen")
    public void userNavigatesToUAPortalCase_Related_ApprovalsCase_Reopen() {
        if (case_reopen.Case_Reopen.isDisplayed()) {
            case_reopen.Case_Reopen.should(Condition.enabled).click();
        } else {
            ua_dashboard.Case_Related_Approvals.should(Condition.enabled).click();
            case_reopen.Case_Reopen.should(Condition.enabled).click();
        }
    }

    @Then("The {string} Officer Approve the Case Reopen Request")
    public void ApproveTheCaseReopenRequest(String Approve_str) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_reopen.Case_Reopen_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        case_initiation.Pending_requests_Requests_Case_physical_Digital.getText();
        executeJavaScript("arguments[0].click();", case_reopen.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_APPROVE_ACTION.getAction().toString()));
        case_initiation.Approval_Confirmation.shouldBe(Condition.visible);
        Assert.assertEquals(Case_Name, case_initiation.Approval_page_Case_No.getText());
        case_initiation.Remarks.sendKeys("Approve the Case Reopen Request ------------> " + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Submit_Button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", case_reopen.Reopen_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).build().perform();
        Assert.assertEquals("Reopen Approved", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        TakeScreenshot();

    }

    @Then("The {string} Officer Reject the Case Reopen Request")
    public void RejectTheCaseReopenRequest(String Approve_str) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        case_reopen.Case_Reopen_Requests_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", case_initiation.Pending_requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        Assert.assertEquals(Case_Name, case_initiation.Pending_requests_Requests_CaseName.getText());
        case_initiation.Pending_requests_Requests_Case_physical_Digital.getText();
        executeJavaScript("arguments[0].click();", case_reopen.ActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_REJECT_ACTION.getAction().toString()));
        case_initiation.Rejection_Confirmation.shouldBe(Condition.visible);
        Assert.assertEquals(Case_Name, case_initiation.Approval_page_Case_No.getText());
        case_initiation.Remarks.sendKeys("Reject the Case Reopen Request ------------> " + Case_Name);
        executeJavaScript("arguments[0].click();", cases.Yes_button);
        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();", case_reopen.Reopen_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        actions().moveToElement(case_transfer.CaseStatusMouseHoverByCaseName(Case_Name)).build().perform();
        Assert.assertEquals("Reopen Request Rejected", case_transfer.CaseStatusMouseHoverByCaseName(Case_Name).getAttribute("mattooltip"));
        TakeScreenshot();

    }

    @Then("Status of the Case will be as Reopen Approved")
    public void CaseStatusReopenApproved() {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        executeJavaScript("arguments[0].click();", cases.Active_Cases);
        if (cases.Case_Name_Validation.isDisplayed()) {
            Assert.assertEquals(Case_Name, cases.Case_Name_Validation.getText());
        }
        highlight(cases.Case_Name_Validation, "green").shouldBe(Condition.visible);
//        Assert.assertEquals("Case Reopen Approved", cases.getCaseStatusByCaseName(Case_Name, CASE_ATTRIBUTES.Case_ReOpen_Approved.getAttributes().toString()).getText());
        TakeScreenshot();

    }


    @When("user select UseCase search for performing Use Case Search")
    public void userSelectUseCaseSearchWithSourceAs() throws InterruptedException {
        viewCase_discover.Use_Case_Search.should(Condition.visible).click();
        Thread.sleep(2000);
        usecasesearch.Use_Case_Selected_heading.should(Condition.visible);
    }

    @Then("Select {string} and {string} from the list")
    public void userShouldDisplayProvidingOrganizationsAlongWithTheirUseCases(String PO_Source, String PO_UseCase) throws
            InterruptedException {
        usecasesearch.PO_Source(PO_Source).should(Condition.visible).click();

        $(By.xpath("//div[contains(text(),'" + PO_Source + "')]//parent::mat-panel-title//parent::span//parent::mat-expansion-panel-header//parent::mat-expansion-panel//table[@role='table']")).shouldBe(Condition.visible);
        int colIndex = usecasesearch.PO_UseCase(PO_Source).getColumnIndexByColumnName("Usecase Description");
        System.out.println("ColIndex : " + colIndex);
        int rowIndex = usecasesearch.PO_UseCase(PO_Source).getRowIndexByColumnContainingText(" Usecase Description ", PO_UseCase);
        highlight(usecasesearch.PO_UseCase(PO_Source).get_Cell_ByIndex(rowIndex, colIndex), "green");
//        int ActionColIndex = usecasesearch.PO_UseCase(PO_Source).getColumnIndexByColumnName("Action");
//        actions().moveToElement(usecasesearch.PO_UseCase(PO_Source).get_Cell_ByIndex(rowIndex, ActionColIndex)).click();
    }

    @When("Click on Raise Request Button and provide parameter value in {string} pop-up window for {string}")
    public void RaiseRequest(String PO_Source, String PO_UseCase) throws InterruptedException {
        int UseCaseCategory_colIndex = usecasesearch.PO_UseCase(PO_Source).getColumnIndexByColumnName("Usecase Category");
        int UseCaseCategory_rowIndex = usecasesearch.PO_UseCase(PO_Source).getRowIndexByColumnContainingText("Usecase Category", PO_UseCase);
        highlight(usecasesearch.PO_UseCase(PO_Source).get_Cell_ByIndex(UseCaseCategory_rowIndex, UseCaseCategory_colIndex), "green");
        String UseCaseCategory = usecasesearch.PO_UseCase(PO_Source).get_Cell_ByIndex(UseCaseCategory_rowIndex, UseCaseCategory_colIndex).getText();
        usecasesearch.PO_UseCase_Title(PO_UseCase).shouldBe(Condition.visible);
        usecasesearch.Input_text.should(Condition.visible).sendKeys("HRPPT8688F");
        usecasesearch.Add_Button.click();
        usecasesearch.Use_Case_Query(PO_Source).shouldBe(Condition.visible);
        commonElements.SUBMIT_BUTTON.click();

    }

    @When("user navigates to UAPortal -> Case management -> Case Participants")
    public void userNavigatesToMenuCase_management_Cases_Participants() {
        if (ua_Case_Management.Case_Participants.isDisplayed()) {
            ua_Case_Management.Case_Participants.should(Condition.enabled).click();
        } else {
            ua_dashboard.case_Management.should(Condition.enabled).click();
            ua_Case_Management.Case_Participants.should(Condition.enabled).click();
        }
    }

    @Then("Nodal Officer add New Participants : {string} into the existing Cases")
    public void AddParticipantsIntoExistingCases(String Username) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String UserName = PropertyUtils.getPropString(Username) + "@devng.in";
        Thread.sleep(3000);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible);
        int colIndex = caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Action");
        System.out.println("colIndex :::::::::: " + colIndex);
        int rolIndex = caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name);
        System.out.println("rolIndex :::::::::: " + rolIndex);
        highlight(caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Case Name")), "green");
        caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, colIndex).shouldBe(Condition.visible).click();
        caseparticipants.Add_Case_Participants_heading.shouldBe(Condition.visible);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].scrollIntoView(true);", caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible));
//        actions().moveToElement(caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible)).build().perform();
        highlight(caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible), "green");
        Thread.sleep(3000);
        caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible).click();
        caseparticipants.Select_Login_ID.shouldBe(Condition.visible);
        caseparticipants.User_Login_ID.shouldBe(Condition.visible).click();
        caseparticipants.Search_Login_ID.shouldBe(Condition.visible).sendKeys(UserName);
        caseparticipants.User_ID.shouldBe(Condition.visible).click();
        caseparticipants.Remarks.shouldBe(Condition.visible).sendKeys("Add new User participant " + UserName + " into the " + Case_Name);
        executeJavaScript("arguments[0].click();", commonElements.SUBMIT_BUTTON.shouldBe(enabled));
        Thread.sleep(3000);
        if (CommonElements.SPINNER_THREE_DOTS_ICON.isDisplayed()) {
            CommonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(Condition.visible);
        }
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible);
        caseownerevoke.Search_Case.shouldBe(Condition.visible).sendKeys(Case_Name);
        highlight(caseparticipants.Case_Participants_Table.getCellByIndex(caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name), caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Participant User Name")), "green");
        scenario.log("Newly added Participant into the " + Case_Name + " is " + caseparticipants.Case_Participants_Table.buildCellXPath(caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name), caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Participant User Name")).getText());
        TakeScreenshot();
    }

    @Then("Nodal Officer add Multiple Case Participants ::: {string} , {string} , {string} into the existing Cases")
    public void AddMultipleParticipantsIntoApprovedCases(String Username_1, String Username_2, String Username_3) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String UserName_1 = PropertyUtils.getPropString(Username_1) + "@devng.in";
        String UserName_2 = PropertyUtils.getPropString(Username_2) + "@devng.in";
        String UserName_3 = PropertyUtils.getPropString(Username_3) + "@devng.in";
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        int colIndex = caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Action");
        System.out.println("colIndex :::::::::: " + colIndex);
        int rolIndex = caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name);
        System.out.println("rolIndex :::::::::: " + rolIndex);
        highlight(caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Case Name")), "green");
        caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, colIndex).shouldBe(Condition.visible).click();
        caseparticipants.Add_Case_Participants_heading.shouldBe(Condition.visible);
        caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible).click();
        caseparticipants.Select_Login_ID.shouldBe(Condition.visible);
        caseparticipants.User_Login_ID.shouldBe(Condition.visible).click();
        caseparticipants.Search_Login_ID.shouldBe(Condition.visible).sendKeys(UserName_1);
        caseparticipants.User_ID.shouldBe(Condition.visible).click();


        caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible).click();
        caseparticipants.User_Login_ID_2.shouldBe(Condition.visible).click();
        caseparticipants.Search_Login_ID.shouldBe(Condition.visible).sendKeys(UserName_2);
        caseparticipants.User_ID.shouldBe(Condition.visible).click();

        caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible).click();
        caseparticipants.User_Login_ID_3.shouldBe(Condition.visible).click();
        caseparticipants.Search_Login_ID.shouldBe(Condition.visible).sendKeys(UserName_3);
        caseparticipants.User_ID.shouldBe(Condition.visible).click();
        caseparticipants.Remarks.shouldBe(Condition.visible).sendKeys("New Case Participant are added to " + Case_Name + " ::::::: " + UserName_1 + UserName_2 + UserName_3);
        executeJavaScript("arguments[0].click();", commonElements.SUBMIT_BUTTON.shouldBe(enabled));
        Thread.sleep(3000);
        if (CommonElements.SPINNER_THREE_DOTS_ICON.isDisplayed()) {
            CommonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(Condition.visible);
        }
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible);
        caseownerevoke.Search_Case.shouldBe(Condition.visible).sendKeys(Case_Name);
        highlight(caseparticipants.Case_Participants_Table.getCellByIndex(caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name), caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Participant User Name")), "green");
        scenario.log("New Case Participant are added to " + Case_Name + " ::::::: " + caseparticipants.Case_Participants_Table.buildCellXPath(caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name), caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Participant User Name")).getText());
        TakeScreenshot();
    }

    @Then("Nodal Officer unmap the existing Case Participants : {string} from the Case")
    public void NodalOfficerUnmapExistingCaseParticipants(String Username) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String UserName = PropertyUtils.getPropString(Username) + "@devng.in";
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible, Duration.ofMinutes(5));
        Thread.sleep(5000);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        int colIndex = caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Action");
        System.out.println("colIndex :::::::::: " + colIndex);
        int rolIndex = caseparticipants.Case_Participants_Table.getRowIndexByColumnContainingText("Case Name", Case_Name);
        System.out.println("rolIndex :::::::::: " + rolIndex);
        highlight(caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Case Name")), "green");
        caseparticipants.Case_Participants_Table.get_Cell_ByIndex(rolIndex, colIndex).shouldBe(Condition.visible).click();
        caseparticipants.Add_Case_Participants_heading.shouldBe(Condition.visible);
//        caseparticipants.Add_New_Participants_Button.shouldBe(Condition.visible).click();
        caseparticipants.Remove_Login_ID(UserName).shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", caseparticipants.Delete_Button.shouldBe(enabled));
        Thread.sleep(2000);
        caseparticipants.Remove_Login_ID(UserName).shouldNotBe(Condition.visible);
        caseparticipants.Remarks.shouldBe(Condition.visible).sendKeys("Unmap Existing Participant :::: " + UserName + " from the Case :::: " + Case_Name);
        executeJavaScript("arguments[0].click();", commonElements.SUBMIT_BUTTON.shouldBe(enabled));
        caseparticipants.Case_Participants_Heading.shouldBe(Condition.visible);
        caseownerevoke.Search_Case.shouldBe(Condition.visible).sendKeys(Case_Name);
        TakeScreenshot();
    }

    @Then("Nodal Officer revokes the case owner and add New Case Owner : {string}")
    public void nodalOfficerRevokesCaseOwner(String Username) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String UserName = PropertyUtils.getPropString(Username) + "@devng.in";
        caseownerevoke.Case_Owner_Revoke_Heading.shouldBe(Condition.visible);
        caseownerevoke.Search_Case.shouldBe(Condition.visible).sendKeys(Case_Name);
        int colIndex = caseownerevoke.Case_revoke_Table.getColumnIndexByColumnName("Action");
        int rolIndex = caseownerevoke.Case_revoke_Table.getRowIndexByColumnContainingText("Case Name", Case_Name);
        highlight(caseownerevoke.Case_revoke_Table.get_Cell_ByIndex(rolIndex, caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Case Name")), "green");
        executeJavaScript("arguments[0].click();", caseownerevoke.Revoke_Table_Button.shouldBe(enabled));
        Thread.sleep(2000);
//        caseownerevoke.Case_revoke_Table.get_Cell_ByIndex(rolIndex, colIndex).shouldBe(Condition.visible).click();
        caseownerevoke.Revoke_Case_Owner_heading.shouldBe(Condition.visible);
        caseownerevoke.Role_Name.should(Condition.visible).click();
        SelectDropDownValue.toSelectDropDown(caseownerevoke.Role_Name_Drop_down, "AUTHORIZED OFFICER");
        executeJavaScript("arguments[0].click();", caseownerevoke.Assign_Officer.should(Condition.visible));
        SelectDropDownValue.toSelectDropDown(caseownerevoke.Assign_Officer_Drop_down, UserName);
        caseownerevoke.Remarks.shouldBe(Condition.visible).sendKeys("Revoke the " + UserName + " from " + Case_Name);
        executeJavaScript("arguments[0].click();", caseownerevoke.Revoke_Button.shouldBe(enabled));
        if (CommonElements.SPINNER_THREE_DOTS_ICON.isDisplayed()) {
            CommonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(Condition.visible);
        }
        caseownerevoke.Case_Owner_Revoke_Heading.shouldBe(Condition.visible);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        highlight(caseownerevoke.Case_revoke_Table.get_Cell_ByIndex(rolIndex, caseparticipants.Case_Participants_Table.getColumnIndexByColumnName("Owner ID")), "green");
        TakeScreenshot();
    }

    @When("user navigates to UAPortal -> Case management -> Case Owner Revoke")
    public void userNavigatesToMenuCase_management_Cases_Owner_Revoke() {
        if (ua_Case_Management.Case_Owner.isDisplayed()) {
            ua_Case_Management.Case_Owner.should(Condition.enabled).click();
        } else {
            ua_dashboard.case_Management.should(Condition.enabled).click();
            ua_Case_Management.Case_Owner.should(Condition.enabled).click();
        }
    }

    @And("Case Participant should not allowed to raise Case transfer,Case Reopen or Case Close request")
    public void ParticipantNotAllowedCaseTransferReopenCloseRequest() {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        caseparticipants.Search_Bar.sendKeys(Case_Name);
        if (!(cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_CLOSE.getAction().toString()).isEnabled())) {
            scenario.log("Case Participant Cannot raise Case Close request");
        }
        if (!(cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.TRANSFER_CASE.getAction().toString()).isEnabled())) {
            scenario.log("Case Participant Cannot raise Case Transfer request");
        }
        if (!(cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_REOPEN.getAction().toString()).isEnabled())) {
            scenario.log("Case Participant Cannot raise Case Reopen request");
        }
    }

    @Then("Case Owner should not be able to view the Case under Active Cases tab")
    public void CaseOwnerNotAllowedCaseUnderActiveCases() {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        caseparticipants.Search_Bar.sendKeys(Case_Name);
        if (!(cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.CASE_CLOSE.getAction().toString()).isDisplayed())) {
            scenario.log("Old Case Owner should not eb allowed to view the Case under Active Cases Tab");
        }

    }

    @And("Click on Notes Button present inside the Case and add Case Notes details")
    public void AddCaseNote() {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Title = Case_Name + RandomUtils.getUniqueNumber();
        casenotes.Notes_Icon.click();
        casenotes.Notes_Heading.should(Condition.visible);
        casenotes.Case_Notes.should(Condition.visible).click();
        casenotes.No_Notes_Added_Yet_Text_Message.should(Condition.visible);
        executeJavaScript("arguments[0].click();", casenotes.Take_Note_Button);
        casenotes.Title_Input_Box.shouldBe(Condition.visible).sendKeys(Title);
        casenotes.Description_Input_Box.shouldBe(Condition.visible).sendKeys(Case_Name + RandomUtils.getUniqueNumber() + " Description " + "Case_Notes.");
        executeJavaScript("arguments[0].click();", casenotes.Add_Button);
        casenotes.Case_Notes_Toast_Message.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", casenotes.Close_Button);
        scenarioContext.setContext(Context.Notes_Title, Title);


    }

    @And("Validate Case Notes details")
    public void ValidateCaseNote() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Title = scenarioContext.getContext(Context.Notes_Title).toString();
        executeJavaScript("arguments[0].click();", casenotes.Notes.should(Condition.visible));
        Thread.sleep(5000);
        executeJavaScript("arguments[0].click();", casenotes.Case_Notes.shouldBe(Condition.visible));
        scenario.log("Title : " + Title);
        TakeScreenshot();
    }

    @And("Validate Case Notes details created by {string}")
    public void ValidateCaseNoteByCaseOwner(String Username) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Title = scenarioContext.getContext(Context.Notes_Title).toString();
        executeJavaScript("arguments[0].click();", cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.VIEW_CASE.getAction().toString()));
        Thread.sleep(2000);
        casenotes.Notes_Icon.click();
        casenotes.Notes_Heading.should(Condition.visible);

        executeJavaScript("arguments[0].click();", casenotes.Notes.should(Condition.visible));
        Thread.sleep(5000);
        executeJavaScript("arguments[0].click();", casenotes.Case_Notes.shouldBe(Condition.visible));
        scenario.log("Case Note created by " + Username + " with given Title :::: " + Title);
        TakeScreenshot();
    }


    @And("Click on Notes Button present inside the Case and add Personal Notes details")
    public void AddPersonalNotes() throws InterruptedException {

        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Title = Case_Name + RandomUtils.getUniqueNumber();
        casenotes.Notes_Icon.click();
        casenotes.Notes_Heading.should(Condition.visible);
        highlight(casenotes.Personal_Notes.shouldBe(visible), "green");
        casenotes.Personal_Notes.should(Condition.visible).click();
        casenotes.No_Notes_Added_Yet_Text_Message.should(Condition.visible);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", casenotes.Take_Note_Button);
        casenotes.Title_Input_Box.shouldBe(Condition.visible).sendKeys(Title);
        casenotes.Description_Input_Box.shouldBe(Condition.visible).sendKeys(Case_Name + RandomUtils.getUniqueNumber() + " Description " + "Personal_Notes.");
        executeJavaScript("arguments[0].click();", casenotes.Add_Button);
        casenotes.Personal_Notes_Toast_Message.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", casenotes.Close_Button);
        scenarioContext.setContext(Context.Notes_Title, Title);
    }

    @And("Validate Personal Notes details")
    public void ValidatePersonalNotes() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Title = scenarioContext.getContext(Context.Notes_Title).toString();
        executeJavaScript("arguments[0].click();", casenotes.Notes.should(Condition.visible));
        executeJavaScript("arguments[0].click();", casenotes.Personal_Notes.shouldBe(Condition.visible));
        scenario.log("Title : " + Title);
        Thread.sleep(2000);
        TakeScreenshot();
    }


    //  ER Search related functions


    @When("user select ER search with source as {string}")
    public void ERSearch(String Entity) throws InterruptedException {
        viewCase_discover.ER_Search.should(Condition.visible).click();
        Thread.sleep(2000);
        viewCase_discover.source.shouldBe(Condition.visible).click();
        if (Entity.equalsIgnoreCase("PERSON")) {
            Thread.sleep(2000);
            viewCase_discover.ER_Source(Entity).shouldBe(Condition.visible).click();

        }

    }

    @And("Based on {string} as Source,select different field values for ER Search Query")
    public void ERSearchQuery(String Entity, DataTable SearchQuery) throws InterruptedException {
        Map_data = SearchQuery.asMaps(String.class, String.class);
        if (Entity.equalsIgnoreCase("PERSON")) {
            for (int i = 0; i < Map_data.size(); i++) {
                viewCase_discover.Select_Parameter.get(i).shouldBe(Condition.visible).click();
                viewCase_discover.ER_Parameter(Map_data.get(i).get("Parameter")).shouldBe(Condition.visible).click();
                viewCase_discover.Select_Operator.get(i).shouldBe(Condition.visible).click();
                viewCase_discover.ER_Operator(Map_data.get(i).get("Operator")).shouldBe(Condition.visible).click();
                viewCase_discover.InputElementForParam(Map_data.get(i).get("Parameter")).should(Condition.appear).sendKeys(Map_data.get(i).get("Value"));
                if (i < Map_data.size() - 1) { //if we have 3 records to be set then we need to click two times
                    viewCase_discover.Add_Rule.should(Condition.enabled).click();
                }//if
            }//for
            executeJavaScript("arguments[0].click();", viewCase_discover.ER_Search_Button);
            viewCase_discover.Remarks_Window.should(Condition.appear);
            viewCase_discover.Enter_Remarks.shouldBe(Condition.visible).sendKeys("ER Search Query for :: " + Entity);
            executeJavaScript("arguments[0].click();", viewCase_discover.Checkbox);
            executeJavaScript("arguments[0].click();", viewCase_discover.Submit_Button);
            Thread.sleep(2000);
            if (viewCase_discover.System_Error_Toast_Message.isDisplayed()) {
                viewCase_discover.Search_Button.click();
                if(viewCase_discover.Remarks_Window.isDisplayed()) {
                    viewCase_discover.Remarks_Window.should(Condition.appear);
                }
                viewCase_discover.Enter_Remarks.shouldBe(Condition.visible).sendKeys("ER Search Query for :: " + Entity);
                executeJavaScript("arguments[0].click();", viewCase_discover.Checkbox);
                executeJavaScript("arguments[0].click();", viewCase_discover.Submit_Button);
            } else if (viewCase_discover.Success_Toast_Message.isDisplayed()) {
                scenario.log(viewCase_discover.Success_Toast_Message.getText());
            }
        }//if
    }//method

    @Then("user should be able to view the results in cluster format")
    public void ViewResultsClusterFormat() throws InterruptedException {

        String Value = Map_data.get(0).get("Value");
        int colIndex = ER_search.ER_Result_Table.getColumnIndexByColumnName("NAME");
        int rowIndex = ER_search.ER_Result_Table.getRowIndexByColumnContainingText("NAME", Value);
        System.out.println(colIndex);
        System.out.println(rowIndex);
        highlight(ER_search.ER_Result_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        System.out.println("Cell Value by Index :: " + ER_search.ER_Result_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        Assert.assertEquals(Value, ER_search.ER_Result_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        TakeScreenshot();
    }//function

    @And("User should be able to expand the record cluster and Unmask first Record in Entity Record Cluster")
    public void ExpandClusterExpand() throws InterruptedException {
        String Value = Map_data.get(0).get("Value");
        if (!(ER_search.Single_Record_Cluster(Value).isEnabled())) {
            scenario.log("Single record cluster for Given ER Search Query");
            ER_search.Expand_button(Value).shouldBe(Condition.visible).click();
        } else if (ER_Search.Unmask_Record_Cluster(Value).isEnabled()) {
            scenario.log("Multiple record cluster for Given ER Search Query");
            ER_Search.Unmask_Record_Cluster(Value).click();
            ER_Search.Confirmation_window.shouldBe(visible);
            ER_Search.Yes_Button.shouldBe(enabled).click();
            CommonElements.SPINNER_CIRCLE_ICON.shouldNotBe(visible);
            Thread.sleep(3000);
            ER_search.Expand_button(Value).shouldBe(Condition.visible).click();
        }
        TakeScreenshot();
        Thread.sleep(3000);

    }//function

    @Then("User select the response from the result table")
    public void ResponseInResultTable() throws InterruptedException {
        String Value = Map_data.get(0).get("Value");
        ER_search.Select_Record(Value).shouldBe(Condition.visible).click();
        Thread.sleep(3000);
    }//function

    @And("Add the response to the Entity profile")
    public void ResponseToEntityProfile() throws InterruptedException {
        String Value = Map_data.get(0).get("Value");
        executeJavaScript("arguments[0].click();", ER_search.Resolve_Entity.should(Condition.enabled));
        Assert.assertEquals(Value, ER_search.Entity_details.getText());
        TakeScreenshot();
        Thread.sleep(4000);
        executeJavaScript("arguments[0].click();", ER_search.Attach_Entity_To_Case.should(Condition.enabled));
        Thread.sleep(3000);
        ER_search.Attach_Entity_To_Case_Title.should(Condition.visible);
        ER_search.Select_Profile_Name.click();
        String Profile_Name = ER_search.Profile_Name.getText();
        scenario.log("Entity Profile Name : " + Profile_Name);
        ER_search.Profile_Name.should(Condition.visible).click();
        executeJavaScript("arguments[0].click();", ER_search.Yes_Button);
        scenario.log("Entity Profile Name :::::::: " + Profile_Name);
        Thread.sleep(2000);
        ER_search.Confirmation_message.shouldBe(Condition.visible);
        Assert.assertEquals("Profile Created Successfully", ER_search.Confirmation_message.shouldBe(Condition.appear).getText());
        scenarioContext.setContext(Context.Entity_Profile_Name, Profile_Name);
    }//function

    @Then("Verify that attached entity Profile is displaying under entity profiles tab in Case Management")
    public void AttachedEntityUnderEntityProfiles() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        EntityProfile.Entity_Proﬁles.should(Condition.visible).click();
        Thread.sleep(2000);
        ER_search.Entity_Profile_Name.should(Condition.visible).getText();
        Assert.assertEquals(Entity_Profile, ER_search.Entity_Profile_Name.getText());

        TakeScreenshot();
    }

    @And("User should be able to perform Search on cluster results and should be displayed the relevant results as per the search keyword.")
    public void PerformSearchOnClusterResults() {
        String Value = Map_data.get(0).get("Value");
        ER_search.Search_Bar.sendKeys(Value);
        final SelenideElement Search_Table_Screenshot = $(By.xpath("//div[contains(text(),'" + Value + "')]//parent::td//parent::tr//parent::tbody//parent::thead//parent::table"));
        ElementScreenshot(Search_Table_Screenshot);
    }

    @And("User should not be able to do any modification in requested parameters once the query is submitted.")
    public void NoModificationInRequestedParametersOnceQuerySubmitted() throws InterruptedException {
        ER_search.Parameters_chip.click();
        Thread.sleep(3000);
    }//EndOfFunction

    @Then("Generate Linkages for created Entity profile")
    public void GenerateLinkage() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        executeJavaScript("arguments[0].click();", ER_search.Generate_Linkages.shouldBe(enabled));
        ER_search.Linkage_Heading.shouldBe(visible);
        TakeScreenshot();
    }

    @Then("Click on expand to expand the Linkage graph and to view the complete entity Nodes and Save the generated linkages to created Entity Profile")
    public void ExpandTheLinkage() throws InterruptedException {
        if (ER_search.Linkage_Expand_Button.isDisplayed()) {
            executeJavaScript("arguments[0].click();", ER_search.Linkage_Expand_Button.shouldBe(visible));
            TakeScreenshot();
            executeJavaScript("arguments[0].click();", ER_search.Zoom_In_Button.shouldBe(enabled));
            executeJavaScript("arguments[0].click();", ER_search.Save_To_Profile_Button.shouldBe(enabled));
            ER_search.Entity_Profile_Name.should(Condition.visible).getText();
            executeJavaScript("arguments[0].scrollIntoView(true);", ER_search.Attached_Linkage.shouldBe(visible));
            TakeScreenshot();
        } else {
            scenario.log("No Linkage got generated for the selected Entity Profile");
        }
    }


    //  Functions for Agency Mart Entity profile transfer and Common Mart Entity Profile transfer


    @Then("user should be able to push that ER profile by entering remarks to agency mart")
    public void PushERProfileToAgencyMart() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Select_Entity_Profile.should(Condition.appear));
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.GetActionButton(CaseName, CASE_ACTIONS.Share_to_Agency_Mart.getAction().toString()));
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Perform_Sharing_Profile_Action(Sharing_Actions.Share_To_Agency_Mart.getAction()).should(Condition.appear));
            ViewCaseEntityProfile.Remark_Title.should(Condition.appear);
            ViewCaseEntityProfile.Remark_Textbox.sendKeys("Approving Officer Share the Entity profile ::::: " + Entity_Profile + " from " + CaseName + " ::::: into Agency Mart");


        } else {
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Select_Entity_Profile.should(Condition.appear));
            Thread.sleep(3000);
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.GetActionButton(CaseName, CASE_ACTIONS.Share_to_Agency_Mart.getAction().toString()));
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Perform_Sharing_Profile_Action(Sharing_Actions.Share_To_Agency_Mart.getAction()).should(Condition.appear));
            ViewCaseEntityProfile.Remark_Title.should(Condition.appear);
            ViewCaseEntityProfile.Remark_Textbox.sendKeys("Share the Entity profile ::::: " + Entity_Profile + " from " + CaseName + " ::::: into Agency Mart");
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Checkbox);
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Submit_Button);
            ViewCaseEntityProfile.Push_To_mart_Title.should(Condition.visible);
            executeJavaScript("arguments[0].click();", ViewCaseEntityProfile.Push_data_Button.should(Condition.enabled));
//            }
//            else{
//                scenario.log("Unable to select the Entity Profile checkbox");
//            }
            Thread.sleep(3000);
        }
    }//EndOfFunction

    @Then("The Approving Officer approve the Agency Mart Request under Agency Mart approval page")
    public void ApproveTheAgencyMartRequestERProfile() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        AgencyMartApprovalPage.Intra_Sharing_Approval_Title.should(Condition.visible);
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Pending_Request.should(Condition.visible));
        int colIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ActionColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Action");
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex), "green");
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.Approve_Action_Cell_ByIndex(rowIndex, ActionColIndex).should(Condition.enabled));
        AgencyMartApprovalPage.Use_Case_Request_Approval.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Approve the ER profile into Agency Mart Transfer Request ::::: " + CaseName);
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled));
        Thread.sleep(2000);
        scenario.log("Push to agency mart request is approved successfully" + Entity_Profile + " And for Case " + CaseName);
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Agency_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Expand(CaseName).should(Condition.enabled));
        highlight(AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible).getText());
        AgencyMartApprovalPage.View_Button(Entity_Profile).click();
        AgencyMartApprovalPage.Intra_Sharing_Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.BackToListView.shouldBe(Condition.visible).click();
//        AgencyMartApprovalPage.PersonalInformation.shouldBe(Condition.visible);
    }//EndOfFunction


    @Then("The Approving Officer reject the Agency Mart Request under Agency Mart approval page")
    public void RejectTheAgencyMartRequestERProfile() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        AgencyMartApprovalPage.Intra_Sharing_Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ActionColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Action");
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex), "green");
        AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.Reject_Action_Cell_ByIndex(rowIndex, ActionColIndex).should(Condition.enabled).click();
        AgencyMartApprovalPage.Use_Case_Request_Approval.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Reject the ER profile into Agency Mart Transfer Request ::::: " + CaseName);
        AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled).click();
        Thread.sleep(2000);
        scenario.log("Push to agency mart request is Rejected successfully :::: " + Entity_Profile + " And for Case " + CaseName);
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Agency_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
        AgencyMartApprovalPage.Expand(CaseName).should(Condition.enabled).click();
        highlight(AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible).getText());
        AgencyMartApprovalPage.View_Button(Entity_Profile).click();
        AgencyMartApprovalPage.Intra_Sharing_Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.BackToListView.shouldBe(Condition.visible).click();
//        AgencyMartApprovalPage.PersonalInformation.shouldBe(Condition.visible);
    }//EndOfFunction

    @Then("User should be able to view Entity Profile under Agency Mart table")
    public void EntityProfileUnderAgencyMartTable() throws InterruptedException {
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        AgencyMartPage.ER_Tab.should(Condition.visible).click();
        Thread.sleep(5000);
        $(By.xpath("//div[text()=' Case Name']")).shouldBe(Condition.visible);
        Thread.sleep(4000);
        int colIndex = AgencyMartPage.Agency_Mart_ER_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartPage.Agency_Mart_ER_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartPage.Agency_Mart_ER_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartPage.Agency_Mart_ER_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ProfilecolIndex = AgencyMartPage.Agency_Mart_ER_Table.getColumnIndexByColumnName("Profile Name");
        int ProfilerowIndex = AgencyMartPage.Agency_Mart_ER_Table.getRowIndexByColumnContainingText("Profile Name", Entity_Profile);
        highlight(AgencyMartPage.Agency_Mart_ER_Table.get_Cell_ByIndex(ProfilerowIndex, ProfilecolIndex), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartPage.Agency_Mart_ER_Table.get_Cell_ByIndex(ProfilerowIndex, ProfilecolIndex).getText());

    }//EndOfFunction

    @Then("user should be able to push that ER profile by entering remarks to Common mart")
    public void PushERProfileToCommonMart() {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
//            EntityProfileUnderAgencyMartTable();
            ViewCaseEntityProfile.Entity_Profile(Entity_Profile).should(Condition.appear).click();
            executeJavaScript("arguments[0].click();", $(By.xpath("(//button[contains(text(),'" + Entity_Profile + "')]//parent::div//mat-checkbox[contains(@class,'mat-mdc-checkbox')]//div[@class='mdc-checkbox']//div[@class='mdc-checkbox__background'])[1]")).should(Condition.appear));
            ViewCaseEntityProfile.GetActionButton(CaseName, CASE_ACTIONS.Share_to_Agency_Mart.getAction().toString()).click();
            ViewCaseEntityProfile.Remark_Title.should(Condition.appear);
            ViewCaseEntityProfile.Remark_Textbox.sendKeys("Pushing the Entity profile ::::: " + Entity_Profile + " from " + CaseName + " ::::: into Common Mart");
            ViewCaseEntityProfile.Checkbox.click();
            ViewCaseEntityProfile.Submit_Button.click();
            ViewCaseEntityProfile.Push_To_mart_Title.should(Condition.visible);
            ViewCaseEntityProfile.Push_data_Button.should(Condition.enabled).click();

        } else {
            ViewCaseEntityProfile.Entity_Profile(Entity_Profile).should(Condition.appear).click();
            executeJavaScript("arguments[0].click();", $(By.xpath("(//button[contains(text(),'" + Entity_Profile + "')]//parent::div//mat-checkbox[contains(@class,'mat-mdc-checkbox')]//div[@class='mdc-checkbox']//div[@class='mdc-checkbox__background'])[1]")).should(Condition.appear));
            ViewCaseEntityProfile.GetActionButton(CaseName, CASE_ACTIONS.Share_to_Agency_Mart.getAction().toString()).click();
            ViewCaseEntityProfile.Remark_Title.should(Condition.appear);
            ViewCaseEntityProfile.Remark_Textbox.sendKeys("Pushing the Entity profile ::::: " + Entity_Profile + " from " + CaseName + " ::::: into Common Mart");
            ViewCaseEntityProfile.Checkbox.click();
            ViewCaseEntityProfile.Submit_Button.click();
            ViewCaseEntityProfile.Push_To_mart_Title.should(Condition.visible);
            ViewCaseEntityProfile.Push_data_Button.should(Condition.enabled).click();
        }

    }//EndOfFunction

    @Then("The Approving Officer Recommends the request to push ER profile into Common Mart under Common Mart approval page")
    public void ApprovingOfficerRecommendsTheCommonMartRequest() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        common_mart_approval_page.Common_Mart_Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = common_mart_approval_page.Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = common_mart_approval_page.Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(common_mart_approval_page.Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, common_mart_approval_page.Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        common_mart_approval_page.Expand_The_Request(CaseName).should(Condition.enabled).click();
        highlight(AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible).getText());
        AgencyMartApprovalPage.View_Button(Entity_Profile).click();
        AgencyMartApprovalPage.BackToListView.shouldBe(Condition.visible).click();
        common_mart_approval_page.Common_Mart_Approval_Title.should(Condition.visible);
        common_mart_approval_page.Approve_Request(CaseName).click();
        common_mart_approval_page.Recommendation_Confirmation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Approve the ER profile into Common Mart Transfer Request ::::: " + CaseName);
        AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled).click();
        scenario.log("Push to Common mart request is recommended successfully for Profile " + Entity_Profile + " And for Case " + CaseName + " By Approving Officer");
        common_mart_approval_page.Recommended_Not_Recommended_Requests.click();
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
    }//EndOfFunction

    @Then("The Approving Officer Not Recommended the request to push ER profile into Common Mart under Common Mart approval page")
    public void ApprovingOfficerNotRecommendTheCommonMartRequest() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        common_mart_approval_page.Common_Mart_Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = common_mart_approval_page.Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = common_mart_approval_page.Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(common_mart_approval_page.Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, common_mart_approval_page.Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        common_mart_approval_page.Expand_The_Request(CaseName).should(Condition.enabled).click();
        highlight(AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible).getText());
        AgencyMartApprovalPage.View_Button(Entity_Profile).click();
        AgencyMartApprovalPage.BackToListView.shouldBe(Condition.visible).click();
        common_mart_approval_page.Common_Mart_Approval_Title.should(Condition.visible);
        common_mart_approval_page.Reject_Request(CaseName).click();
        common_mart_approval_page.Recommendation_Confirmation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Not recommending the ER profile into Common Mart Transfer Request ::::: " + CaseName);
        AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled).click();
        scenario.log("Push to Common mart request is not-recommended successfully for Profile " + Entity_Profile + " And for Case " + CaseName + " By Approving Officer");
        common_mart_approval_page.Recommended_Not_Recommended_Requests.click();
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
    }//EndOfFunction
    @Then("The Designated Officer Approves the Common Mart Request under Common Mart approval page")
    public void DesignatedOfficerApproveCommonMartRequest() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        common_mart_approval_page.Approval_Title.isDisplayed();
        Thread.sleep(4000);
        common_mart_approval_page.Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        common_mart_approval_page.Expand_The_Request(CaseName).should(Condition.enabled).click();
        highlight(AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Expand_Profile_Name(CaseName, Entity_Profile).should(Condition.visible).getText());
        AgencyMartApprovalPage.View_Button(Entity_Profile).click();
        TakeScreenshot();
        AgencyMartApprovalPage.BackToListView.shouldBe(Condition.visible).click();
        common_mart_approval_page.Approval_Title.should(Condition.visible);
        int ActionColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Action");
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex), "green");
        AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.Approve_Action_Cell_ByIndex(rowIndex, ActionColIndex).should(Condition.enabled).click();
        AgencyMartApprovalPage.Use_Case_Request_Approval.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Approve the ER profile into Common Mart Transfer Request ::::: " + CaseName);
        AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled).click();
        Thread.sleep(2000);
        scenario.log("Push to Common mart request is Approved successfully for Profile " + Entity_Profile + " And for Case " + CaseName + " By Designated Officer");
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Agency_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
    }//EndOfFunction

    @Then("The Designated Officer Rejects the Common Mart Request under Common Mart approval page")
    public void DesignatedOfficerRejectsCommonMartRequest() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        common_mart_approval_page.Approval_Title.isDisplayed();
        Thread.sleep(4000);
        common_mart_approval_page.Approval_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        common_mart_approval_page.Approval_Title.should(Condition.visible);
        int ActionColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Action");
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex), "green");
        AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.Reject_Action_Cell_ByIndex(rowIndex, ActionColIndex).should(Condition.enabled).click();
        AgencyMartApprovalPage.Use_Case_Request_Approval.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Reject the ER profile into Common Mart Transfer Request ::::: " + CaseName);
        AgencyMartApprovalPage.SUBMIT_BUTTON.should(Condition.enabled).click();
        Thread.sleep(2000);
        scenario.log("Push to Common mart request is Rejected successfully for Profile " + Entity_Profile + " And for Case " + CaseName + " By Designated Officer");
        executeJavaScript("arguments[0].click();", AgencyMartApprovalPage.Agency_Approved_Rejected_Requests);
        highlight(case_initiation.Pending_requests_Requests_CaseName, "green");
    }//EndOfFunction

    @Then("User should be able to view Entity Profile under Common Mart table")
    public void EntityProfileCommonMart() throws InterruptedException {
        String Entity_Profile = scenarioContext.getContext(Context.Entity_Profile_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        AgencyMartPage.ER_Tab.should(Condition.visible).click();
        Thread.sleep(5000);
        $(By.xpath("//div[text()=' Case Name']")).shouldBe(Condition.visible);
        Thread.sleep(4000);
        int colIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ProfileColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Profile Name");
        int ProfileRowIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getRowIndexByColumnContainingText("Profile Name", Entity_Profile);
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(ProfileRowIndex, ProfileColIndex), "green");
        Assert.assertEquals(Entity_Profile, AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(ProfileRowIndex, ProfileColIndex).getText());
        int ActionColIndex = AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.getColumnIndexByColumnName("Action");
        highlight(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex), "green");
        actions().moveToElement(AgencyMartApprovalPage.Agency_Common_Mart_Approval_Table.get_Cell_ByIndex(rowIndex, ActionColIndex)).click();
        AgencyMartApprovalPage.Common_Mart_Title.shouldBe(Condition.visible);
        TakeScreenshot();
    }//EndOfFunction


// Scheduled Query Related Functions and Methods

    @Then("User validate the Case status and Click on Scheduled Query action button to create new Scheduled Query request for Non-Sensitive Use Case :: {string} and {string}")
    public void NewScheduledQueryRequest(String UseCase_Source, String UseCase) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Query_Name = RandomUtils.getUniqueNumber();
        cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.Create_Scheduled_Query.getAction().toString()).click();
        CreateScheduledQuery.Scheduled_Query_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Scheduled_Query_Button);
        CreateScheduledQuery.Create_Scheduled_Query_Title.shouldBe(Condition.visible);
        CreateScheduledQuery.Scheduled_Query_Name.sendKeys("Query_" + Query_Name);

        Thread.sleep(3000);
        CreateScheduledQuery.Case_Name_Field.sendKeys(Case_Name);
        CreateScheduledQuery.Get_Case_Name(Case_Name).click();
        Thread.sleep(2000);
        highlight(CreateScheduledQuery.Source_Field.shouldBe(visible));
        CreateScheduledQuery.Source_Field.sendKeys(UseCase_Source);
        CreateScheduledQuery.Get_Query_Source(UseCase_Source).click();
        executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
        highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
        CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible).click();
        highlight(CreateScheduledQuery.Get_Query_Use_Case(UseCase), "");
        CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        if (CreateScheduledQuery.Use_Case_Error_Message.isDisplayed()) {
            executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
            highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
            CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.enabled).click();
            CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        }
        Thread.sleep(3000);
        if (UseCase.equalsIgnoreCase("List of Passports by Name, Email ID and Gender")) {
            CreateScheduledQuery.Given_Name.sendKeys("Anuradha");
            CreateScheduledQuery.Sur_Name.sendKeys("Malik");
            CreateScheduledQuery.Email_ID.sendKeys("Anuradha_Malik@gmail.com");
        }
        CreateScheduledQuery.Remarks.sendKeys("Request : " + Query_Name);
        executeJavaScript("arguments[0].click();", cases.Checkbox);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Button);
        executeJavaScript("arguments[0].click();", cases.Yes_button.should(Condition.appear));
        Thread.sleep(3000);
        scenarioContext.setContext(Context.Query_Name, Query_Name);
        scenario.log("Query Name ::::: " + Query_Name);
    }//EndOfFunction

    @And("Scheduled Query should be shown in Scheduled Query -> Active Scheduled Queries tab")
    public void ActiveScheduledQueriesTab() throws InterruptedException {
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        Scheduled_Query.Deactivated_Scheduled_Queries.click();
        Thread.sleep(2000);
        Scheduled_Query.Active_Scheduled_Queries.click();
        Thread.sleep(3000);
        int ColIndex = activeScheduledQueries.Active_Scheduled_Query_Table.getColumnIndexByColumnName("Scheduled Query Name");
        int RowIndex = activeScheduledQueries.Active_Scheduled_Query_Table.getRowIndexByColumnContainingText("Scheduled Query Name", Query_Name);
        activeScheduledQueries.Active_Scheduled_Query_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible);
        highlight(activeScheduledQueries.Active_Scheduled_Query_Table.get_Cell_ByIndex(RowIndex, ColIndex), "green");
        Thread.sleep(3000);

        activeScheduledQueries.View_Active_Query_By_Query_Name(Query_Name).click();
        activeScheduledQueries.View_Scheduled_Query_Title.shouldBe(Condition.visible);
        String[] QueryName = activeScheduledQueries.Scheduled_Query_Name.shouldBe(Condition.visible).getText().split(":  ");
        String[] CaseName = activeScheduledQueries.Scheduled_Query_Case_Name.shouldBe(Condition.visible).getText().split(":  ");
        Assert.assertEquals(Query_Name, QueryName[1]);
        Assert.assertEquals(Case_Name, CaseName[1]);
        CreateScheduledQuery.Cancel_Button.click();
    }//EndOfFunction

    public void ScheduledQueryErrormessages() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Query_Name = "";
        cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.Create_Scheduled_Query.getAction().toString()).click();
        CreateScheduledQuery.Scheduled_Query_Title.shouldBe(Condition.visible);
        CreateScheduledQuery.Create_Scheduled_Query_Button.click();
        CreateScheduledQuery.Create_Scheduled_Query_Title.shouldBe(Condition.visible);
        CreateScheduledQuery.Scheduled_Query_Name.click();

        CreateScheduledQuery.Query_Name_Error_Message.shouldBe(Condition.visible);
    }


    @Then("User validate the Case status and Click on Scheduled Query action button to create new Scheduled Query request for Sensitive Use Case :: {string} and {string}")
    public void CreateNewScheduledQueryRequestForSensitiveUseCase(String UseCase_Source, String UseCase) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Query_Name = RandomUtils.getUniqueNumber();
        cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.Create_Scheduled_Query.getAction().toString()).click();
        CreateScheduledQuery.Scheduled_Query_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Scheduled_Query_Button);
        CreateScheduledQuery.Create_Scheduled_Query_Title.shouldBe(Condition.visible);
        CreateScheduledQuery.Scheduled_Query_Name.sendKeys("Query_" + Query_Name);

        Thread.sleep(3000);
        CreateScheduledQuery.Case_Name_Field.sendKeys(Case_Name);
        CreateScheduledQuery.Get_Case_Name(Case_Name).click();
        Thread.sleep(2000);
        CreateScheduledQuery.Source_Field.sendKeys(UseCase_Source);
        CreateScheduledQuery.Get_Query_Source(UseCase_Source).click();
        executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
        highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
        CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible).click();
        highlight(CreateScheduledQuery.Get_Query_Use_Case(UseCase), "");
        CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        if (CreateScheduledQuery.Use_Case_Error_Message.isDisplayed()) {
            executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
            highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
            CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.enabled).click();
            CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        }
        if (UseCase.equalsIgnoreCase("Travel Details of Foreigner by Passport Number and Nationality")) {
            CreateScheduledQuery.Passport_Number.shouldBe(Condition.visible).sendKeys("ZX111114");
            CreateScheduledQuery.Nationality_Drop_Down.click();
            executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Get_Nationality("INDIA").shouldBe(Condition.visible));
            CreateScheduledQuery.Get_Nationality("INDIA").click();
        }
        CreateScheduledQuery.Remarks.sendKeys("Request : " + Query_Name);
        executeJavaScript("arguments[0].click();", cases.Checkbox);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Button);
        executeJavaScript("arguments[0].click();", cases.Yes_button.should(Condition.appear));
        Thread.sleep(3000);
        scenarioContext.setContext(Context.Query_Name, Query_Name);
        scenario.log("Query Name ::::: " + Query_Name);
    }//EndOfFunction

    @Then("Scheduled Query should be shown in Scheduled Query -> Pending for approval Queries tab")
    public void ScheduledQueryPendingForApprovalQueries() throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        Scheduled_Query.Deactivated_Scheduled_Queries.click();
        Thread.sleep(3000);
        commonElements.SPINNER_THREE_DOTS_ICON.shouldNotBe(visible);
        ScheduledQuery.Pending_Approval.click();
        Thread.sleep(3000);
        int ColIndex = pendingForApproval.Pending_For_Approval_Scheduled_Query_Table.getColumnIndexByColumnName("Scheduled Query Name");
        int RowIndex = pendingForApproval.Pending_For_Approval_Scheduled_Query_Table.getRowIndexByColumnContainingText("Scheduled Query Name", Query_Name);
        pendingForApproval.Pending_For_Approval_Scheduled_Query_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible);
        highlight(pendingForApproval.Pending_For_Approval_Scheduled_Query_Table.get_Cell_ByIndex(RowIndex, ColIndex), "green");
        activeScheduledQueries.View_Pending_Query_By_Query_Name(Query_Name).click();
        activeScheduledQueries.View_Scheduled_Query_Title.shouldBe(Condition.visible);
        String[] QueryName = activeScheduledQueries.Scheduled_Query_Name.shouldBe(Condition.visible).getText().split(":  ");
        String[] CaseName = activeScheduledQueries.Scheduled_Query_Case_Name.shouldBe(Condition.visible).getText().split(":  ");
        Assert.assertEquals(Query_Name, QueryName[1]);
        Assert.assertEquals(Case_Name, CaseName[1]);
        CreateScheduledQuery.Cancel_Button.click();
    }//EndOfFunction

    @Then("Officer approves the Scheduled Query request")
    public void supervisoryOfficerApprovesTheScheduledQueryRequest() throws InterruptedException {
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        Query_Approval.Scheduled_Query_Approval_Title.shouldBe(Condition.visible);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Query_Approval.Search_Bar.click();
        Query_Approval.Search_Bar.sendKeys(Query_Name);
        int ColIndex = Query_Approval.Scheduled_Query_Approval_Table.getColumnIndexByColumnName("Name");
        int RowIndex = Query_Approval.Scheduled_Query_Approval_Table.getRowIndexByColumnContainingText("Name", Query_Name);
        System.out.println("ColIndex : " + ColIndex);
        System.out.println("RowIndex : " + RowIndex);
        highlight(Query_Approval.Scheduled_Query_Approval_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible), "green").getText();
        Query_Approval.Expand_The_Request(Query_Name).click();
        Recommendation_Approval.Expand_View_All.click();
        Recommendation_Approval.Back_to_List_View.click();
        TakeScreenshot();
        Thread.sleep(2000);
        executeJavaScript("arguments[0].click();", Query_Approval.ApproveActionButtonByQuery_Name(Query_Name));
        Query_Approval.Scheduled_Query_Approval_Confirmation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Approve the Scheduled Query Request ::::: " + Query_Name);
        executeJavaScript("arguments[0].click();", Recommendation_Approval.Yes_Button.should(Condition.enabled));
        scenario.log("Scheduled Query is Approved successfully by Supervisory Officer");
//        Query_Approval.Scheduled_Query_Approval_Title.shouldBe(Condition.visible);
        Query_Approval.Approved_Rejected_Scheduled_Queries.click();
        highlight(Recommendation_Approval.Recommend_Scheduled_Query_Record, "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Recommend_Scheduled_Query_Record.getText());
        TakeScreenshot();

    }//EndOfFunction



    @And("Validate the status of the scheduled Query under Active Scheduled Queries")
    public void StatusofScheduledQuery() throws InterruptedException {
        String Schld_Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        int ColIndex = activeScheduledQueries.Active_Scheduled_Query_Table.getColumnIndexByColumnName("Scheduled Query Name");
        int RowIndex = activeScheduledQueries.Active_Scheduled_Query_Table.getRowIndexByColumnContainingText("Scheduled Query Name", Schld_Query_Name);
        highlight(activeScheduledQueries.Active_Scheduled_Query_Table.get_Cell_ByIndex(RowIndex,ColIndex),"green");
        activeScheduledQueries.View_Active_Query_By_Query_Name(Schld_Query_Name).click();
        activeScheduledQueries.View_Scheduled_Query_Title.shouldBe(Condition.visible);
        TakeScreenshot();
        String[] QueryName = activeScheduledQueries.Scheduled_Query_Name.shouldBe(Condition.visible).getText().split(":  ");
        Assert.assertEquals(Schld_Query_Name, QueryName[1]);
        String[] Status = activeScheduledQueries.Scheduled_Query_Status.shouldBe(Condition.visible).getText().split(":  ");
        Assert.assertEquals("Approved", Status[1]);
        CreateScheduledQuery.Cancel_Button.click();
    }
    @Then("User validate the Case status and Click on Scheduled Query action button to create new Scheduled Query request for Highly-Sensitive Use Case :: {string} and {string}")
    public void HighlySensitiveUseCaseRequest(String UseCase_Source, String UseCase) throws InterruptedException {
        String Case_Name = scenarioContext.getContext(Context.CASENAME).toString();
        String Query_Name = RandomUtils.getUniqueNumber();
        cases.getActionButtonByCaseName(Case_Name, CASE_ACTIONS.Create_Scheduled_Query.getAction().toString()).click();
        CreateScheduledQuery.Scheduled_Query_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Scheduled_Query_Button);
        CreateScheduledQuery.Create_Scheduled_Query_Title.shouldBe(Condition.visible);
        CreateScheduledQuery.Scheduled_Query_Name.sendKeys("Query_" + Query_Name);

        Thread.sleep(3000);
        CreateScheduledQuery.Case_Name_Field.sendKeys(Case_Name);
        CreateScheduledQuery.Get_Case_Name(Case_Name).click();
        Thread.sleep(2000);
        CreateScheduledQuery.Source_Field.sendKeys(UseCase_Source);
        CreateScheduledQuery.Get_Query_Source(UseCase_Source).click();
        executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
        highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
        CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible).click();
        highlight(CreateScheduledQuery.Get_Query_Use_Case(UseCase).shouldBe(Condition.visible), "");
        CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        if (CreateScheduledQuery.Use_Case_Error_Message.isDisplayed()) {
            executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible));
            highlight(CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.visible), "");
            CreateScheduledQuery.Select_Use_Case.shouldBe(Condition.enabled).click();
            CreateScheduledQuery.Get_Query_Use_Case(UseCase).click();
        }
        if (UseCase.equalsIgnoreCase("Get Bank Account Details for Permanent Account Number (PAN) and FY")) {
            CreateScheduledQuery.Pan_Number.shouldBe(Condition.visible).sendKeys("ADJPU1080H");
        }
        CreateScheduledQuery.Remarks.sendKeys("Request : " + Query_Name);
        cases.Checkbox.click();
        executeJavaScript("arguments[0].scrollIntoView(true);", CreateScheduledQuery.Create_Button);
        executeJavaScript("arguments[0].click();", CreateScheduledQuery.Create_Button);
        executeJavaScript("arguments[0].click();", cases.Yes_button.should(Condition.appear));
        scenarioContext.setContext(Context.Query_Name, Query_Name);
        scenario.log("Query Name ::::: " + Query_Name);
    }//EndOfFunction

    @Then("Supervisory Officer Recommends the Scheduled Query request")
    public void SupervisoryRecommendsQueryRequest() throws InterruptedException {
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
//        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        Recommendation_Approval.Recommendation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Thread.sleep(3000);
        int colIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("Name");
        int rowIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getRowIndexByColumnContainingText("Name", Query_Name);
        highlight(Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());

        Recommendation_Approval.Sch_Qury_Related_Activity(Query_Name, "Expand").shouldBe(visible).click();
        Recommendation_Approval.Expand_View_All.click();
        Recommendation_Approval.Back_to_List_View.click();
        TakeScreenshot();
        executeJavaScript("arguments[0].click();", Recommendation_Approval.Approved_By_Query_Name(Query_Name));

        Recommendation_Approval.Recommendation_Confirmation_Title.shouldBe(visible);
        highlight(AgencyMartApprovalPage.Request_Textbox, "green").click();
        AgencyMartApprovalPage.Request_Textbox.sendKeys("Recommend the Scheduled Query Request ::::: " + Query_Name);
        executeJavaScript("arguments[0].click();", Recommendation_Approval.Yes_Button.should(Condition.enabled));
        scenario.log("Scheduled Query is Recommended successfully by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Recommendation_Approval.Recommend_Scheduled_Query_Record, "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Recommend_Scheduled_Query_Record.getText());
        TakeScreenshot();
    }//EndOfFunction

    @Then("Supervisory Officer doesn't Recommends the Scheduled Query request")
    public void supervisoryOfficerNotRecommendQueryRequest() {
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        Recommendation_Approval.Recommendation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        int colIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("Name");
        int rowIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getRowIndexByColumnContainingText("Name", Query_Name);
        highlight(Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
//        executeJavaScript("arguments[0].scrollIntoView(true);", common_mart_approval_page.Approve_Request(Query_Name).shouldBe(Condition.visible));
        Recommendation_Approval.Sch_Qury_Related_Activity(Query_Name, "Expand");
        executeJavaScript("arguments[0].click();", Recommendation_Approval.Rejected_By_Query_Name(Query_Name));
        Recommendation_Approval.Not_Recommendation_Confirmation_Title.shouldBe(visible);
        highlight(AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled), "Green").sendKeys("Scheduled Query Request is not Recommend ::::: " + Query_Name);
        executeJavaScript("arguments[0].click();", Recommendation_Approval.Yes_Button.should(Condition.enabled));
        scenario.log("Scheduled Query is not Recommended by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Recommendation_Approval.Recommend_Scheduled_Query_Record, "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Recommend_Scheduled_Query_Record.getText());
        TakeScreenshot();
    }//EndOfFunction

    @Then("Officer rejects the Scheduled Query request")
    public void RejectScheduledQueryRequest() throws InterruptedException {
        String Query_Name = "Query_" + scenarioContext.getContext(Context.Query_Name).toString();
        Query_Approval.Scheduled_Query_Approval_Title.shouldBe(Condition.visible);
        Thread.sleep(3000);
        int ColIndex = Query_Approval.Scheduled_Query_Approval_Table.getColumnIndexByColumnName("Name");
        int RowIndex = Query_Approval.Scheduled_Query_Approval_Table.getRowIndexByColumnContainingText("Name", Query_Name);
        System.out.println("ColIndex : " + ColIndex);
        System.out.println("RowIndex : " + RowIndex);
        highlight(Query_Approval.Scheduled_Query_Approval_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible), "green");
        executeJavaScript("arguments[0].click();", Query_Approval.RejectActionButtonByQuery_Name(Query_Name));
        Query_Approval.Scheduled_Query_Approval_Confirmation_Title.should(Condition.visible);
        AgencyMartApprovalPage.Request_Textbox.should(Condition.enabled).sendKeys("Reject the Scheduled Query Request ::::: " + Query_Name);
        Recommendation_Approval.Yes_Button.should(Condition.enabled).click();
        scenario.log("Scheduled Query is not Approved by Approving Officer");
//        Query_Approval.Scheduled_Query_Approval_Title.shouldBe(Condition.visible);
        Query_Approval.Approved_Rejected_Scheduled_Queries.click();
        highlight(Recommendation_Approval.Recommend_Scheduled_Query_Record, "green");
        Assert.assertEquals(Query_Name, Recommendation_Approval.Recommend_Scheduled_Query_Record.getText());
        TakeScreenshot();

    }//EndOfFunction


    @Then("User select Use Case search for specific Providing Organization {string} and Click on Use Case {string} and submit Use-Case with {string}")
    public void userSelectUseCaseSearchForSpecificProvidingOrganization(String PO, String UseCase, String PANno) throws InterruptedException {
        UseCaseSearch.Select_PO(PO).click();
        executeJavaScript("arguments[0].scrollIntoView(true);", UseCaseSearch.Use_Case_Table(PO).shouldBe(Condition.appear));
        highlight(UseCaseSearch.Use_Case_Table(PO).shouldBe(Condition.appear), "green");
        highlight(UseCaseSearch.Use_Case(PO, UseCase), "Green").click();
        UseCaseSearch.Use_Case_request_Page_Heading(UseCase).shouldBe(Condition.visible);
        if (PO.equalsIgnoreCase("CBDT")) {
            if (UseCase.equalsIgnoreCase("Get Permanent Account Number (PAN) Details")) {
                Thread.sleep(2000);
                UseCaseSearch.PANno.sendKeys(PANno);
                Thread.sleep(2000);
                UseCaseSearch.Add_Button.click();
                UseCaseSearch.SelectedUseCase.click();
                TakeScreenshot();
                UseCaseSearch.Ok_Button.click();
                Thread.sleep(3000);
                commonElements.Vertical_Loader.shouldNotBe(visible);
                executeJavaScript("arguments[0].click();", UseCaseSearch.Submit_Button);
                UseCaseSearch.LowUseCase.click();
                UseCaseSearch.CommentsText.sendKeys("Non-Sensitive Use Case");
                UseCaseSearch.Declaration.click();
                executeJavaScript("arguments[0].click();", UseCaseSearch.Submit_Button_UseCase);
                Thread.sleep(3000);
            } else if (UseCase.equalsIgnoreCase("Get Tax Deduction and Collection Account Number (TAN) Details")) {
                UseCaseSearch.TANno.sendKeys(PANno);
                Thread.sleep(2000);
                UseCaseSearch.Add_Button.click();
                Thread.sleep(2000);
                UseCaseSearch.SelectedUseCase.click();
                TakeScreenshot();
                Thread.sleep(2000);
                UseCaseSearch.Ok_Button.click();
                ElementScreenshot(UseCaseSearch.Use_Case_chip);
                Thread.sleep(3000);
                commonElements.Vertical_Loader.shouldNotBe(visible);
                UseCaseSearch.Submit_Button.click();
                if (UseCaseSearch.LowUseCase.isDisplayed()) {
                    UseCaseSearch.LowUseCase.click();
                }
                UseCaseSearch.CommentsText.sendKeys("Sensitive Use Case");
                UseCaseSearch.Declaration.click();
                executeJavaScript("arguments[0].click();", UseCaseSearch.Submit_Button_UseCase);
                Thread.sleep(3000);
                commonElements.Vertical_Loader.shouldNotBe(visible);
                if(UseCaseSearch.Confirmation_Title_Heading.isDisplayed()) {
                    UseCaseSearch.Confirmation_Title_Heading.shouldBe(visible);
                }
                UseCaseSearch.Confirmation_Ok_Button.shouldBe(enabled).click();
                Thread.sleep(3000);


            } else if (UseCase.equalsIgnoreCase("Get Bank Account Details for Permanent Account Number (PAN) and FY")) {
                String Finanacial_Year = "2015-16";
                UseCaseSearch.Financial_Year.click();
                Thread.sleep(3000);
                UseCaseSearch.Financial_Year_Search.sendKeys(Finanacial_Year);
                Thread.sleep(3000);
                UseCaseSearch.Financial_Year(Finanacial_Year).click();
                UseCaseSearch.PANno.sendKeys(PANno);
                UseCaseSearch.Year_Range.click();
                UseCaseSearch.Select_Year_Range.click();
                UseCaseSearch.Add_Button.click();
                Thread.sleep(2000);
                UseCaseSearch.SelectedUseCase.click();
                TakeScreenshot();
                UseCaseSearch.Ok_Button.click();
                commonElements.Vertical_Loader.shouldNotBe(visible);
                executeJavaScript("arguments[0].click();", UseCaseSearch.Submit_Button);
                if(UseCaseSearch.LowUseCase.isDisplayed()) {
                    executeJavaScript("arguments[0].click();", UseCaseSearch.LowUseCase);
                }
                UseCaseSearch.CommentsText.sendKeys("Highly-Sensitive Use Case");
                UseCaseSearch.Declaration.click();
                UseCaseSearch.Submit_Button_UseCase.click();
                Thread.sleep(3000);
                commonElements.Vertical_Loader.shouldNotBe(visible);
                UseCaseSearch.Confirmation_Title_Heading.shouldBe(visible);
                executeJavaScript("arguments[0].click();", UseCaseSearch.Confirmation_Ok_Button.shouldBe(enabled));
                Thread.sleep(3000);
            }
        }

    }

    @Then("User check in Request-Response tab")
    public void userCheckInRequestResponseTab() {
        UseCaseSearch.RequestResponseTab.click();
        TakeScreenshot();
    }

    @Then("User clicks ok to confirm")
    public void userClicksOkToConfirm() throws InterruptedException {
        Thread.sleep(5000);
        UseCaseSearch.ConfirmOk.click();
    }

    @When("user navigates to UAPortal -> Request_Response_Approvals -> Use_Case_Approvals")
    public void userNavigatesToUAPortalRequest_Response_ApprovalsUse_Case_Approvals() throws InterruptedException {
        Case_Approval.RequestResponseApprovals.click();
        Case_Approval.UseCaseQueriesApprovals.click();
    }

    @Then("Approving_Officer approves the Use Case Query request")
    public void approving_officerApprovesTheUseCaseQueryRequest() throws InterruptedException {
        String CASEID = scenarioContext.getContext(Context.CASEID).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        Query_Approval.Use_Case_Query_Approval_Title.shouldBe(Condition.visible);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Query_Approval.Search_Bar.click();
        Query_Approval.Search_Bar.sendKeys(CaseName);
        Thread.sleep(3000);
        int ColIndex = Query_Approval.Scheduled_Query_Approval_Table.getColumnIndexByColumnName("Case Name");
        int RowIndex = Query_Approval.Scheduled_Query_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        System.out.println("ColIndex : " + ColIndex);
        System.out.println("RowIndex : " + RowIndex);
        highlight(Query_Approval.Scheduled_Query_Approval_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible), "green").getText();
        String Sub_Request_ID = Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(RowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText();
        scenario.log("Sub Request ID :::: " + Sub_Request_ID);
        Case_Approval.Use_Case_Qury_Related_Activity(CaseName, "View").shouldBe(visible).click();
        TakeScreenshot();
        Recommendation_Approval.Back_to_List_View.click();
        executeJavaScript("arguments[0].click();", Case_Approval.Use_Case_Query_Approval(CaseName));
        Case_Approval.Approval_Confirmation_Title.shouldBe(visible);
        highlight(Case_Approval.Request_Remarks, "green").click();
        Case_Approval.Request_Remarks.sendKeys("Approve the Use Case Query Request ::::: " + CaseName);
        executeJavaScript("arguments[0].click();", Case_Approval.Submit_Button.should(Condition.enabled));
        scenario.log("Use Case Query is Approved successfully by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Case_Approval.Recommend_Request, "green");
        Assert.assertEquals(CaseName, Case_Approval.Recommend_Request.getText());
        TakeScreenshot();
    }


    @When("user navigates to UAPortal -> Request_Response_Approvals -> Recommendation")
    public void userNavigatesToUAPortalRequest_Response_ApprovalsRecommendation() throws InterruptedException {
        Case_Approval.RequestResponseApprovals.click();
        Case_Approval.UseCaseQueryRecommendation.click();

    }

    @Then("Supervisory Officer Recommends the Use Case Query request")
    public void supervisoryOfficerRecommendsTheUseCaseQueryRequest() throws InterruptedException {
        String CASEID = scenarioContext.getContext(Context.CASEID).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        Case_Approval.SearchRequest.sendKeys(CASEID);
        Case_Approval.UseCaseRecommend_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        Thread.sleep(3000);
        int colIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        String Sub_Request_ID = Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText();
        scenario.log("Sub Request ID :::: " + Sub_Request_ID);
        Case_Approval.Use_Case_Qury_Related_Activity(CaseName, "View").shouldBe(visible).click();
//        Assert.assertEquals(Sub_Request_ID, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText());
        Recommendation_Approval.Back_to_List_View.click();
        executeJavaScript("arguments[0].click();", Case_Approval.Use_Case_Query_Recommendation(CaseName));
        Recommendation_Approval.Recommendation_Confirmation_Title.shouldBe(visible);
        highlight(Case_Approval.Request_Remarks, "green").click();
        Case_Approval.Request_Remarks.sendKeys("Recommend the Use Case Query Request ::::: " + CaseName);
        executeJavaScript("arguments[0].click();", Case_Approval.Submit_Button.should(Condition.enabled));
        scenario.log("Use Case Query is Recommended successfully by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Case_Approval.Recommend_Request, "green");
        Assert.assertEquals(CaseName, Case_Approval.Recommend_Request.getText());
        TakeScreenshot();
    }


    @Then("Approving_Officer rejects the Use Case Query request")
    public void approving_officerRejectsTheUseCaseQueryRequest() throws InterruptedException {
        String CASEID = scenarioContext.getContext(Context.CASEID).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();

        Query_Approval.Use_Case_Query_Approval_Title.shouldBe(Condition.visible);
        commonElements.Vertical_Loader.shouldNotBe(visible);
        Query_Approval.Search_Bar.click();
        Query_Approval.Search_Bar.sendKeys(CaseName);
        int ColIndex = Query_Approval.Scheduled_Query_Approval_Table.getColumnIndexByColumnName("Case Name");
        int RowIndex = Query_Approval.Scheduled_Query_Approval_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        System.out.println("ColIndex : " + ColIndex);
        System.out.println("RowIndex : " + RowIndex);
        highlight(Query_Approval.Scheduled_Query_Approval_Table.get_Cell_ByIndex(RowIndex, ColIndex).shouldBe(Condition.visible), "green").getText();

        String Sub_Request_ID = Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(RowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText();
        scenario.log("Sub Request ID :::: " + Sub_Request_ID);
        Case_Approval.Use_Case_Qury_Related_Activity(CaseName, "View").shouldBe(visible).click();
        TakeScreenshot();
        Recommendation_Approval.Back_to_List_View.click();
        executeJavaScript("arguments[0].click();", Case_Approval.Use_Case_Query_Reject(CaseName));
        Case_Approval.Reject_Confirmation_Title.shouldBe(visible);
        highlight(Case_Approval.Request_Remarks, "green").click();
        Case_Approval.Request_Remarks.sendKeys("Reject the Use Case Query Request ::::: " + CaseName);
        executeJavaScript("arguments[0].click();", Case_Approval.Yes_Button.should(Condition.enabled));
        scenario.log("Use Case Query is Rejected successfully by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Case_Approval.Recommend_Request, "green");
        Assert.assertEquals(CaseName, Case_Approval.Recommend_Request.getText());
        TakeScreenshot();

    }

    @Then("Supervisory Officer does not Recommend the Use Case Query request")
    public void supervisoryOfficerDoesNotRecommendTheUseCaseQueryRequest() throws InterruptedException {

        String CASEID = scenarioContext.getContext(Context.CASEID).toString();
        String CaseName = scenarioContext.getContext(Context.CASENAME).toString();
        Thread.sleep(5000);
        Case_Approval.SearchRequest.sendKeys(CASEID);
        Case_Approval.UseCaseRecommend_Title.should(Condition.visible);
        AgencyMartApprovalPage.Pending_Request.should(Condition.visible).click();
        Thread.sleep(3000);
        int colIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("Case Name");
        int rowIndex = Recommendation_Approval.Scheduled_Query_Recommendation_Table.getRowIndexByColumnContainingText("Case Name", CaseName);
        highlight(Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(CaseName, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        String Sub_Request_ID = Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText();
        scenario.log("Sub Request ID :::: " + Sub_Request_ID);
        Case_Approval.Use_Case_Qury_Related_Activity(CaseName, "View").shouldBe(visible).click();
        TakeScreenshot();
//        Assert.assertEquals(Sub_Request_ID, Recommendation_Approval.Scheduled_Query_Recommendation_Table.get_Cell_ByIndex(rowIndex, Recommendation_Approval.Scheduled_Query_Recommendation_Table.getColumnIndexByColumnName("SubRequest ID")).getText());
        Recommendation_Approval.Back_to_List_View.click();
        executeJavaScript("arguments[0].click();", Case_Approval.Use_Case_Query_Not_Recommended(CaseName));
        Recommendation_Approval.Not_Recommendation_Confirmation_Title.shouldBe(visible);
        highlight(Case_Approval.Request_Remarks, "green").click();
        Case_Approval.Request_Remarks.sendKeys("Don't recommend the Use Case Query Request ::::: " + CaseName);
        executeJavaScript("arguments[0].click();", Case_Approval.Yes_Button.should(Condition.enabled));
        scenario.log("Use Case Query is not Recommended successfully by Supervisory Officer");
        Recommendation_Approval.Recommended_Not_Recommended_Requests.click();
        highlight(Case_Approval.Recommend_Request, "green");
        Assert.assertEquals(CaseName, Case_Approval.Recommend_Request.getText());
        TakeScreenshot();

    }
}//class
