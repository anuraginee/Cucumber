/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.ua;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class UALeftHamburgerMenuStepDef {
    @Autowired
    private UA_dashboard ua_dashboard;

    @Autowired
    private CommonElements commonElements;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    /**
     *
     * @param scenario scenario
     */
    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    /**
     *
     */
    @When("user navigates to UAPortal -> Case Management")
    public void userNavigatesToMenuCase_Management() {
        ua_dashboard.case_Management.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Scheduled_Query_Management")
    public void userNavigatesToMenuScheduled_Query_Management() {
        ua_dashboard.Scheduled_Query_Management.should(Condition.enabled).click();
    }
    @When("user navigates to UAPortal -> Scheduled_Query_Management -> Scheduled_Query")
    public void userNavigatesToMenuScheduled_Query_Management_Scheduled_Query() {
        if (ua_dashboard.Scheduled_Query.isDisplayed()) {
            ua_dashboard.Scheduled_Query.should(Condition.enabled).click();
        } else {
            ua_dashboard.Scheduled_Query_Management.should(Condition.enabled).click();
            ua_dashboard.Scheduled_Query.should(Condition.enabled).click();
        }
    }

    @When("user navigates to UAPortal -> Case_Related_Approvals")
    public void userNavigatesToMenuCase_Related_Approvals() {
        ua_dashboard.Case_Related_Approvals.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Request_Response_Approvals")
    public void userNavigatesToMenuRequest_Response_Approvals() {
        ua_dashboard.Request_Response_Approvals.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Scheduled_Query_Approvals")
    public void userNavigatesToMenuScheduled_Query_Approvals() {
        ua_dashboard.Scheduled_Query_Approvals.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Scheduled_Query_Approvals -> Approvals")
    public void userNavigatesToMenuScheduled_Query_Approvals_Approvals() {
        if (ua_dashboard.Approval.isDisplayed()) {
            ua_dashboard.Approval.should(Condition.enabled).click();
        } else {
            ua_dashboard.Scheduled_Query_Approvals.should(Condition.enabled).click();
            ua_dashboard.Approval.should(Condition.enabled).click();
        }
    }

    @When("user navigates to UAPortal -> Intra Agency Approval -> Sharing Approval")
    public void userNavigatesToMenuIntra_Mart_Approval() {
        if (ua_dashboard.Sharing_Approval.isDisplayed()) {
            ua_dashboard.Sharing_Approval.click();
        } else {
            ua_dashboard.Intra_Agency_Approval.should(Condition.enabled).click();
            ua_dashboard.Sharing_Approval.shouldBe(Condition.appear).click();
        }
    }

    @When("user navigates to UAPortal -> Inter Agency Approval -> Sharing Approval")
    public void userNavigatesToMenuInter_Mart_Approval() {
        if (ua_dashboard.Sharing_Approval.isDisplayed()) {
            ua_dashboard.Sharing_Approval.click();
        } else {
            ua_dashboard.Intra_Agency_Approval.should(Condition.enabled).click();
            ua_dashboard.Sharing_Approval.shouldBe(Condition.appear).click();
        }
    }

    @When("user navigates to UAPortal -> Intra Agency Approval -> Agency Mart")
    public void userNavigatesToMenuIntra_Mart_Sharing() {
        if (ua_dashboard.Agency_Mart.isDisplayed()) {
            ua_dashboard.Agency_Mart.click();
        } else {
            ua_dashboard.Intra_Agency_Sharing.should(Condition.enabled).click();
            ua_dashboard.Agency_Mart.shouldBe(Condition.appear).click();
        }
    }

    @When("user navigates to UAPortal -> Inter Agency Approval -> Common Mart")
    public void userNavigatesToMenuInter_Mart_Sharing() {
        if (ua_dashboard.Agency_Mart.isDisplayed()) {
            ua_dashboard.Agency_Mart.click();
        } else {
            ua_dashboard.Inter_Agency_Sharing.should(Condition.enabled).click();
            ua_dashboard.Common_Mart.shouldBe(Condition.appear).click();
        }
    }


    @When("user navigates to UAPortal -> Inter Agency Approval -> Sharing Recommendation")
    public void userNavigatesToMenuInter_Mart_Approval_Recommendation() {
        if (ua_dashboard.Sharing_Approval.isDisplayed()) {
            ua_dashboard.Sharing_Approval.click();
        } else {
            ua_dashboard.Intra_Agency_Approval.should(Condition.enabled).click();
            ua_dashboard.Sharing_Approval.shouldBe(Condition.appear).click();
        }
    }

    @When("user navigates to UAPortal -> User_Management")
    public void userNavigatesToMenuUser_Management() {
        ua_dashboard.User_Management.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> User_Management ->Update_Profile")
    public void userNavigatesToMenuUser_Management_Update_Profile() {
        if (ua_dashboard.update_Profile.isDisplayed()) {
            ua_dashboard.update_Profile.click();
        } else {
            ua_dashboard.User_Management.should(Condition.enabled).click();
            ua_dashboard.update_Profile.shouldBe(Condition.appear).click();
        }

    }


    @When("user navigates to UAPortal -> Entity_Profiles")
    public void userNavigatesToMenuEntity_Profiles() {
        ua_dashboard.Entity_Profiles.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Agency_Mart")
    public void userNavigatesToMenuAgency_Mart() {
        ua_dashboard.Agency_Mart.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Common_Mart")
    public void userNavigatesToMenuCommon_Mart() {
        ua_dashboard.Common_Mart.should(Condition.enabled).click();
    }
    @When("user navigates to UAPortal -> Common_Mart_Approval -> Recommendation")
    public void userNavigatesToMenuCommon_Mart_Approval_Recommendation() {
        if (ua_dashboard.Recommendation.isDisplayed()) {
            ua_dashboard.Recommendation.should(Condition.enabled).click();
        } else {
            ua_dashboard.Inter_Agency_Approval.should(Condition.enabled).click();
            ua_dashboard.Recommendation.should(Condition.enabled).click();
        }
    }

    @When("user navigates to UAPortal -> Reports")
    public void userNavigatesToMenuReports() {
        ua_dashboard.Reports.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> User_Activity_Logs")
    public void userNavigatesToMenuUser_Activity_Logs() {
        ua_dashboard.User_Activity_Logs.should(Condition.enabled).click();
    }

    @When("user navigates to UAPortal -> Feedback")
    public void userNavigatesToMenuFeedback() {
        ua_dashboard.Feedback.should(Condition.enabled).click();
    }


    @When("Nodal user navigates to UAPortal -> Manage Terminal -Gandiva")
    public void nodalNavigatesToManageTerminal(){
        ua_dashboard.manageTerminal.should(Condition.enabled).click();

    }
    @When("Nodal user navigates to UAPortal -> Manage USB")
    public void nodalNavigatesToManageUSB() {
        ua_dashboard.manageUSBUA.should(Condition.enabled).click();
    }

        @When("user navigates to UAPortal -> Scheduled_Query_Approvals -> Recommendation")
    public void Scheduled_Query_Approvals_Recommendation() {
        if (ua_dashboard.Recommendation.isDisplayed()) {
            ua_dashboard.Recommendation.should(Condition.enabled).click();
        } else {
            ua_dashboard.Scheduled_Query_Approvals.should(Condition.enabled).click();
            ua_dashboard.Recommendation.should(Condition.enabled).click();
        }

    }

}