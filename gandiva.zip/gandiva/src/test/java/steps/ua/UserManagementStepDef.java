/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package steps.ua;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;

import PageObject.UserAgentPortal.UserManagement.CreateUser.Create_User;
import PageObject.UserAgentPortal.UserManagement.CreateUser.Update_User;
import PageObject.UserAgentPortal.UserManagement.Users;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.junit5.ScreenShooterExtension;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import io.cucumber.java.en_scouse.An;
import org.apache.poi.ss.formula.functions.T;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;

import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;

import steps.LoginStepDef;
import utils.Context.Context;
import utils.PropertyUtils;
import utils.RandomUtils;
import utils.ScenarioContext;

import utils.SelectDropDown.SelectDropDownValue;
import utils.WebDriverFactory;
import utils.enums.DASHBOARD_WIDGETS;
import utils.table.tableImpl;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import static com.codeborne.selenide.Condition.enabled;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import static steps.CommonStepDef.ElementScreenshot;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;
import static utils.WebDriverFactory.FirstTimeLogin;


@ExtendWith({ScreenShooterExtension.class})
public class UserManagementStepDef {
    @Autowired
    private Users User_page;
    @Autowired
    private UA_dashboard ua_dashboard;
    @Autowired
    private Create_User create_user;
    @Autowired
    private CommonElements commonelements;

    @Autowired
    private Update_User updateUser;


    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext scenarioContext = new ScenarioContext();


    Map<String, Integer> map_nodal = new HashMap<String, Integer>();

    @When("user navigates to UAPortal -> User management -> Users")
    public void UserNavigatesToMenuUser_Management_Users() throws InterruptedException {

        if (User_page.Users_Tab.isDisplayed()) {
            User_page.Users_Tab.should(Condition.enabled).click();
        } else {
            ua_dashboard.User_Management.should(Condition.enabled).click();
            User_page.Users_Tab.should(Condition.enabled).click();
        }
    }


    @And("User takes the snapshot of User Widget present on the Dashboard page")
    public void DashboardSnapshot() throws InterruptedException {
//       Adding sleep for system to wait till case related count in dashboard gets updated

        Thread.sleep(10000);
        map_nodal.put(DASHBOARD_WIDGETS.USERS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.USERS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.USERS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.USERS_TOTAL.getParamName()).getText()));
        map_nodal.put(DASHBOARD_WIDGETS.USERS_ACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.USERS_ACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.USERS_ACTIVE.getWidgetName(), DASHBOARD_WIDGETS.USERS_ACTIVE.getParamName()).getText()));
        map_nodal.put(DASHBOARD_WIDGETS.USERS_INACTIVE.getWidgetName() + "_" + DASHBOARD_WIDGETS.USERS_INACTIVE.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.USERS_INACTIVE.getWidgetName(), DASHBOARD_WIDGETS.USERS_INACTIVE.getParamName()).getText()));
        TakeScreenshot();
    }

    @And("Create new user {string} with relevant details")
    public void NewAuthorizedOfficer(String User_Role) throws InterruptedException {
        String[] parts = User_Role.split(" ");
        String User_Name = parts[0] + RandomUtils.generateUniqueAlphabetName();
        String EmailID = RandomUtils.generateRandomEmail();
        String Contact_Number = RandomUtils.generateRandomMobileNumber(10);
        String Login_Unique_ID = "demo" + RandomUtils.generateUniqueString();
        executeJavaScript("arguments[0].click();", create_user.Create_Users);
        create_user.Create_User_title.should(Condition.visible);
        create_user.UserName.sendKeys(User_Name);
        create_user.EmailID.sendKeys(EmailID);
        create_user.User_Role.click();
        create_user.Select_User_Role(User_Role).shouldBe(visible).click();
        Thread.sleep(3000);
        create_user.LoginID.sendKeys(Login_Unique_ID);
        String Officer_Login_ID = create_user.Login_ID_prefix.getText() + Login_Unique_ID + create_user.LoginID_Domain.getText();
        scenario.log("Login ID for " + User_Role + " : " + Officer_Login_ID);
        create_user.Rank_Field.click();
        create_user.Select_Rank_DropDown.should(Condition.visible).click();
        create_user.Portal_Access_Field.click();
        create_user.Gandiva_Portal.should(Condition.visible).click();
        actions().moveToElement(create_user.UserName).click().perform();
        create_user.Gandiva_Portal.shouldNotBe(Condition.visible);
        create_user.Contact_Number_Field.should(Condition.editable).sendKeys(Contact_Number);
        create_user.Address.sendKeys("Pune");
        create_user.Menu_and_Access_Permission_Heading.should(Condition.visible);
//        actions().scrollToElement(create_user.Menu_and_Access_Permission_Menu_Tab_Header).perform();
        Assert.assertEquals("GANDIVA", create_user.Menu_and_Access_Permission_Menu_Tab_Header.getText());
        for (SelenideElement e : create_user.menu_Permissions) {
            System.out.println(e.getText());
        }
        TakeScreenshot();
        $(commonelements.SUBMIT_BUTTON).scrollIntoView(true);
        executeJavaScript("arguments[0].click();", commonelements.SUBMIT_BUTTON.shouldBe(Condition.enabled));
        String Login_Id = create_user.Login_ID_prefix.getText() + Login_Unique_ID;
        scenarioContext.setContext(Context.Login_ID_Officer, Login_Id);
    }


    @And("Nodal officer should get success message after creation of new user")
    public void SuccessMessageOfUserCreation() throws InterruptedException {
        String successToastMessage = User_page.ToastMessage.getText();
        ElementScreenshot(User_page.ToastMessage);
//        Assert.assertEquals("User created sucessfully.", successToastMessage);
        Thread.sleep(5000);
    }

    @And("Validate the newly created user in users table")
    public void validateTheNewlyCreatedCaseInManageUserTable() throws InterruptedException {
        final tableImpl User_table = new tableImpl($(By.xpath("//table[contains(@class,'mat-mdc-table')]")).should(Condition.appear));

        String Login_Id = scenarioContext.getContext(Context.Login_ID_Officer).toString();
        int colIndex = User_table.getColumnIndexByColumnName("Login ID");
        int rowIndex = User_table.getRowIndexByColumnContainingText("Login ID", Login_Id + "@devng.in");
        System.out.println(colIndex);
        System.out.println(rowIndex);
        highlight(User_table.get_Cell_ByIndex(rowIndex, colIndex), "green");
        System.out.println("Get cell by Index value :: " + User_table.get_Cell_ByIndex(rowIndex, colIndex));
        Assert.assertEquals(Login_Id + "@devng.in", User_table.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int colIndex1 = User_table.getColumnIndexByColumnName("Password");
        int rowIndex1 = User_table.getRowIndexByColumnContainingText("Login ID", Login_Id + "@devng.in");
        System.out.println(colIndex1);
        System.out.println(rowIndex1);
        Thread.sleep(3000);

        create_user.passIcon.should(Condition.appear).click();
        String temp_Password = create_user.firstTimePassword.getText();
        String[] arr = temp_Password.split(":");
        String firstTimePassword = arr[1];
        System.out.println(firstTimePassword);
        create_user.popUpClose.click();
        System.out.println(temp_Password);
        scenarioContext.setContext(Context.Temp_Password, firstTimePassword);

    }


    @When("New user login to the Application")
    public void FirstTimeLoginToResetPassword() throws InterruptedException {
        String Password = scenarioContext.getContext(Context.Temp_Password).toString();
        System.out.println(Password);
        String Login_Id = scenarioContext.getContext(Context.Login_ID_Officer).toString();
        System.out.println(Login_Id);
        LoginStepDef loginStepDef = new LoginStepDef();
        loginStepDef.Open("UA");
        loginStepDef.LoginWithTempCredentials(Login_Id, Password);
        create_user.currentPassword.should(Condition.appear).sendKeys(Password);
        create_user.newPassword.should(Condition.appear).sendKeys(PropertyUtils.getPassword());
        create_user.confirmNewPassword.should(Condition.appear).sendKeys(PropertyUtils.getPassword());
        create_user.Disclaimer.should(visible);
        create_user.Agree_checkbox.should(Condition.visible).click();
        create_user.resetPasswordSubmit.shouldBe(enabled).click();
//        executeJavaScript("arguments[0].click();", create_user.resetPasswordSubmit);
        Thread.sleep(3000);
        loginStepDef.Open("UA");
        loginStepDef.LoginWithTempCredentials(Login_Id, PropertyUtils.getPassword());

    }

    @And("Select user LoginID {string} whose details want to update click on edit button and update the editable details")
    public void UpdateUserDetails(String LoginID) throws InterruptedException {

        String Name = RandomUtils.generateUniqueAlphabetName();
        String EmailID = RandomUtils.generateRandomEmail();
        String Contact_Number = RandomUtils.generateRandomMobileNumber(10);

        RandomUtils.sendHumanKeys(updateUser.createUserSearch, LoginID);
        highlight(updateUser.createUserSearch, "green");
        Thread.sleep(3000);
        int colIndex = updateUser.user_Mgmt_table.getColumnIndexByColumnName("ACTION");
        int rownumber = updateUser.user_Mgmt_table.getRowIndexByColumnContainingText("LOGIN ID", LoginID);
        updateUser.user_Mgmt_table.get_Cell_ByIndex(rownumber, colIndex).$(By.xpath(".//div[1]//button")).click();
        updateUser.userName.click();
        updateUser.userName.clear();
        RandomUtils.sendHumanKeys(updateUser.userName, Name);
        updateUser.emailID.clear();
        RandomUtils.sendHumanKeys(updateUser.emailID, EmailID);
        updateUser.contactNo.clear();
        RandomUtils.sendHumanKeys(updateUser.contactNo, Contact_Number);
        $(updateUser.updatebtn).scrollIntoView(true);
        updateUser.updatebtn.shouldBe(Condition.enabled).click();

    }

    @Then("User should get success message after updating details")
    public void SuccessMessageOnUpdatingDetails() {

        String successToastMessage = User_page.ToastMessage.getText();
        ElementScreenshot(User_page.ToastMessage);
//        Assert.assertEquals("User Updated Successfully", successToastMessage);
    }


    @And("Click on create user button and keep blank mandatory fields")
    public void KeepMandatoryFieldsBlank() throws InterruptedException {
        String User_Name = "";
        String EmailID = "";
        String Contact_Number = "";
        String Login_Unique_ID = "";
        create_user.Create_Users.click();
        create_user.Create_User_title.should(Condition.visible);
        create_user.UserName.sendKeys(User_Name);
        create_user.EmailID.sendKeys(EmailID);
        create_user.User_Role.click();
        create_user.LoginID.doubleClick();
        create_user.LoginID.sendKeys(Login_Unique_ID);
        create_user.Rank_Field.click();
        create_user.Portal_Access_Field.click();
        create_user.Contact_Number_Field.should(Condition.editable).sendKeys(Contact_Number);
        create_user.Address.click();
    }

    @Then("User should get appropriate field error message and Submit button should not be visible")
    public void ValidateErrorMessages() {
        ElementScreenshot(create_user.nameErrorMsg);
        Assert.assertEquals("Name is Required", create_user.nameErrorMsg.getText());

        ElementScreenshot(create_user.emailErrorMsg);
        Assert.assertEquals("Email ID is Required", create_user.emailErrorMsg.getText());

        ElementScreenshot(create_user.roleErrorMsg);
        Assert.assertEquals("Role is Required", create_user.roleErrorMsg.getText());

        ElementScreenshot(create_user.loginErrorMsg);
        Assert.assertEquals("Login ID is Required", create_user.loginErrorMsg.getText());

        ElementScreenshot(create_user.rankErrorMsg);
        Assert.assertEquals("Rank is Required", create_user.rankErrorMsg.getText());

        ElementScreenshot(create_user.portalErrorMsg);
        Assert.assertEquals("Portal is Required", create_user.portalErrorMsg.getText());

        ElementScreenshot(create_user.contactNoErrorMsg);
        Assert.assertEquals("Contact Number is Required", create_user.contactNoErrorMsg.getText());

    }


    @And("Select user the user {string} whose password want to reset and click on the forgot password icon")
    public void ResetPassword(String LoginID) {

        RandomUtils.sendHumanKeys(updateUser.createUserSearch, LoginID);
        highlight(updateUser.createUserSearch, "green");
        executeJavaScript("arguments[0].click();", updateUser.forgetPassword.should(Condition.appear));
        updateUser.submitbtn.should(Condition.visible).click();
        String successToastMessage = User_page.ToastMessage.getText();
        ElementScreenshot(User_page.ToastMessage);
        Assert.assertEquals("Forgot Password Request Sent Sucessfully", successToastMessage);


    }

    @Then("User should displayed new password under eye icon")
    public void VerifyIcon() {

        create_user.passIcon.should(Condition.appear).click();
        String temp_Password = create_user.firstTimePassword.getText();
        String[] arr = temp_Password.split(":");
        String firstTimePassword = arr[1];
        System.out.println(firstTimePassword);
        create_user.popUpClose.click();
        TakeScreenshot();

    }


    @Then("User should get appropriate error message stating that designated officer already exists for this organization")
    public void ErrorMessageDesignatedAlreadyExists() {
        String ErrorToastMessage = User_page.ToastMessage.getText();
        ElementScreenshot(User_page.ToastMessage);
        Assert.assertEquals("Designated Officer already exists for this Organization", ErrorToastMessage);


    }

}
