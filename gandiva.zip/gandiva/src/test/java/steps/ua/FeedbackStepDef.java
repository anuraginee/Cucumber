/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package steps.ua;

import PageObject.AdminPortal.AdminFeedback;
import PageObject.UserAgentPortal.Feedback;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import utils.Context.Context;
import utils.PropertyUtils;
import utils.ScenarioContext;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static java.lang.Integer.parseInt;
import static steps.CommonStepDef.TakeScreenshot;
import static utils.Highlighter.highlight;


@ExtendWith({ScreenShooterExtension.class})
public class FeedbackStepDef {
    @Autowired
    private Feedback feedback;

    @Autowired
    private AdminFeedback adminfeedback;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext scenarioContext = new ScenarioContext();

    @Then("Create new Feedback under feedback tab, FeedbackCategory and Sub Feedback Category")
    public void NewFeedback() throws InterruptedException {
        String Feedback_Category_Value= "Category";
        feedback.Feedback_Title.should(Condition.visible);
        feedback.Add_Feedback_Button.click();
        feedback.Add_Feedback_Window_Title.should(Condition.visible);
//        feedback.FeedbackCategoryDropdown.shouldBe(Condition.visible).click();
        feedback.FeedbackCategorySearch.sendKeys(Feedback_Category_Value);
        Thread.sleep(3000);
        highlight(feedback.SelectCategory,"green");

        feedback.SelectCategory.shouldBe(Condition.visible).click();
        feedback.SubFeedbackCategoryDropdown.click();
        highlight(feedback.SelectSubCategory,"green");
        Thread.sleep(2000);
        feedback.SelectSubCategory.shouldBe(Condition.visible).click();
        feedback.Description.click();
        feedback.Description.sendKeys("Feedback :: " + Feedback_Category_Value);
        executeJavaScript("arguments[0].click();", feedback.Create_Button);
        feedback.Confirmation_Window_Title.should(Condition.visible);
        feedback.Confirmation_Message.should(Condition.visible);
        executeJavaScript("arguments[0].click();", feedback.Yes_button);
        feedback.Feedback_Title.should(Condition.visible);

        String UserRole = feedback.User_role.getText().trim();
        System.out.println("User Role : " + UserRole);

        scenarioContext.setContext(Context.USER_ROLE, UserRole);
        scenarioContext.setContext(Context.feedbackCategory,Feedback_Category_Value);

    }

    @And("Verify New Feedback row under feedback Table")
    public void verifyFeedbackUnderTable() throws InterruptedException {
        String FeedbackCategory = scenarioContext.getContext(Context.feedbackCategory).toString();
        Thread.sleep(3000);

        int colIndex = feedback.FeedbackCategoryTable.getColumnIndexByColumnName("Category");
        int rowIndex = feedback.FeedbackCategoryTable.getRowIndexByColumnContainingText("Category", FeedbackCategory);
        highlight(feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(FeedbackCategory, feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex).getText());
    }

    @Then("Admin Officer searches for Feedback Category in Feedback Table")
    public void verifyAdminFeedbackTable() throws InterruptedException {
        String FeedbackCategory = scenarioContext.getContext(Context.feedbackCategory).toString();
        Thread.sleep(5000);
        int colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("Category");
        int rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("Category", FeedbackCategory);
        highlight(adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(FeedbackCategory, adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex).getText());

        // To Validate User_Role
        int role_colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("ROLE NAME");
        System.out.println("Is Key isContains:" + scenarioContext.isContains(Context.USER_ROLE));
        System.out.println("User Role Value :" + scenarioContext.getContext(Context.USER_ROLE).toString());
        int role_rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("ROLE NAME", scenarioContext.getContext(Context.USER_ROLE).toString());
        highlight(adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(role_rowIndex, role_colIndex), "green");
        Assert.assertEquals(scenarioContext.getContext(Context.USER_ROLE).toString(), adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(role_rowIndex, role_colIndex).getText());
    }


    public void ChatHistoryButton() throws InterruptedException {
        int colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("Chat History");
        int rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("ROLE NAME", scenarioContext.getContext(Context.USER_ROLE).toString());
        adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex).click();

    }

    @Then("Admin officer Click on chat history button and view the Chat and drops text in the Chat Window")
    public void ViewChat() throws InterruptedException {
        ChatHistoryButton();
        int colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("CHAT HISTORY");
        int rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("ROLE NAME", scenarioContext.getContext(Context.USER_ROLE).toString());
        highlight(adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Thread.sleep(3000);
        adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex).click();
        adminfeedback.Chat_History_Heading.should(Condition.visible);
        adminfeedback.Input_Text_Box.click();
        adminfeedback.Input_Text_Box.sendKeys("Feedback received from " + scenarioContext.getContext(Context.USER_ROLE).toString());
        TakeScreenshot();
        adminfeedback.Text_Submit_Button.click();
        adminfeedback.Cancel_Button.click();
    }

    @Then("User check for New message under Feedback table in UA portal")
    public void NewMessageUnderFeedbackTableUAPortal() throws InterruptedException {
        String FeedbackCategory = scenarioContext.getContext(Context.feedbackCategory).toString();
        Thread.sleep(5000);
        int colIndex = feedback.FeedbackCategoryTable.getColumnIndexByColumnName("Category");
        int rowIndex = feedback.FeedbackCategoryTable.getRowIndexByColumnContainingText("Category", FeedbackCategory);
        highlight(feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(FeedbackCategory, feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ChatcolIndex = feedback.FeedbackCategoryTable.getColumnIndexByColumnName("Feedback History");
//        highlight(feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, ChatcolIndex), "green");
//        feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, ChatcolIndex).should(Condition.visible).click();
        feedback.New_Chat_Box_UA.click();
        feedback.Input_Text_Box_UA.click();
        feedback.Input_Text_Box_UA.sendKeys("Close the Feedback Chat " + scenarioContext.getContext(Context.USER_ROLE).toString());
        TakeScreenshot();
        executeJavaScript("arguments[0].click();", feedback.Text_Send_Button.shouldBe(Condition.enabled));
        executeJavaScript("arguments[0].click();", feedback.Cancel_Button);
    }

    @And("Admin Officer read the unread messages and closes the Feedback Category Chat")
    public void closeTheFeedbackCategoryChat() throws InterruptedException {
        ChatHistoryButton();
        int colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("CHAT HISTORY");
        int rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("ROLE NAME", scenarioContext.getContext(Context.USER_ROLE).toString());
        highlight(adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex), "green").click();
        adminfeedback.Chat_History_Heading.should(Condition.visible);
        adminfeedback.Input_Text_Box.click();
        adminfeedback.Input_Text_Box.sendKeys("As Requested, Closing this Issue ");
        TakeScreenshot();
        executeJavaScript("arguments[0].click();", adminfeedback.Chat_Close_Button);
        adminfeedback.Chat_Close_Confirmation_Title.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();", adminfeedback.Proceed_Button);
        Thread.sleep(3000);
    }

    @Then("Check the status of the Chat History")
    public void StatusOfTheChatHistory() {
        feedback.Created_On_Column.doubleClick();
        highlight(feedback.First_Row_Status.shouldBe(Condition.visible),"green");
//        Assert.assertEquals("Closed",feedback.First_Row_Status.shouldBe(Condition.visible).getText());
        TakeScreenshot();
    }

    @And("User download the Chat History")
    public void userDownloadTheChat() throws InterruptedException {
        String FeedbackCategory = scenarioContext.getContext(Context.feedbackCategory).toString();
        Thread.sleep(5000);
        int colIndex = feedback.FeedbackCategoryTable.getColumnIndexByColumnName("Category");
        int rowIndex = feedback.FeedbackCategoryTable.getRowIndexByColumnContainingText("Category", FeedbackCategory);
        highlight(feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Assert.assertEquals(FeedbackCategory, feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, colIndex).getText());
        int ChatcolIndex = feedback.FeedbackCategoryTable.getColumnIndexByColumnName("Feedback History");
//        highlight(feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, ChatcolIndex), "green");
//        feedback.FeedbackCategoryTable.get_Cell_ByIndex(rowIndex, ChatcolIndex).should(Condition.visible).click();
        feedback.New_Chat_Box_UA.click();
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();", feedback.UA_Download_chat.shouldBe(Condition.visible));
        feedback.Confirmation_Window.shouldBe(Condition.visible);
        feedback.Confirm_Password.click();
        feedback.Confirm_Password.sendKeys(PropertyUtils.getPassword());
        feedback.Save_Button.click();
    }

    @And("Admin Officer download the Chat History")
    public void adminOfficerDownloadTheChatHistory() throws InterruptedException {
        ChatHistoryButton();
        int colIndex = adminfeedback.AdminFeedbackTable.getColumnIndexByColumnName("CHAT HISTORY");
        int rowIndex = adminfeedback.AdminFeedbackTable.getRowIndexByColumnContainingText("ROLE NAME", scenarioContext.getContext(Context.USER_ROLE).toString());
        highlight(adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex), "green");
        Thread.sleep(3000);
        adminfeedback.AdminFeedbackTable.get_Cell_ByIndex(rowIndex, colIndex).click();
        adminfeedback.New_Chat_Button.click();
        Thread.sleep(3000);
        adminfeedback.Chat_History_Heading.should(Condition.visible);
        executeJavaScript("arguments[0].click();",adminfeedback.Download_Chat);
        feedback.Confirmation_Window.shouldBe(Condition.visible);
        executeJavaScript("arguments[0].click();",feedback.Confirm_Password);
        feedback.Confirm_Password.sendKeys(PropertyUtils.getPassword());
        executeJavaScript("arguments[0].click();",adminfeedback.Submit_Button);
        Thread.sleep(3000);
        executeJavaScript("arguments[0].click();",adminfeedback.Cancel_Button);
    }
}//class
