/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package steps.ua;

import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import PageObject.UserAgentPortal.Feedback;
import PageObject.UserAgentPortal.Reports.UA_Reports;
import PageObject.UserAgentPortal.Reports_Xpath;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.PropertyUtils;
import utils.ScenarioContext;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.actions;


@ExtendWith({ScreenShooterExtension.class})
public class UAReportsStepDef {

    @Autowired
    private caseManagementStepDef caseManagementstepdef;
    @Autowired
    private Reports_Xpath report;
    @Autowired
    private UA_Reports UAReports;
    @Autowired
    private Feedback feedback;

    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }

    ScenarioContext scenarioContext = new ScenarioContext();


    @When("User navigates to Reports -> Case -> Case Summary")
    public void userNavigatesToMenuReports_Case() {
        if (UAReports.Case_Case_Summary.isDisplayed()) {
            UAReports.Case_Case_Summary.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Case_Summary.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> List Of Cases With Requests")
    public void userNavigatesToMenuReports_List_Of_Cases_With_Requests() {
        if (UAReports.Case_List_Of_Cases_With_Requests.isDisplayed()) {
            UAReports.Case_List_Of_Cases_With_Requests.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.visible).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_List_Of_Cases_With_Requests.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> Case History")
    public void userNavigatesToMenuReports_Case_History() {
        if (UAReports.Case_Case_History.isDisplayed()) {
            UAReports.Case_Case_History.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Case_History.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> User Wise Case Level Requests")
    public void userNavigatesToMenuReports_User_Wise_Case_Level_Requests() {
        if (UAReports.Case_User_Wise_Case_Level_Requests.isDisplayed()) {
            UAReports.Case_User_Wise_Case_Level_Requests.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_User_Wise_Case_Level_Requests.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> Case Transfer From Original User")
    public void userNavigatesToMenuReports_Case_Transfer_From_Original_User() {
        if (UAReports.Case_Case_Transfer_From_Original_User.isDisplayed()) {
            UAReports.Case_Case_Transfer_From_Original_User.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Case_Transfer_From_Original_User.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> Role Wise User Wise Case Statistics")
    public void userNavigatesToMenuReports_Role_Wise_User_Wise_Case_Statistics() {
        if (UAReports.Case_Role_Wise_User_Wise_Case_Statistics.isDisplayed()) {
            UAReports.Case_Role_Wise_User_Wise_Case_Statistics.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Role_Wise_User_Wise_Case_Statistics.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case -> Case List")
    public void userNavigatesToMenuReports_Case_List() {
        if (UAReports.Case_Case_List.isDisplayed()) {
            UAReports.Case_Case_List.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Case_List.should(Condition.enabled).click();
        }
    }

    @When("user should be able to download the report in xlxs format")
    public void Reports_in_XLSX_Format() throws InterruptedException {
        if ($(By.xpath("(//mat-icon[@data-mat-icon-name='file_download'])[1]")).isDisplayed()) {
            $(By.xpath("(//mat-icon[@data-mat-icon-name='file_download'])[1]")).click();
            feedback.Confirmation_Window.shouldBe(Condition.visible);
            feedback.Confirm_Password.click();
            feedback.Confirm_Password.sendKeys(PropertyUtils.getPassword());
            feedback.Save_Button.click();
            Thread.sleep(3000);
        } else {
            scenario.log("Unable to view and Download the report details");
        }
    }


    @When("User navigates to Reports -> Request -> Scheduled Query Summary")
    public void userNavigatesToMenuReports_Request() {
        if (UAReports.Scheduled_Queries_Summary.isDisplayed()) {
            UAReports.Scheduled_Queries_Summary.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Scheduled_Queries_Summary.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> Request History")
    public void userNavigatesToMenuReports_Request_History() {
        if (UAReports.Request_History.isDisplayed()) {
            UAReports.Request_History.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Request_History.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> QR Requests Summary")
    public void userNavigatesToMenuReports_QR_Request_Summary() {
        if (UAReports.QR_Request_Summary.isDisplayed()) {
            UAReports.QR_Request_Summary.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.visible).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.QR_Request_Summary.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> List Of Requests")
    public void userNavigatesToMenuReports_List_Of_Requests() {
        if (UAReports.List_of_Requests.isDisplayed()) {
            UAReports.List_of_Requests.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.List_of_Requests.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> Request Error")
    public void userNavigatesToMenuReports_Request_Error() {
        if (UAReports.Request_Error.isDisplayed()) {
            UAReports.Request_Error.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Request_Error.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> ER Requests Summary")
    public void userNavigatesToMenuReports_ER_Requests_Summary() {
        if (UAReports.ER_Request_Summary.isDisplayed()) {
            UAReports.ER_Request_Summary.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.ER_Request_Summary.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request -> Requests Summary")
    public void userNavigatesToMenuReports_Request_Summary() {
        if (UAReports.Request_Summary.isDisplayed()) {
            UAReports.Request_Summary.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Request_Summary.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Approval -> Case Requests Pending For Approval")
    public void userNavigatesToMenuApproval_Case_Requests_Pending_For_Approval() {
        if (UAReports.Case_Requests_Pending_Approval.isDisplayed()) {
            UAReports.Case_Requests_Pending_Approval.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Approval.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.Case_Requests_Pending_Approval.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Approval -> List Of Pending Requests For Recommendation")
    public void userNavigatesToMenuApproval_List_Of_Pending_Requests_For_Recommendation() {
        if (UAReports.List_Of_Pending_Requests_For_Recommendation.isDisplayed()) {
            UAReports.List_Of_Pending_Requests_For_Recommendation.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Approval.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.List_Of_Pending_Requests_For_Recommendation.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Approval -> List Of Pending Query Response For Their Action")
    public void userNavigatesToMenuApproval_List_of_Pending_Query_Response_For_Thier_Action() {
        if (UAReports.List_Of_Pending_Query_Response_For_Their_Action.isDisplayed()) {
            UAReports.List_Of_Pending_Query_Response_For_Their_Action.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Approval.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.List_Of_Pending_Query_Response_For_Their_Action.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Approval -> List Of All Data Mart Requests")
    public void userNavigatesToMenuReports_List_Of_All_Data_Mart_Requests() {
        if (UAReports.List_Of_All_Data_Mart_Requests.isDisplayed()) {
            UAReports.List_Of_All_Data_Mart_Requests.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Approval.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.List_Of_All_Data_Mart_Requests.should(Condition.enabled).click();
        }
    }


    @When("User navigates to Reports -> Approval -> List Of Pending Query Requests For Their Action")
    public void userNavigatesToMenuReports_List_Of_Pending_Query_Requests_For_Their_Action() {
        if (UAReports.List_Of_Pending_Query_Requests_For_Their_Action.isDisplayed()) {
            UAReports.List_Of_Pending_Query_Requests_For_Their_Action.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Approval.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            UAReports.List_Of_Pending_Query_Requests_For_Their_Action.should(Condition.enabled).click();
        }
    }


// Reports related Xpath(s)- mentioned Reports are not mapped inside any of the Sub report Tabs


    @When("User navigates to Reports -> Status Of Requests Raised For Approval")
    public void userNavigatesToMenu_Requests_Raised_For_Approval() {
        if (UAReports.Status_Of_Requests_Raised_For_Approval.isDisplayed()) {
            UAReports.Status_Of_Requests_Raised_For_Approval.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Status_Of_Requests_Raised_For_Approval.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> List Of Users With Cases")
    public void userNavigatesToMenu_List_Of_Users_With_Cases() {
        if (UAReports.List_Of_Users_With_Cases.isDisplayed()) {
            UAReports.List_Of_Users_With_Cases.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.List_Of_Users_With_Cases.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Case Request Received for Review")
    public void userNavigatesToMenuCase_Request_Received_for_Review() {
        if (UAReports.Case_Requests_Received_For_Review.isDisplayed()) {
            UAReports.Case_Requests_Received_For_Review.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case_Requests_Received_For_Review.should(Condition.enabled).click();
        }
    }

    @When("User navigates to Reports -> Request Awaiting Approving Officer Review or Report")
    public void userNavigatesToMenuReports_Request_Awaiting_Approving_Officer_Review() {
        if (UAReports.Request_Awaiting_Approving_Officer_Review_Approval.isDisplayed()) {
            UAReports.Request_Awaiting_Approving_Officer_Review_Approval.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Request_Awaiting_Approving_Officer_Review_Approval.should(Condition.enabled).click();
        }
    }
    @When("User navigates to Reports -> Case Report Nodal Wise")
    public void userNavigatesToMenuReports_Case_Report_Nodal_Wise() {
        if (UAReports.Case_Report_Nodal_Wise.isDisplayed()) {
            UAReports.Case_Report_Nodal_Wise.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Case_Report_Nodal_Wise.should(Condition.enabled).click();
        }
    }

// Xpath(s) for Reports->Users Reports

    @When("User navigates to Reports -> Users -> List Of Existing Users")
    public void userNavigatesToMenuReports_Request_List_of_Existing_Users() {
        if (UAReports.List_Of_Existing_Users.isDisplayed()) {
            UAReports.List_Of_Existing_Users.should(Condition.enabled).click();
        } else {
            UA_dashboard.Reports.should(Condition.enabled).click();
            UAReports.Users.shouldBe(Condition.visible).shouldBe(Condition.enabled).click();
            actions().scrollToElement(UAReports.List_Of_Existing_Users).click();
//            UAReports.List_Of_Existing_Users.should(Condition.enabled).click();
        }
    }

}