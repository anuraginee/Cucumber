/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps.ua;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.CaseManagement.Cases;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import utils.enums.DASHBOARD_WIDGETS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.executeJavaScript;
import static steps.CommonStepDef.TakeScreenshot;

/**
 *
 */
@ExtendWith({ScreenShooterExtension.class})
public class UADashboardStepDef {
    @Autowired
    private CommonElements commonElements;

    @Autowired
    private UA_dashboard ua_dashboard;

    @Autowired
    private Cases cases;

    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


    Map<String, Integer> Map_User = new HashMap<String, Integer>();
    List<Map<String, String>> Map_data = new ArrayList<>();


    @When("Users clicks view all link to view the Cases widget")
    public void CasesWidget() throws InterruptedException {

        Map_User.put(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.CASES_TOTAL.getParamName()).getText()));
        int Case_total_count = Map_User.get(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.CASES_TOTAL.getParamName());
        scenario.log("Case widget Total Count :::: " + Case_total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.CASES_TOTAL.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();

            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Case_total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Pending Case Level Requests Widget")
    public void totalNodalOfficersWidget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName()).getText()));
        int Pending_Case_Level_Request_total_count = Map_User.get(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getParamName());
        scenario.log("Pending Case Level Request widget Total Count :::: " + Pending_Case_Level_Request_total_count);

        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()));
        Thread.sleep(2000);
        if (cases.User_role.getText().equalsIgnoreCase("APPROVING OFFICER")) {
            ua_dashboard.Pending_Case_Level_Request.shouldBe(Condition.visible);
        } else if (cases.User_role.getText().equalsIgnoreCase("SUPERVISORY OFFICER")) {
            ua_dashboard.Pending_Case_Level_Request.shouldBe(Condition.visible);
        } else {
            ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.PENDINGCASELEVELREQUESTS_TOTAL.getWidgetName()).shouldBe(Condition.visible);
        }

        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Pending_Case_Level_Request_total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }


    @When("Users clicks view all link to view the QR Requests Widget")
    public void action_Pending_on_QR_Requests_with_Admin() throws InterruptedException {

        Map_User.put(DASHBOARD_WIDGETS.QR_Response_Received.getWidgetName() + "_" + DASHBOARD_WIDGETS.QR_Response_Received.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.QR_Response_Received.getWidgetName(), DASHBOARD_WIDGETS.QR_Response_Received.getParamName()).getText()));
        int QR_Request_total_count = Map_User.get(DASHBOARD_WIDGETS.QR_Response_Received.getWidgetName() + "_" + DASHBOARD_WIDGETS.QR_Response_Received.getParamName());
        scenario.log("QR Request widget Total Count :::: " + QR_Request_total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.QR_Response_Received.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.QR_Response_Received.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(QR_Request_total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }

    }

    @When("Users clicks view all link to view the Pending Common Mart Requests Widget")
    public void action_Pending_Common_Mart_Requests() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getWidgetName() + "_" + DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getWidgetName(), DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getParamName()).getText()));
        int Pending_Common_Mart_Request_total_count = Map_User.get(DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getWidgetName() + "_" + DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getParamName());
        scenario.log("Pending Common Mart Request widget Total Count :::: " + Pending_Common_Mart_Request_total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.Pending_Common_Mart_Requests.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Pending_Common_Mart_Request_total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Ingested Data Requests Widget")
    public void casesWidget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.IngestedDataRequests_ER.getWidgetName() + "_" + DASHBOARD_WIDGETS.IngestedDataRequests_ER.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.IngestedDataRequests_ER.getWidgetName(), DASHBOARD_WIDGETS.IngestedDataRequests_ER.getParamName()).getText()));
        int Ingested_Data_Requests_ER_count = Map_User.get(DASHBOARD_WIDGETS.IngestedDataRequests_ER.getWidgetName() + "_" + DASHBOARD_WIDGETS.IngestedDataRequests_ER.getParamName());
        scenario.log("Ingested Data Request widget Total Count :::: " + Ingested_Data_Requests_ER_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.IngestedDataRequests_ER.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.IngestedDataRequests_ER.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Ingested_Data_Requests_ER_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }


    @When("Users clicks view all link to view the Scheduled Queries Widget")
    public void approval_Awaited_On_Highly_Sensitive_Query_At_PO_Widget() throws InterruptedException {

        Map_User.put(DASHBOARD_WIDGETS.ScheduledQueries_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.ScheduledQueries_Total.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.ScheduledQueries_Total.getWidgetName(), DASHBOARD_WIDGETS.ScheduledQueries_Total.getParamName()).getText()));
        int Scheduled_Queries_Total_count = Map_User.get(DASHBOARD_WIDGETS.ScheduledQueries_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.ScheduledQueries_Total.getParamName());
        scenario.log("Scheduled Query Request widget Total Count :::: " + Scheduled_Queries_Total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.ScheduledQueries_Total.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.ScheduledQueries_Total.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Scheduled_Queries_Total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Pending QR Requests Widget")
    public void action_Pending_On_Profile_Update_Request_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.PendingQRRequests_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.PendingQRRequests_Total.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PendingQRRequests_Total.getWidgetName(), DASHBOARD_WIDGETS.PendingQRRequests_Total.getParamName()).getText()));
        int Pending_QR_Requests_Total_count = Map_User.get(DASHBOARD_WIDGETS.PendingQRRequests_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.PendingQRRequests_Total.getParamName());
        scenario.log("Pending QR Request widget Total Count :::: " + Pending_QR_Requests_Total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.PendingQRRequests_Total.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.PendingQRRequests_Total.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Pending_QR_Requests_Total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }

    }

    @When("Users clicks view all link to view the User Widget")
    public void User_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.Total_User.getWidgetName() + "_" + DASHBOARD_WIDGETS.Total_User.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.Total_User.getWidgetName(), DASHBOARD_WIDGETS.Total_User.getParamName()).getText()));
        int User_Total_count = Map_User.get(DASHBOARD_WIDGETS.Total_User.getWidgetName() + "_" + DASHBOARD_WIDGETS.Total_User.getParamName());
        scenario.log("User Total Count :::: " + User_Total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.USERS_TOTAL.getWidgetName()));
        Thread.sleep(2000);
        ua_dashboard.Users_Heading.shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(User_Total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Transferred Cases Widget")
    public void Transferred_Cases_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName()).getText()));
        int Transferred_Cases_Total_count = Map_User.get(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getParamName());
        scenario.log("Transferred Cases Total Count :::: " + Transferred_Cases_Total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.TRANSFERREDCASES_TOTAL.getWidgetName()));
        Thread.sleep(2000);
        ua_dashboard.Transferred_Cases_Heading.shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Transferred_Cases_Total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Pending Highly Sensitive Queries at PO Widget")
    public void Pending_Highly_Sensitive_Queries_at_PO_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getWidgetName(), DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getParamName()).getText()));
        int Pending_Highly_Sensitive_Queries_at_PO_Total_count = Map_User.get(DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getWidgetName() + "_" + DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getParamName());
        scenario.log("Pending Highly Sensitive Queries Request widget Total Count :::: " + Pending_Highly_Sensitive_Queries_at_PO_Total_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.Pending_Highly_Sensitive_Queries_at_PO_Total.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(Pending_Highly_Sensitive_Queries_at_PO_Total_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Pending Scheduled Query Requests Widget")
    public void Pending_Scheduled_Queries_Request_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getWidgetName(), DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getParamName()).getText()));
        int PENDING_Scheduled_Query_REQUESTS_TOTAL_count = Map_User.get(DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getParamName());
        scenario.log("Pending Sensitive Queries Request widget Total Count :::: " + PENDING_Scheduled_Query_REQUESTS_TOTAL_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getWidgetName()));
//        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.PENDINGScheduledQueryREQUESTS_TOTAL.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(PENDING_Scheduled_Query_REQUESTS_TOTAL_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    @When("Users clicks view all link to view the Pending Mart Requests Widget")
    public void Pending_Mart_Request_Widget() throws InterruptedException {
        Map_User.put(DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getParamName(), Integer.parseInt(ua_dashboard.getCountByWidgetNameAndParam(DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getWidgetName(), DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getParamName()).getText()));
        int PENDING_Mart_REQUESTS_count = Map_User.get(DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getWidgetName() + "_" + DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getParamName());
        scenario.log("Pending Mart Request widget Total Count :::: " + PENDING_Mart_REQUESTS_count);
        executeJavaScript("arguments[0].click();", ua_dashboard.widgetViewAll(DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getWidgetName()));
        ua_dashboard.widgetHeading(DASHBOARD_WIDGETS.PENDINGMARTREQUESTS_Common_Mart.getWidgetName()).shouldBe(Condition.visible);
        Thread.sleep(2000);
        if ($(By.xpath("//table[contains(@class,'mat-table')]")).isDisplayed()) {
            $(By.xpath("//table[contains(@class,'mat-table')]")).should(Condition.appear);
            TakeScreenshot();
            executeJavaScript("arguments[0].scrollIntoView(true);", ua_dashboard.Total_Count);
            String Count = ua_dashboard.Total_Count.getText();
            int Total_Count = Integer.parseInt(extractNumber(Count));
            Assert.assertEquals(PENDING_Mart_REQUESTS_count, Total_Count);
        }
        else{
            scenario.log("Widget -> View All ::::::::::: Table is not visible");
        }
    }

    public static String extractNumber(String Count) {

        Count = Count.trim();
        // Find the index of "of " and extract the substring starting from that position
        int Total_Count = Count.indexOf("of ");
        if (Total_Count != -1) {
            // Extract the number after "of "
            String number = Count.substring(Total_Count + 3).trim();
            return number;
        }
        // Return an empty string if the format is unexpected
        return "";
    }

}

