package steps.ua;

import PageObject.Common.CommonElements;
import PageObject.Common.ProfileUpdate;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.junit5.ScreenShooterExtension;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

@ExtendWith({ScreenShooterExtension.class})
public class ProfileUpdateStepDef {
    @Autowired
    private UA_dashboard ua_dashboard;
    @Autowired
    private ProfileUpdate profileUpdate;

    @Autowired
    private CommonElements commonElements;

    // Use Below lines of code for writing into the Cucumber Report
    // Example : scenario.log("Your Text here . . .");
    Scenario scenario;

    @Before
    public void beforeScenario(Scenario scenario) {
        this.scenario = scenario;
    }


    @When("user navigates to myprofile, changes {string}, {string},{string} and Profile change request trigger to approver")
    public void user_navigates_to_myprofile_changes_and_Profile_change_request_trigger_to_approve(String Mobile, String EmailId, String Remarks) throws InterruptedException {

        profileUpdate.officerName.shouldBe(Condition.appear).click();
        profileUpdate.profileIcon.shouldBe(Condition.visible).click();
        profileUpdate.editProfile.should(Condition.visible).click();
        profileUpdate.emailIdField.clear();
        profileUpdate.emailIdField.setValue(EmailId); // Change Email ID

        profileUpdate.mobileField.clear();
        profileUpdate.mobileField.setValue(Mobile); // Change mobile number

        profileUpdate.profileUpdateRemarksField.setValue(Remarks);

        profileUpdate.profileUpdateBtn.shouldBe(Condition.appear).click();

        profileUpdate.confirmationBtn.shouldBe(Condition.appear).click();

        String toastmessage = profileUpdate.successToastMessage.getText();
        Assert.assertEquals(toastmessage, "User details updated successfully");


    }

    @And("Nodal approves the profile update request by username {string} and remark {string}")
    public void approveProfileUpdateRequest(String Username, String NodalRemark) {

        profileUpdate.searchField.setValue(Username);
        profileUpdate.approveBtn.shouldBe(Condition.visible).click();
        profileUpdate.nodalRemark.setValue(NodalRemark);
        profileUpdate.confirmationYes.shouldBe(Condition.enabled).click();
        String nodalSuccessMessage = profileUpdate.successToastMessageNodal.getText();
        Assert.assertEquals(nodalSuccessMessage, "Profile update request approved successfully.");


    }


}
