/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package steps;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.WebDriverRunner;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.log4j.Logger;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utils.WebDriverFactory;

import static utils.WebDriverFactory.FirstTimeLogin;


/**
 *
 */
public class CucumberHooks {

    @SuppressWarnings("unused")
    private static Logger Log = Logger.getLogger(CucumberHooks.class);

    @Before
    public void beforeTest(Scenario scenario) {
        Log.info("--- Scenario'" + scenario.getName() + "' ---");

        WebDriverFactory.getWebDriverInstance();// ENTRY POINT CREATES WEB DRIVER INSTANCE.
    }
    @BeforeEach
    public void setUp() {
        // Clear cookies after launching the driver instance
        Selenide.clearBrowserCookies();

        // Optionally, you might want to clear local storage as well
        Selenide.clearBrowserLocalStorage();
    }



    /**
     * @param scenario
     */
    @After
    public void afterTest(Scenario scenario) {
        if (scenario.isFailed()) {
            Log.warn("--- Scenario'" + scenario.getName() + "' Failed ---");
            TakesScreenshot ts = (TakesScreenshot) WebDriverRunner.getWebDriver();
            byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", scenario.getName());
        } else {
            Log.info("--- Scenario '" + scenario.getName() + "' Completed Successfully ---");
        }
        WebDriverFactory.closeWebDriverInstance();
        System.out.println("AfterTest -> FirstTimeLogin is :" + FirstTimeLogin.toString());
//        dataStorage.cleanUpAll();
    }

    @BeforeAll
    public static void CucumberSetUpSuite() {
        Log.info("Cucumber Suite SetUp");
    }

    @AfterAll
    public static void CucumberTearDownSuite() {
        Log.info("Cucumber Suite Tear Down");
    }

}