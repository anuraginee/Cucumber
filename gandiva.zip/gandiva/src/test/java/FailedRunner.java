/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 18-07-2023
*/

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty", "html:target/cucumber/reports2.html", "json:target/cucumber/cucumber2.json"},
        features = "@target/failedrerun.txt",
        glue = "steps",
        tags="@UA",
        dryRun = false,
        snippets = CucumberOptions.SnippetType.CAMELCASE)
public class FailedRunner {
}