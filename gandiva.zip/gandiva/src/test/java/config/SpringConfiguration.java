/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

/**
 *Spring Configuration Class.
 */
@Configuration
@ComponentScan({ "steps", "PageObject", "utils"})
@PropertySources({ @PropertySource("classpath:application.properties"), })
public class SpringConfiguration {
}
