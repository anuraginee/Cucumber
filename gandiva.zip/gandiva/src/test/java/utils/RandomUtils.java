/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package utils;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.openqa.selenium.WebElement;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 *
 */
public class RandomUtils {

    // Set to store generated names to ensure uniqueness
    private static Set<String> generatedNames = new HashSet<>();

    /**
     * Generate Random number with 4 digits length.
     */
    public static String getUniqueNumber() {
        SimpleDateFormat formatter = new SimpleDateFormat("ddMMMhhmmss");
        String strDate = formatter.format(new Date());
        SecureRandom random = new SecureRandom();
        return strDate.concat(new BigInteger(16, random).toString(1).toLowerCase());
    }

    /**
     * @return
     */
    public static String getTimeBasedUniqueNumber() {
        return String.valueOf(System.currentTimeMillis());
    }


    // Method to generate a unique alphabet name
    public static String generateUniqueAlphabetName() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder name = new StringBuilder();

        do {
            // Generating a random name of random length between 5 and 10 characters
            int length = (int) (Math.random() * 6) + 2;
            for (int i = 0; i < length; i++) {
                int index = (int) (Math.random() * alphabet.length());
                name.append(alphabet.charAt(index));
            }
        } while (generatedNames.contains(name.toString()));

        // Add the generated name to the set
        generatedNames.add(name.toString());

        return name.toString();
    }

    /**
     * @return
     */
    public static String getRandomEmail() {
        return "Automation" + RandomUtils.getUniqueNumber() + "@mail.com";
    }

    static String verificationCode;

    /**
     * @param element
     * @param text
     */
    public static void sendHumanKeys(WebElement element, String text) {
        Random r = new Random();
        for (int i = 0; i < text.length(); i++) {
            try {
                Thread.sleep((int) (r.nextGaussian() * 20 + 100));
            } catch (InterruptedException e) {
            }
            String s = new StringBuilder().append(text.charAt(i)).toString();
            element.sendKeys(s);
        }
    }

    /**
     * @param portal
     * @param userName
     * @param password
     * @return
     */
    public static String getVerificationCode(String portal, String userName, String password) {
        RestAssured.baseURI = PropertyUtils.getPropString("NG_KeyClockUrl");
        RestAssured.useRelaxedHTTPSValidation();
        // Request
        RequestSpecification request = RestAssured.given();
        JSONObject requestParams = new JSONObject();
        requestParams.put("username", userName);
        requestParams.put("password", password);
        if (portal.equalsIgnoreCase("UA")) {
            requestParams.put("roleAlias", "");
        } else if (portal.equalsIgnoreCase("ADMIN")) {
            requestParams.put("roleAlias", "NGADM");
        } else {
            requestParams.put("roleAlias", "");//VDI
        }
        requestParams.put("otp", "");
        request.header("Content-Type", "application/json");
        request.body(requestParams.toJSONString()); // Post the request and check the response
        Response response = request.post("/ng-keyCloak");
        System.out.println(response.getStatusLine());
        // Get Response Body
        ResponseBody responseBody = response.getBody();
        System.out.println("RESPONSE : ----> " + responseBody.asString());
        return extractDigits(responseBody.asString());
    }

    public static String getVerificationCodeForUserActivity(String userName, String password) {
        RestAssured.baseURI = PropertyUtils.getPropString("NG_KeyClockUrl");
        RestAssured.useRelaxedHTTPSValidation();
        // Request
        RequestSpecification request = RestAssured.given();
        JSONObject requestParams = new JSONObject();
        requestParams.put("username", userName);
        requestParams.put("password", password);
        requestParams.put("roleAlias", "");
        requestParams.put("otp", "");
        request.header("Content-Type", "application/json");
        request.body(requestParams.toJSONString()); // Post the request and check the response
        Response response = request.post("/ng-keyCloak");
        System.out.println(response.getStatusLine());
        // Get Response Body
        ResponseBody responseBody = response.getBody();
        System.out.println("RESPONSE : ----> " + responseBody.asString());
        return extractDigits(responseBody.asString());
    }


    /**
     * @param in
     * @return
     */
    public static String extractDigits(final String in) {
        String before = "Your one time password to complete Login is ";
        String after = ". OTP is valid for 5 mins.";
        String code = PropertyUtils.between(in, before.toString(), after.toString());
        System.out.println("CODE : ----> " + code);
        return code;
    }

    public static String generateRandomEmail() {
        String[] domains = {"gmail.com", "yahoo.com", "hotmail.com", "example.com"};

        // Generate a random username
        String username = generateRandomUsername();

        // Choose a random domain
        Random random = new Random();
        int domainIndex = random.nextInt(domains.length);
        String domain = domains[domainIndex];

        // Construct the email address
        return username + "@" + domain;
    }

    private static String generateRandomUsername() {
        String characters = "abcdefghijklmnopqrstuvwxyz0123456789";
        int length = 8; // You can adjust the length as needed
        StringBuilder username = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            username.append(characters.charAt(index));
        }

        return username.toString();
    }

    public static String generateRandomMobileNumber(int length) {
        // Define the possible mobile number formats in India
        String[] formats = {"9xxxxxxxxx", "8xxxxxxxxx", "7xxxxxxxxx"};

        // Choose a random format
        String selectedFormat = formats[new Random().nextInt(formats.length)];

        // Generate a random number based on the selected format
        StringBuilder mobileNumber = new StringBuilder();
        for (char formatChar : selectedFormat.toCharArray()) {
            if (formatChar == 'x') {
                // If the character is 'x', replace it with a random digit
                mobileNumber.append(new Random().nextInt(10));
            } else {
                // Otherwise, keep the character as it is
                mobileNumber.append(formatChar);
            }
        }

        return mobileNumber.toString();
    }

    public static String generateUniqueString() {
        // Define the characters and digits to be used in the combination
//        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String digits = "0123456789";

        // Combine characters and digits
//        String combinedChars = characters + digits;
        String combinedChars = digits;
        // Initialize a Random object
        Random random = new Random();

        // Create a StringBuilder to store the generated string
        StringBuilder uniqueString = new StringBuilder();

        // Generate three characters
        for (int i = 0; i < 3; i++) {
            // Get a random index from the combinedChars string
            int randomIndex = random.nextInt(combinedChars.length());

            // Append the character at the random index to the uniqueString
            uniqueString.append(combinedChars.charAt(randomIndex));
        }

        // Convert StringBuilder to String and return
        return uniqueString.toString();
    }

    public static String generateUniqueInt() {
        // Define the characters and digits to be used in the combination
//        String characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String digits = "0123456789";

        // Combine characters and digits
//        String combinedChars = characters + digits;
        String combinedChars = digits;
        // Initialize a Random object
        Random random = new Random();

        // Create a StringBuilder to store the generated string
        StringBuilder uniqueString = new StringBuilder();

        // Generate three characters
        for (int i = 0; i < 2; i++) {
            // Get a random index from the combinedChars string
            int randomIndex = random.nextInt(combinedChars.length());

            // Append the character at the random index to the uniqueString
            uniqueString.append(combinedChars.charAt(randomIndex));
        }

        // Convert StringBuilder to String and return
        return uniqueString.toString();
    }

    public static String generateRandomIPAddress() {
        Random rand = new Random();
        StringBuilder ipAddress = new StringBuilder();

        // Generate each part of the IP address
        for (int i = 0; i < 4; i++) {
            ipAddress.append(rand.nextInt(256)); // Random number between 0 and 255
            if (i < 3) {
                ipAddress.append(".");
            }
        }

        return ipAddress.toString();
    }

    public static String generateRandomMACAddress() {
        Random rand = new Random();
        StringBuilder macAddress = new StringBuilder();

        // Generate each part of the MAC address
        for (int i = 0; i < 6; i++) {
            macAddress.append(String.format("%02X", rand.nextInt(256))); // Random hexadecimal number
            if (i < 5) {
                macAddress.append("");
            }
        }

        return macAddress.toString();
    }



    public static String generateRandompid() {
        Random rand = new Random();
        StringBuilder pid = new StringBuilder();

        // Generate each part of the MAC address
        for (int i = 0; i < 2; i++) {
            pid.append(String.format("%02X", rand.nextInt(256))); // Random hexadecimal number
            if (i < 5) {
                pid.append("");
            }
        }

        return pid.toString();
    }


    public static String generateOrgName() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder name = new StringBuilder();

        do {
            // Generating a random name of random length between 5 and 10 characters
            int length = (int) (Math.random() * 6) + 2;
            for (int i = 0; i < length; i++) {
                int index = (int) (Math.random() * alphabet.length());
                name.append(alphabet.charAt(index));
            }
        } while (generatedNames.contains(name.toString()));

        // Add the generated name to the set
        generatedNames.add(name.toString());

        return name.toString();
    }


}
