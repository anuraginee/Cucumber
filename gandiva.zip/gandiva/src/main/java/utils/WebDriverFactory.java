package utils;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.WebDriverRunner;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import static com.codeborne.selenide.Browsers.*;

public class WebDriverFactory {

    public static Boolean FirstTimeLogin = false;

    public static void getWebDriverInstance() {
        createWebDriver();
    }

    public static void closeWebDriverInstance() {
        shutdownWebDriver();
    }
    public static void quitWebDriverInstance() {
        quitWebDriver();
    }

    private static void createWebDriver() {
        String browser = PropertyUtils.getPropString("selenide.browser", "selenide.properties");
        Boolean headless = PropertyUtils.getPropBoolean("selenide.headless", "selenide.properties");
        String pageLoadStrategy = PropertyUtils.getPropString("selenide.pageloading.strategy", "selenide.properties");
        Integer timeout = PropertyUtils.getPropInteger("selenide.timeout", "selenide.properties");
//        Boolean remoteExecution = PropertyUtils.getPropBoolean("selenide.remote.execution", "selenide.properties");
//        String remoteHost = PropertyUtils.getPropString("selenide.remote", "selenide.properties");
//
//        if (remoteExecution) {
//            Configuration.remote = remoteHost;
//        }

        switch (browser) {
            case IE:
                Configuration.fastSetValue = true;
                break;
            case CHROME:
                Configuration.headless = headless;
                // Set Chrome Options from the selenide.properties file TBD Later.
                ChromeOptions chromeOptions = new ChromeOptions();
                chromeOptions.addArguments("--disable-extensions");
                chromeOptions.addArguments("--no-sandbox");
                chromeOptions.addArguments("disable-infobars");
                chromeOptions.addArguments("--disable-web-security");
                chromeOptions.addArguments("--disable-site-isolation-trials");
                DesiredCapabilities capabilities = new DesiredCapabilities();
                capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);//browserstackOptions
                Configuration.browserCapabilities = capabilities;// Important Step
                /* OR
                 *   Configuration.browserCapabilities.setCapability(ChromeOptions.CAPABILITY, browserstackOptions);
                 * */
                break;
            case FIREFOX:


                break;
            case EDGE:
                break;
            default:
                System.out.println("No previously known web browser is specified," + " please check properties file for any missmatch. Specified browser is: " + browser);
                break;
        }
        Configuration.browser = browser;
        Configuration.timeout = timeout;
//        Configuration.startMaximized = true;
        Configuration.pageLoadStrategy = pageLoadStrategy;
//    SelenideLogger.addListener("AllureSelenide", new AllureSelenide().screenshots(true).savePageSource(true));
    }

    private static void shutdownWebDriver() {
        System.out.println("Closing Web Driver . . . ");
        WebDriverRunner.closeWebDriver();
        WebDriverFactory.FirstTimeLogin = false;
    }

    private static void quitWebDriver() {
        System.out.println("Quitting Web Driver . . . ");
        WebDriverRunner.getWebDriver().quit();
        WebDriverFactory.FirstTimeLogin = false;
    }
}