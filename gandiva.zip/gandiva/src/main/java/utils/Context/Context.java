package utils.Context;

public enum Context {
    CASENAME,
    CASEID,
    USER_ROLE,
    NOTIFICATION_CONTENT,
    Entity_Profile_Name,
    Current_Date_Time,
    Login_ID_Officer,
    Query_Name,
    OrgName,

    LoginID,
    orgType,
    Approver_User_Role,
    Case_Status,

    alias,

    roleName,

    description,
    ContactNo,

    feedbackCategory,

    feedbackCatDes,

    macAddress,

    officeLocation,

    vid,

    Notes_Title,

    Temp_Password;

}
