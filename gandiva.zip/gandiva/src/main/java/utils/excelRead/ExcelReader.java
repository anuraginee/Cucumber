package utils.excelRead;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.IOException;

@Component
public class ExcelReader {


   public static String readCellValue(String sheetName, int row, int column) throws IOException {
       FileInputStream file = new FileInputStream("D:\\Somnath\\Automation\\gandiva\\src\\test\\resources\\features\\Scenario_Counts.xlsx");
       String count = WorkbookFactory.create(file).getSheet(sheetName).getRow(row).getCell(column).getStringCellValue();
       return count;
   }
   }



