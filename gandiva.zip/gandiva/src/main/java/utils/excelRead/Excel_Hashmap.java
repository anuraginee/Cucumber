package utils.excelRead;

import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Component;

import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Component

public class Excel_Hashmap {

//    public static void main(String[] args) throws IOException {
//        String excelFilePath = "C:\\workplace\\gandiva\\src\\test\\java\\testdata\\Notification_list.xls";
//        Map<String, ArrayList<String>> excelMap = readExcel(excelFilePath);
//        System.out.println(excelMap);

//        try {
//            Map<String, ArrayList<String>> excelMap = readExcel(excelFilePath);
//            for (Map.Entry<String, ArrayList<String>> entry : excelMap.entrySet()) {
//                System.out.println("Module: " + entry.getKey());
//                System.out.println("Message Content: " + entry.getValue());
//                System.out.println("-------------------------");
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    public static Map<String, ArrayList<String>> readExcel(String filePath) throws IOException {
        Map<String, ArrayList<String>> excelMap = new HashMap<>();

        FileInputStream inputStream = new FileInputStream(new File(filePath));
        Workbook workbook = WorkbookFactory.create(inputStream);

        Sheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();

        while (rowIterator.hasNext()) {
            Row currentRow = rowIterator.next();
            Cell moduleCell = currentRow.getCell(1, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            Cell messageCell = currentRow.getCell(2, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

            String module = moduleCell.getStringCellValue().trim();
            String message = messageCell.getStringCellValue().trim();

            if (!module.isEmpty() && !message.isEmpty()) {
                if (excelMap.containsKey(module)) {
                    excelMap.get(module).add(message);
                } else {
                    ArrayList<String> messages = new ArrayList<>();
                    messages.add(message);
                    excelMap.put(module, messages);
                }
            }
        }
        workbook.close();
        inputStream.close();
        return excelMap;
    }

    public static String Case_Related_Notification_From_Hashmap(String Module, String Scenario_Notification_Text, String Case_ID, String User_Role) throws IOException {
        String Notification_Text = "";
        Map<String, ArrayList<String>> excelMap = readExcel("C:\\workplace\\gandiva\\src\\test\\java\\testdata\\Notification_list.xls");
        ArrayList<String> messages = excelMap.get(Module);

        if (Module.equalsIgnoreCase("Case Initiation")) {
            System.out.println("Case Initiation : " + messages);
            if (messages != null) {
                for (String message : messages) {
                    if (message.contains(Scenario_Notification_Text)) {
                        Notification_Text = message.replace("<<Case ID>>", Case_ID);
                    } else if (message.contains(Scenario_Notification_Text)) {
                        Notification_Text = message.replace("<<Case ID>>", Case_ID);
                        Notification_Text = message.replace("<<Role>>", User_Role);

                        System.out.println("Notification Text : " + Notification_Text);
                    }
                }
            }
        } else if (Module.equalsIgnoreCase("Case Close")) {
            System.out.println("Case Close : " + messages);
            if (messages != null) {
                for (String message : messages) {
                    if (message.contains(Scenario_Notification_Text)) {
                        Notification_Text = message.replace("<<Case ID>>", Case_ID);
                    }
//                    else if(message.contains(Scenario_Notification_Text)) {
//                        Notification_Text = message.replace("<<Case ID>>", Case_ID);
//                        System.out.println("Notification Text : " + Notification_Text);
//                    }
                }
            }
        }


        return Notification_Text;
    }

    public static ArrayList<String> Read_Module_Names() throws IOException {
        ArrayList<String> keysList = null;
        try {
            Map<String, ArrayList<String>> excelMap = readExcel("C:\\workplace\\gandiva\\src\\test\\java\\testdata\\Notification_list.xls");
            // Get the keys (Module values) as an ArrayList
            keysList = new ArrayList<>(excelMap.keySet());
            // Print the keys
            System.out.println("Keys List : ");
            for (String key : keysList) {
                System.out.println(key);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return keysList;
    }


}
