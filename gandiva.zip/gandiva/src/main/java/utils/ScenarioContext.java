/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import utils.Context.Context;

//import io.cucumber.spring.ScenarioScope;

/*
 * This class is used to share data among scenario steps
 */
@Component
public class ScenarioContext {

    private Map<String, Object> scenarioContext;

    public ScenarioContext() {
        this.scenarioContext = new HashMap<>();
    }

    public void setContext(Context key, Object value) {
        this.scenarioContext.put(key.toString(), value);
    }

    public Object getContext(Context key) {
        return this.scenarioContext.get(key.toString());
    }

    public Boolean isContains(Context key) {
        return this.scenarioContext.containsKey(key.toString());
    }
}
