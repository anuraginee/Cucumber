package utils.table;

import com.codeborne.selenide.SelenideElement;

import java.util.List;

public interface table {
    int get_Row_Counts();

    int get_Column_Counts();

    public int getColumnIndexByColumnName(String columnName);

    SelenideElement get_Cell_ByIndex(int rowNumber, int columnNumber);

//    List<SelenideElement> get_Row_ByIndex(int rowNumber);
//
//    List<SelenideElement> get_Column_ByIndex(int columnNumber);
//
//    public List<SelenideElement> get_Column_ByColumnName(String columnName);

    public int getRowIndexByColumnContainingText(String columnName, String CellValue);

    SelenideElement get_Cell_Value_By_Index(int rowIndex, int columnIndex);
}
