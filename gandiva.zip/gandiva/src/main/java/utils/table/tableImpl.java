package utils.table;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class tableImpl implements table {
    SelenideElement table;
    List<SelenideElement> rows;
    List<SelenideElement> columns;

    public tableImpl(SelenideElement element) {
        table = element;
        rows = table.$$(By.xpath(".//tbody//tr"));
        columns = table.$$(By.xpath(".//tr[1]//td"));
    }// Constructor.

    /**
     * @return row counts
     */
    @Override
    public int get_Row_Counts() {
        return rows.size();
    }

    /**
     * @return numColumns counts
     */
    @Override
    public int get_Column_Counts() {
        return columns.size();
    }

    public int getColumnIndexByColumnName(String columnName) {
        int columnIndex = -1;
        for (int i = 1; i <= columns.size(); i++) {
            String col_text = $(By.xpath("//thead//tr//th[" + i + "]")).getText();////div//div[text()=' " + columnName + "']
            System.out.println("Column Text : " + col_text);
            if (col_text.toUpperCase().trim().equalsIgnoreCase(columnName)) {
                columnIndex = i;
                break;
            }
        }//for
        return columnIndex;
    }

    /**
     * @param rowIndex    rowIndex
     * @param columnIndex columnIndex
     * @return SelenideElement cell
     */
    @Override
    public SelenideElement get_Cell_ByIndex(int rowIndex, int columnIndex) {
        SelenideElement cell = rows.get(rowIndex).$$(By.xpath(".//td")).get(columnIndex - 1);
        System.out.println("get_Cell_ByIndex -> Cell :" + cell.getText());
        return cell;
    }

/// Approve_Action_Cell_ByIndex,Reject_Action_Cell_ByIndex functions are created only for approval and rejection for any of the request. Please Use this functions for mentioned reasons.

    public SelenideElement Approve_Action_Cell_ByIndex(int rowIndex, int columnIndex) {
        System.out.println("Row Value" + rows.get(rowIndex));
        System.out.println("Column Value" + rows.get(columnIndex));
        SelenideElement Cell = $(By.xpath("//table[@role='table' and@ng-reflect-data-source='[object Object]']//tbody//tr[" + 1 + "]//td[" + columnIndex + "]//button//span//img[@ng-reflect-message='Approve']"));
        System.out.println("get_Cell_ByIndex -> New Cell : " + Cell.getText());
        return Cell;
    }

    public SelenideElement Reject_Action_Cell_ByIndex(int rowIndex, int columnIndex) {
        System.out.println("Row Value" + rows.get(rowIndex));
        System.out.println("Column Value" + rows.get(columnIndex));
        SelenideElement Cell = $(By.xpath("//table[@role='table' and@ng-reflect-data-source='[object Object]']//tbody//tr[" + 1 + "]//td[" + columnIndex + "]//button//span//img[@ng-reflect-message='Reject']"));
        System.out.println("get_Cell_ByIndex -> New Cell : " + Cell.getText());
        return Cell;
    }

    /**
     * This Method Returns the row index of a row having cell whose value in a column say "Portal" is  some text
     *
     * @param columnName columnName
     * @param CellValue  CellValue
     * @return rowIndex number
     */
    @Override
    public int getRowIndexByColumnContainingText(String columnName, String CellValue) {
        int columnIndex = getColumnIndexByColumnName(columnName);
        int rowIndex = 0;
        System.out.println("Iterating through rows . . .");
        for (int i = 0; i < rows.size() - 1; i++) {
            System.out.println("getRowIndexByColumnContainingText : " + get_Cell_ByIndex(i, columnIndex).getText());
            if (get_Cell_ByIndex(i, columnIndex).getText().equalsIgnoreCase(CellValue)) {
                System.out.println("Assigning Row Number . . .");
                rowIndex = i;
                break;
            }
        }//for
        return rowIndex;
    }//method

    // Specifically used for Case participant scenarios
    public SelenideElement buildCellXPath(int rowIndex, int columnIndex) {
        System.out.println("Row Value" + rows.get(rowIndex));
        System.out.println("Column Value" + rows.get(columnIndex));
        SelenideElement Cell_Value = $(By.xpath("//table//tbody//tr[" + (1) + "]//td[" + (columnIndex) + "]//div"));
        System.out.println("get_Cell_ByIndex -> New Cell : " + Cell_Value.getText());
        return Cell_Value;
    }
    @Override
    public SelenideElement get_Cell_Value_By_Index(int rowIndex, int columnIndex) {
        SelenideElement cell = rows.get(rowIndex).$$(By.xpath(".//td")).get(columnIndex);
        System.out.println("get_Cell_ByIndex -> Cell :" + cell.getText());
        return cell;
    }



//    Anu Implementation

    public SelenideElement getCellByIndex(int rowIndex, int columnIndex) {
        SelenideElement cell = rows.get(rowIndex).$$(By.xpath(".//td")).get(columnIndex - 1);
        System.out.println("get_Cell_ByIndex -> Cell :" + cell.getText());
        return cell;
    }

}//class
