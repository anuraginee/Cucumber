/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils.dataprovider;

import java.io.IOException;
import java.util.Map;

public interface ExcelReader {
    boolean openWorksheet(String fileName, String sheetName);

    boolean openDefaultWorksheet(String fileName);

    void closeWorkBook() throws IOException;

    Map<String, String> getRow(int headerRowNumber, int rowNumber);

    Map<Integer, Map<String, String>> getDataInSheet(int headerRowNumber);

    int getTotalRows();

    Map<String, String> getRowByColumnVal(String columnValue, int columnNum, int headerRowNum);
}
