/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils.dataprovider;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
public class ExcelReaderImpl implements ExcelReader {
//    private Sheet currentSheet = null;
//    private Workbook workbook = null;

    private Workbook workbook;
    private Sheet currentSheet;

    @Override
    public boolean openWorksheet(String fileName, String sheetName) {
        FileInputStream excelFile = null;
        try {
            excelFile = new FileInputStream(new File(fileName));
        } catch (FileNotFoundException e) {
            Assert.fail("FileNotFoundException while opening the File " + fileName + "with details " + e.getMessage());
            e.printStackTrace();
        }
        try {
            this.workbook = new XSSFWorkbook(excelFile);
        } catch (IOException ioEx) {
            Assert.fail("IOException while opening workbook" + fileName + "with details " + ioEx.getMessage());
            ioEx.printStackTrace();
        }
        int numberOfSheets = workbook.getNumberOfSheets();
        boolean bfound = false;

        for (int i = 0; i < numberOfSheets; i++) {
            Sheet tempSheet = workbook.getSheetAt(i);
            if (tempSheet.getSheetName().compareTo(sheetName) == 0) {
                this.currentSheet = workbook.getSheetAt(i);
                bfound = true;
                break;
            }//if
        }//for
        if (!bfound) {
            try {
                this.workbook.close();
            } catch (IOException e) {
                Assert.fail("Error closing workbook");
                e.printStackTrace();
            }
        }//if
        return true;
    }

    @Override
    public boolean openDefaultWorksheet(String fileName) {
        FileInputStream excelFile = null;
        try {
            excelFile = new FileInputStream(new File(fileName));
        } catch (FileNotFoundException e) {
            Assert.fail("FileNotFoundException while opening the File " + fileName + "with details " + e.getMessage());
            e.printStackTrace();
        }
        try {
            this.workbook = new XSSFWorkbook(excelFile);
        } catch (IOException ioEx) {
            Assert.fail("IOException while opening workbook" + fileName + "with details " + ioEx.getMessage());
            ioEx.printStackTrace();
        }
        this.currentSheet = workbook.getSheetAt(0);
        return true;
    }

    @Override
    public void closeWorkBook() {
        try {
            this.workbook.close();
        }//try
        catch (IOException e) {
            Assert.fail("Error Closing workbook");
            e.printStackTrace();
        } //catch
    }

    @Override
    public Map<String, String> getRow(int headerRowNum, int rowNumber) {
        try {
            Map<String, String> rowMap = new HashMap<String, String>();
            DataFormatter dataFormatter = new DataFormatter();
            Row headerRow = this.currentSheet.getRow(rowNumber);
            int totalCells = headerRow.getLastCellNum();
            for (int i = 0; i < totalCells; i++) {
                String headerCell = dataFormatter.formatCellValue(headerRow.getCell(i));
                String rowCell = dataFormatter.formatCellValue(headerRow.getCell(i));
                rowMap.put(headerCell, rowCell);
            }
            return rowMap;
        }//try
        catch (Exception e) {
            return null;
        }
    }

    @Override
    public Map<Integer, Map<String, String>> getDataInSheet(int headerRowNumber) {
        try {
            Map<Integer, Map<String, String>> fullSheet = new HashMap<Integer, Map<String, String>>();
            Row headerRow = this.currentSheet.getRow(headerRowNumber);
            for (int j = headerRowNumber + 1; j < this.currentSheet.getLastRowNum(); j++) {
                Map<String, String> rowMap = new HashMap<String, String>();
                DataFormatter dataFormatter = new DataFormatter();
                Row row = this.currentSheet.getRow(j);
                int totalCells = headerRow.getLastCellNum();
                for (int i = 0; i < totalCells; i++) {
                    String headerCell = dataFormatter.formatCellValue(headerRow.getCell(i));
                    String rowCell = dataFormatter.formatCellValue(row.getCell(i));
                    rowMap.put(headerCell, rowCell);
                }//for
                fullSheet.put(j, rowMap);
            }//for
            return fullSheet;
        } catch (Exception e) {
            Assert.fail("I failed to Retrive workbook with message" + e.getMessage());
            return null;
        }
    }

    @Override
    public int getTotalRows() {
        return this.currentSheet.getLastRowNum();
    }

    @Override
    public Map<String, String> getRowByColumnVal(String columnValue, int columnNum, int headerRowNum) {
        try {
            for (Row tempRow : this.currentSheet) {
                String tempContent = tempRow.getCell(columnNum).getRichStringCellValue().toString();
                if (columnValue.compareTo(tempContent) == 0) {
                    int rowNumber = tempRow.getRowNum();
                    Map<String, String> rowMap = new HashMap<String, String>();
                    DataFormatter dataFormatter = new DataFormatter();
                    Row headerRow = this.currentSheet.getRow(headerRowNum);
                    Row row = this.currentSheet.getRow(rowNumber);
                    int totalCells = headerRow.getLastCellNum();
                    for (int i = 0; i < totalCells; i++) {
                        String headerCell = dataFormatter.formatCellValue(headerRow.getCell(i));
                        String rowCell = dataFormatter.formatCellValue(row.getCell(i));
                        rowMap.put(headerCell, rowCell);
                    }//for
                    return rowMap;
                }//if
            }//for
            return null;
        }//try
        catch (Exception e) {
            return null;
        }//catch

    }
    }
