/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils.dataprovider;

public interface ExcelWriter {
    public boolean createWorkBook(String fileName, String sheetName);

    void putHeaders(int rowNumber, String[] headers);

    void putRow(int rowNumber, String header, String value);

    void saveWorkbook(String excelFileName);
}
