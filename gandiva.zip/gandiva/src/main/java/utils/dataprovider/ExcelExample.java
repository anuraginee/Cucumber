/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils.dataprovider;

import java.util.Map;
import java.util.Map.Entry;


public class ExcelExample {
    public static void main(String[] args) {
        ExcelReaderImpl myExcel = new ExcelReaderImpl();
        myExcel.openWorksheet("C:\\workplace\\gandiva\\src\\main\\java\\utils\\dataprovider\\Notification_list.xlsx", "Notification_List");
        //get Total Rows
        int totalrows = myExcel.getTotalRows();
        System.out.println("Total rows :" + totalrows);

        //getDataIn Sheet
        Map<Integer, Map<String, String>> treemap = myExcel.getDataInSheet(0);// Header row
        for (Entry<Integer, Map<String, String>> entry : treemap.entrySet()) {
            System.out.println("Row Number :" + entry.getKey());
            Map<String, String> internalMap = entry.getValue();
            for (Entry<String, String> internalEntry : internalMap.entrySet()) {
                System.out.println("Key: " + internalEntry.getKey() + " Value " + internalEntry.getValue());
            }//for

        }//for

//        // getRow
        Map<String, String> rowMap = myExcel.getRow(3, 18);
        for (Entry<String, String> internalEntry : rowMap.entrySet()) {

            System.out.println("Key: " + internalEntry.getKey() + " Value " + internalEntry.getValue());
        }
        myExcel.closeWorkBook();
    }
}


