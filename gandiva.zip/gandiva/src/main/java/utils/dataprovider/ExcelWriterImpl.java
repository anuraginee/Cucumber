/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 08-09-2023
*/
package utils.dataprovider;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

public class ExcelWriterImpl implements ExcelWriter {

    private XSSFWorkbook workbook = null;
    private XSSFSheet sheet = null;
    // This Map holds the mapping of cell Number and header.
    private Map<String, Integer> headerMap = null;

    /**
     * Method to Create Workbook.
     *
     * @param fileName
     * @param sheetName
     * @return
     */
    @Override
    public boolean createWorkBook(String fileName, String sheetName) {

        try {
            // Create a new workbook
            this.workbook = new XSSFWorkbook();
            // Create new work sheet
            this.sheet = workbook.createSheet(sheetName);

        } catch (Exception e) {
            Assert.fail("Failed to Create workbook with message " + e.getMessage());
        }

        return true;
    }

    /**
     * Method to Put Headers.
     *
     * @param rowNumber
     * @param headers
     */
    @Override
    public void putHeaders(int rowNumber, String[] headers) {
        try {
            Row row = sheet.createRow(rowNumber);
            for (int i = 0; i < headers.length; i++) {
                Cell cell = row.createCell(i);
                headerMap.put(headers[0], i);
            }//for
        }//try
        catch (Exception e) {
            Assert.fail("Failed to put header with message " + e.getMessage());
        }
    }

    /**
     * Method to put Row.
     *
     * @param rowNumber
     * @param header
     * @param value
     */
    @Override
    public void putRow(int rowNumber, String header, String value) {
        try {
            Row row = sheet.createRow(rowNumber);
            int cellNum = this.headerMap.get(header);
            Cell cell = row.createCell(cellNum);
            cell.setCellValue(value);
        }//try
        catch (Exception e) {
            Assert.fail("Failed to save row " + e.getMessage());
        }
    }

    /**
     * Method to save Workbook.
     *
     * @param excelFileName
     */
    @Override
    public void saveWorkbook(String excelFileName) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(excelFileName));
        } catch (FileNotFoundException e) {
            Assert.fail("Failed to save Excel " + e.getMessage());
        }
        try {
            workbook.write(out);
        } catch (IOException e) {
            Assert.fail("Failed to save Excel " + e.getMessage());
        }
    }
}
