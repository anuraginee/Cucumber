package utils.SelectDropDown;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.springframework.stereotype.Component;

@Component
public class SelectDropDownValue {

    public static void toSelectDropDown(ElementsCollection list, String dropdownvalue) throws InterruptedException {
        for (SelenideElement e : list) {
            if (e.getText().equals(dropdownvalue)) {
                e.should(Condition.visible).click();
                Thread.sleep(3000);
                break;
            }

        }
    }

}
