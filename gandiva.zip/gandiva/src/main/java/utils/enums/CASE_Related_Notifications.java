package utils.enums;

public enum CASE_Related_Notifications
{
    Case_Initiation("Case Initiation"),

    CASE_REJECT_ACTION("Reject");
    public final String Case_Notification;

    CASE_Related_Notifications(String act) {
        this.Case_Notification = act;
    }

    public String Case_Related_Notification() {
        return Case_Notification;
    }
}
