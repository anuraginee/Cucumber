package utils.enums;

public enum Sharing_Actions
{
    Share_To_Agency_Mart("Push To Agency Mart"),
    Share_with_Specific_Users_within_Agency("Share with Specific Users (within Agency)"),
    Push_To_Common_Mart("Push To Common Mart"),
    Share_with_Specific_Agency("Share with Specific Agency");
    private final String action;

    Sharing_Actions(String act) {
        this.action = act;
    }

    public String getAction() {
        return action;
    }
}
