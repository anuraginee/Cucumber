package utils.enums;

public enum CASE_ATTRIBUTES
{
    CASE_REQUEST_SUBMITTED("Case Request Submitted"),
    CASE_APPROVED("Case Approved"),
    CASE_Rejected("Case Rejected"),
    CASE_CLOSED("Case Close Approved"),
    Case_ReOpen_Approved("Case Reopen Approved"),
    Case_Close_Request_Submitted("Case Close Request Submitted"),
    Transfer_Request_Rejected("Transfer Request Rejected");
    private final String Status;

    CASE_ATTRIBUTES(String Stat) {
        this.Status = Stat;
    }

    public String getAttributes() {
        return Status;
    }
}
