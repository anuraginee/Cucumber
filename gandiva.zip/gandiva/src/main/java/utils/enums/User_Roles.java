package utils.enums;

public enum User_Roles
{
    DESIGNATED_OFFICER("DESIGNATED OFFICER"),
    AUTHORIZED_OFFICER("AUTHORIZED OFFICER"),
    SUPERVISORY_OFFICER("SUPERVISORY OFFICER"),
    APPROVING_OFFICER("APPROVING OFFICER");
    private final String action;

    User_Roles(String act) {
        this.action = act;
    }

    public String getAction() {
        return action;
    }
}
