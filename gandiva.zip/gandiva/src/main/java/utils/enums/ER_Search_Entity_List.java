package utils.enums;

public enum ER_Search_Entity_List
{
    PERSON("PERSON"),
    VEHICLE("VEHICLE"),
    ORGANIZATION("ORGANIZATION");
    private final String action;

    ER_Search_Entity_List(String act) {
        this.action = act;
    }

    public String getAction() {
        return action;
    }
}
