package utils.enums;

public enum CASE_STATUS
{
    CASE_INITIATION("Initiation"),
    CASE_CLOSE("Close"),
    CASE_TRANSFER("Transfer"),
    CASE_REOPEN("Re-Open"),
    CASE_ARCHIVE ("Archive");
    private final String status;

    CASE_STATUS(String act) {
        this.status = act;
    }

    public String getStatus() {
        return status;
    }
}
