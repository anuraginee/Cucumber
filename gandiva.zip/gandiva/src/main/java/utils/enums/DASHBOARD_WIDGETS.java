package utils.enums;

public enum DASHBOARD_WIDGETS
{

// Widgets  Cases
    CASES_TOTAL("Cases", "Total"),
    CASES_ACTIVE("Cases", "Active"),
    CASES_CLOSED("Cases", "Closed"),
    PENDINGCASELEVELREQUESTS_TOTAL("Pending Case Level Requests", "Total"),
    PENDINGCASELEVELREQUESTS_Rejected("Pending Case Level Requests", "Rejected"),
    PENDINGCASELEVELREQUESTS_Initiation("Pending Case Level Requests", "Initiation"),
    PENDINGCASELEVELREQUESTS_Transfer("Pending Case Level Requests", "Transfer"),
    PENDINGCASELEVELREQUESTS_ReOpen("Pending Case Level Requests", "Re-Open"),
    PENDINGCASELEVELREQUESTS_Close("Pending Case Level Requests", "Close"),
    TRANSFERREDCASES_TOTAL("Transferred Cases", "Total"),
    TRANSFERREDCASES_Active("Transferred Cases", "Active"),
    TRANSFERREDCASES_Closed("Transferred Cases", "Closed"),

    IngestedDataRequests_ER("Ingested Data Requests", "ER"),
    IngestedDataRequests_Profile("Ingested Data Requests", "Profile"),
    IngestedDataRequests_Image("Ingested Data Requests", "Image"),
    IngestedDataRequests_PO_Wise("Ingested Data Requests", "PO-Wise"),
    ScheduledQueries_Total("Scheduled Queries","Total"),
    ScheduledQueries_Active("Scheduled Queries","Active"),
    ScheduledQueries_Inactive("Scheduled Queries","Inactive"),
    ScheduledQueries_Pending("Scheduled Queries","Pending"),
    ScheduledQueries_Rejected("Scheduled Queries","Rejected"),
    PendingQRRequests_Total("Pending QR Requests","Total"),
    Pending_Highly_Sensitive_Queries_at_PO_Total("Pending Highly Sensitive Queries at PO","Total"),
    PENDINGScheduledQueryREQUESTS_TOTAL("Pending Scheduled Query Requests", "Total"),
    PENDINGMARTREQUESTS_Common_Mart("Pending Mart Requests", "Common Mart"),
    PENDINGMARTREQUESTS_Agency_Mart("Pending Mart Requests", "Agency Mart"),
    Pending_Common_Mart_Requests("Pending Common Mart Requests", "Total"),

// Admin portal widgets

    Organizations_Enrolled_Total ("Organizations Enrolled", "Total"),
    Organizations_Enrolled_Active ("Organizations Enrolled", "Active"),
    Organizations_Enrolled_Inactive ("Organizations Enrolled", "Inactive"),

    Total_Nodal_Officers ("Total Nodal Officers", "Total"),
    Active_Nodal_Officers ("Total Nodal Officers", "Active"),
    Inactive_Nodal_Officers ("Total Nodal Officers", "Inactive"),


    Total_User("Total User", "Total"),
    Total_User_Active("Total User", "Active"),

    Total_User_Inactive("Total User", "Inactive"),


    Action_Pending_on_QR_Requests_with_Admin("Action Pending on QR Requests with Admin", "Total"),

    QR_Requests_Initiated("QR Requests", "Request Initiated"),

    QR_Response_Received("QR Requests", "Response Received"),

    Approval_Awaited_On_Highly_Sensitive_Query_At_PO("Approval Awaited On Highly Sensitive Query At PO", "Total"),

    Action_Pending_On_Profile_Update_Request("Action Pending On Profile Update Request", "Total"),

    Ingested_Data_Requests_ER("Ingested Data Requests", "ER"),
    Ingested_Data_Requests_PO_Wise ("Ingested Data Requests", "PO-Wise"),
    Ingested_Data_Requests_Profile ("Ingested Data Requests", "Profile"),
    Ingested_Data_Requests_Image ("Ingested Data Requests", "Image"),

    Scheduled_Query_Requests_Total("Scheduled Query Requests", "Total"),
    Scheduled_Query_Requests_Active("Scheduled Query Requests", "Active"),

    Scheduled_Query_Requests_Inactive("Scheduled Query Requests", "Inactive"),

    Scheduled_Query_Requests_Pending("Scheduled Query Requests", "Pending"),
    Scheduled_Query_Requests_Rejected("Scheduled Query Requests", "Rejected"),


    // PO Portal Widgets

    Requests_Received("Requests Received", "Total"),
    Requests_Responded("Requests Responded", "Total"),

    Pending_Requests("Pending Requests", "Total"),

    Error_Requests("Error Requests", "Total"),

    //    Extends Enum with other widgets
    QRREQUESTS_Request_Raised("QR Requests", "Request Raised"),
    QRREQUESTS_Response_Received("QR Requests", "Response Received"),

//    User-Widget for Nodal Officer
    USERS_TOTAL("Users", "Total"),
    USERS_ACTIVE("Users", "Active"),
    USERS_INACTIVE("Users", "Inactive");


    private final String widgetName;
    private final String paramName;


    DASHBOARD_WIDGETS(String widget, String param) {
        this.widgetName = widget;
        this.paramName = param;
    }

    public String getWidgetName() {
        return widgetName;
    }

    public String getParamName() {
        return paramName;
    }

}
