package utils.enums;

public enum Notification_List
{
    Account_Change_Password("Your application password would expire in "),
    Account_Password_Changed_Successfully("You have successfully changed password."),
    User_Account_Locked("User Account with User ID"),
    User_Account_Permission_Modified("Your permission to access the application is modified."),
    Profile_Update("Profile Update Request for"),
    Profile_Information_Approved_Nodal("Nodal officer has Approved your update profile information request. "),
    Profile_Information_Rejected_Nodal("Nodal officer has Rejected your update profile"),
    Profile_Information_Approved_NGAdmin("Nodal officer has Approved your update profile information request. "),
    Profile_Information_Rejected_NGAdmin("Nodal officer has Rejected your update profile"),
    Use_Case_Configuration_Changed("is changed by NATGRID."),
    Use_Case_Configuration_Added(" is added by NATGRID."),
    Use_Case_Configuration_Revoked(" is revoked by NATGRID."),
    Push_Notification_Application_Offline("Application will be offline for maintenance purposes between"),
    Push_Notification_Application_New_Feature("Application has been updated with new features"),
    Case_Initiation_Request("Case Initiation request for Case ID"),
    Case_Initiation_Request_Approved_Rejected("Initiation request for Case ID"),
    Case_Close_Request("Close case request for Case ID"),
    Case_Close_Request_Approved_Rejected("Request to close the case with Case ID"),

    ;

    private final String Notification;

    Notification_List(String act) {
        this.Notification = act;
    }

    public String getNotification() {
        return Notification;
    }
}
