package utils.enums;

public enum CASE_ACTIONS
{
    TRANSFER_CASE("Transfer case"),
    CASE_CLOSE("Case Close"),
    VIEW_CASE("View case"),
    CASE_REOPEN("Case Reopen"),
    CASE_ARCHIVE("Case Archive"),
    CASE_APPROVE_ACTION("Approve"),
    Share_to_Agency_Mart("Share to Agency Mart"),
    Create_Scheduled_Query("Create Scheduled Query"),
    CASE_REJECT_ACTION("Reject");
    private final String action;

    CASE_ACTIONS(String act) {
        this.action = act;
    }

    public String getAction() {
        return action;
    }
}
