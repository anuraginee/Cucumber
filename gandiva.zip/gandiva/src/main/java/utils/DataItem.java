package utils;

/*
 * You need to add your variable which is shared between steps here
 */
public enum DataItem {
    COLLECTION_NAME /*String*/,
    CASE_NAME /* Name of the Case*/,
}