package utils.Notification;

import PageObject.Common.CommonElements;
import PageObject.UserAgentPortal.Dashboard.UA_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.Scenario;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import utils.Context.Context;
import utils.enums.Notification_List;
import utils.excelRead.Excel_Hashmap;
import utils.table.tableImpl;

import java.io.IOException;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.actions;
import static utils.Highlighter.highlight;

@Component
public class Notification {

    @Autowired
    private static UA_dashboard ua_dashboard;


    public static void Notification_Work_Flow() throws InterruptedException {
        Thread.sleep(3000);
        highlight(ua_dashboard.Notification_Icon,"green").click();
        actions().scrollToElement(CommonElements.Notification_View_All).build().perform();
        CommonElements.Notification_View_All.click();
        CommonElements.Notification_Heading.shouldBe(Condition.appear);
        actions().moveToElement(CommonElements.Notification_Heading).click().perform();
        //    public static final tableImpl Notification_Table = new tableImpl($(By.xpath("//table[@role=\"table\" and @ng-reflect-data-source=\"[object Object]\"]")).should(Condition.appear));
    }


}
