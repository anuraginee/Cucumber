package PageObject.AdminPortal.Attention;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Attention {

    public static final SelenideElement addMessage = $(By.xpath("//*[text()='Add Message ']"));

    public static final SelenideElement titleField = $(By.xpath("//*[@formcontrolname='title']"));

    public static final SelenideElement descriptionField = $(By.xpath("//*[@formcontrolname='content']"));

    public static final SelenideElement submitBtn = $(By.xpath("//*[text()='Submit']"));




}
