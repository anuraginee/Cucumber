package PageObject.AdminPortal.UserActivityLogs;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class AdminPortalActivity  {

public static final SelenideElement orgType = $(By.xpath("//mat-label[text()='Organization Type']"));

public static final SelenideElement orgName = $(By.xpath("//mat-label[text()='Organization Name']"));
public static final ElementsCollection orgTypesList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

public static final SelenideElement search = $(By.xpath("//*[@placeholder='search']"));

public static final SelenideElement adminUser = $(By.xpath("//*[@id='selectOrganization']"));

 public static final ElementsCollection adminUserList = $$(By.xpath("//*[@class='mat-option-text']"));

public static final SelenideElement activityLogPage = $(By.xpath("//*[text()=' User Activity Logs ']"));
public static final SelenideElement submitActivityPage = $(By.xpath("//*[text()='Submit']"));


public static final SelenideElement nodalUserID = $(By.xpath("//*[@formcontrolname='userName']"));

 public static final SelenideElement nodalPassword = $(By.xpath("//*[@formcontrolname='passcode']"));

 public static final SelenideElement userActivityCaptcha = $(By.xpath(" //div[@class='captcha']"));
 public static final SelenideElement userActivityCptchaField =$(By.xpath("//*[@formcontrolname='captcha']"));

 public static final  SelenideElement otpField = $(By.xpath("//*[@formcontrolname='otp']"));
 public static final SelenideElement verifybtn = $(By.xpath("//span[normalize-space()='Verify']"));

 public static final SelenideElement activityLogTable = $(By.xpath("//*[@id='table_hide']"));


 public void activityLogin() {
  verifybtn.should(Condition.enabled).click();
 }
}












