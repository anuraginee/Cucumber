/**
 * Author : Prashant Deshmukh
 * Project : Natgrid (Gandiva)
 * Dated : 21-07-2023
*/
package PageObject.AdminPortal.Dashboard;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


/**
 * Page Object Class for Admin Dashboard.
 */
@Component
public class Admin_dashboard extends CommonElements {
    //    public static final SelenideElement administrator_icon = $(By.className("sidenav-logo select-none flex-none"));
    public static final SelenideElement bar_dashboard = $(By.xpath("//mat-sidenav-container//span[text()=\"Dashboard\"]"));

    public static final SelenideElement User_role = $(By.xpath("//span[text()='NATGRIDADMIN']"));
    public static final SelenideElement Logout = $(By.xpath("//div//a//span[contains(text(),'Logout')]"));

    public static final SelenideElement bar_OrganizationTypeManagement = $(By.xpath("//mat-sidenav-container//span[text()=\"Organization Type Management\"]"));
    public static final SelenideElement bar_PortalManagement = $(By.xpath("//mat-sidenav-container//span[text()=\"Portal Management\"]"));
    public static final SelenideElement bar_RoleManagement = $(By.xpath("//mat-sidenav-container//span[text()=\"Role Management\"]"));
    public static final SelenideElement bar_OrganizationManagement = $(By.xpath("//mat-sidenav-container//span[text()=\"Organization Management\"]"));
    public static final SelenideElement bar_UserManagement = $(By.xpath("//*[text()='User Management']"));
    public static final SelenideElement bar_UserManagement_Users= $(By.xpath("//*[text()='Users']"));

    public static final SelenideElement profile_Updates_Approvals= $(By.xpath("//mat-sidenav-container//span[text()='Profile Updates – Approvals']"));
    public static final SelenideElement workflow_Management = $(By.xpath("//mat-sidenav-container//span[text()=\"Workflow Management\"]"));
    public static final SelenideElement use_Case_Management = $(By.xpath("//mat-sidenav-container//span[text()=\"Use Case Management\"]"));

    public static final SelenideElement requestTemplates = $(By.xpath("//*[text()='Request Templates']"));
    // Activity Notifications
    public static final SelenideElement activity_Notifications = $(By.xpath("//mat-sidenav-container//span[text()=\"Activty Notifications\"]"));
    public static final SelenideElement push_Notifications = $(By.xpath("//mat-sidenav-container//span[text()=\"Push Notifications\"]"));
    public static final SelenideElement masters = $(By.xpath("//mat-sidenav-container//span[text()=\"Masters\"]"));
    public static final SelenideElement queryApproval = $(By.xpath("//mat-sidenav-container//span[text()=\"Query Approval\"]"));
    public static final SelenideElement user_Activity_Logs = $(By.xpath("//mat-sidenav-container//span[text()=\"User Activity Logs\"]"));
    public static final SelenideElement Feedback = $(By.xpath("//mat-sidenav-container//span[text()=\"Feedback\"]"));
    public static final SelenideElement reports = $(By.xpath("//mat-sidenav-container//span[text()=\"Reports\"]"));

    public static final SelenideElement adminUsers = $(By.xpath("//*[text()='Admin Users']"));
    public static final SelenideElement manageTerminalMenu = $(By.xpath("//*[text()='Manage Terminal - Admin']"));

    public static final SelenideElement manageUSBMenu = $(By.xpath("//*[text()='Manage USB - Admin']"));

    public static final SelenideElement attention = $(By.xpath("//*[text()='Attention']"));








    public void clickLink(String linkName) {
        SelenideElement link = $(By.xpath("//mat-sidenav-container//span[text()=" + linkName + "]"));
        link.click();

    }
}
