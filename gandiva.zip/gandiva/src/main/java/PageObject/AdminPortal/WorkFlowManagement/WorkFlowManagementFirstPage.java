package PageObject.AdminPortal.WorkFlowManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class WorkFlowManagementFirstPage {

    public static final tableImpl workFlow_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hide']")).should(Condition.appear));
    public static final SelenideElement addWorkFlowBtn = $(By.xpath("//*[text()=' Add Work Flow ']"));

    public static final SelenideElement orgType = $(By.xpath("//*[@placeholder='Organization Type']"));

    public static final ElementsCollection orgTypeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement selectOrgName = $(By.xpath("//*[@formcontrolname='orgIdUa']"));

    public static final ElementsCollection orgNameList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement eventCode = $(By.xpath("//*[@formcontrolname='workflowEventCode']"));

    public static final ElementsCollection eventCodeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement workFlowName = $(By.xpath("//*[@formcontrolname='workflowName']"));

    public static final SelenideElement workFlowSubmit = $(By.xpath("//*[text()='Submit']"));

    public static final SelenideElement workFlowSearch = $(By.xpath("//*[@placeholder='Search']"));

    public static final ElementsCollection userAgencyList = $$(By.xpath("//*[@id='pdfTable']//tbody/tr//td"));

    public static final SelenideElement updateButton = $(By.xpath("//*[@role='menuitem']"));

    public static final SelenideElement workFlowUpdate = $(By.xpath("//*[text()='Update']"));

}
