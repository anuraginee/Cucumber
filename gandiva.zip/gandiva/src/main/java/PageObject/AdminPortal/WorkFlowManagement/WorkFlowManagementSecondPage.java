package PageObject.AdminPortal.WorkFlowManagement;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class WorkFlowManagementSecondPage {

    public static final SelenideElement stepName = $(By.xpath("//*[@formcontrolname='workflowStepName']"));

    public static final SelenideElement stepDescription = $(By.xpath("//*[@formcontrolname='workflowStepDescription']"));



    public static final SelenideElement roleName = $(By.xpath("//*[@formcontrolname='assignedToRole']"));

    public static final ElementsCollection roleNameList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement stepStatus = $(By.xpath("(//*[@ng-reflect-name='stepStatusDefault'])[1]"));

    public static final SelenideElement stepStatusDropdown = $(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement addMoreLevels = $(By.xpath("//*[text()=' Add more levels']"));

    public static final SelenideElement stepTypeIntermidiate = $(By.xpath("(//*[@formcontrolname='workflowStepTypeId'])[2]"));

    public static final ElementsCollection stepTypeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement stepSequneceIntermidiate = $(By.xpath("(//*[@formcontrolname='workflowStepSeq'])[2]"));

    public static final ElementsCollection stepSeqList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement stepNameIntermidiate = $(By.xpath("(//*[@formcontrolname='workflowStepName'])[2]"));

    public static final SelenideElement roleNameIntermidiate = $(By.xpath("(//*[@formcontrolname='assignedToRole'])[2]"));

    public static final SelenideElement stepDescriptionIntermidiate = $(By.xpath("(//*[@formcontrolname='workflowStepDescription'])[2]"));

    public static final SelenideElement recommendedStatus = $(By.xpath("(//*[@formcontrolname='stepStatusPositiverecmd'])[2]"));
    public static final SelenideElement approvedStatus = $(By.xpath("(//*[@formcontrolname='stepStatusPositive'])[2]"));

    public static final SelenideElement notrecommendedStatus = $(By.xpath("(//*[@formcontrolname='stepStatusNegativerecmd'])[2]"));
    public static final SelenideElement rejectedStatus = $(By.xpath("(//*[@formcontrolname='stepStatusNegative'])[2]"));

    public static final SelenideElement intermRecommend =$(By.xpath("(//*[@class='mdc-list-item__primary-text'])[1]"));

    public static final SelenideElement intermNotRecommend = $(By.xpath("(//*[@class='mdc-list-item__primary-text'])[2]"));

    public static final SelenideElement intermIsMandatory = $(By.xpath("(//*[@ng-reflect-name='isStepMandatory'])[2]"));

    public static final SelenideElement isMantatoryYes = $(By.xpath("(//*[@class='mdc-list-item__primary-text'])[1]"));

    public static final SelenideElement previousStep = $(By.xpath("(//*[@formcontrolname='workflowStepIdPrevName'])[2]"));

    public static final ElementsCollection previousStepList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement secondPageSubmit = $(By.xpath("(//*[text()='Submit'])[2]"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement isMantatoryNo = $(By.xpath("(//*[@class='mdc-list-item__primary-text'])[2]"));

    public static final SelenideElement stepTypeTerminator = $(By.xpath("(//*[@formcontrolname='workflowStepTypeId'])[3]"));

    public static final SelenideElement stepNameTerminator = $(By.xpath("(//*[@formcontrolname='workflowStepName'])[3]"));

    public static final SelenideElement stepDescriptionTerminator = $(By.xpath("(//*[@formcontrolname='workflowStepDescription'])[3]"));

    public static final SelenideElement stepSequneceTerminator = $(By.xpath("(//*[@formcontrolname='workflowStepSeq'])[3]"));

    public static final SelenideElement approvedStatusTerminator = $(By.xpath("(//*[@formcontrolname='stepStatusPositive'])[3]"));

    public static final SelenideElement rejectedStatusTerminator = $(By.xpath("(//*[@formcontrolname='stepStatusNegative'])[3]"));

    public static final SelenideElement termIsMandatory = $(By.xpath("(//*[@ng-reflect-name='isStepMandatory'])[3]"));

    public static final SelenideElement termPreviousStep = $(By.xpath("(//*[@formcontrolname='workflowStepIdPrevName'])[3]"));

    public static final SelenideElement roleNameTerminator = $(By.xpath("(//*[@formcontrolname='assignedToRole'])[3]"));
}
