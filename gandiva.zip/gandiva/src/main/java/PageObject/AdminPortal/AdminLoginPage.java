/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.*;

@Component
public class AdminLoginPage {
    //LOGIN FORM FIELDS
    public static final SelenideElement usernameField = $(By.id("mat-input-0"));
    public static final SelenideElement passwordField = $(By.id("mat-input-1"));
    public static final SelenideElement adminCaptchaField = $(By.xpath("//*[contains(@class,'captcha-text')]"));
    public static final SelenideElement adminCaptchaTextField = $(By.id("mat-input-2"));
    public static final SelenideElement loginButton = $(By.xpath("//button//span[text()=\" LOGIN \"]"));
    public static final SelenideElement verificationCodeTextField = $(By.id("mat-input-3"));

    public void adminLogin() {
        loginButton.should(Condition.enabled).click();
    }
}