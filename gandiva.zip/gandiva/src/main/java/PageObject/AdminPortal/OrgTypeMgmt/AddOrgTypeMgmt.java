/*
Author : Somnath Jarhad
Project : Natgrid (Gandiva)
Dated : 17-08-2023
*/
package PageObject.AdminPortal.OrgTypeMgmt;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class AddOrgTypeMgmt {
    public static final SelenideElement btn_AddOrgType = $(By.xpath("//*[text()='Add Organization Type ']"));
    public static final SelenideElement OrgType = $(By.xpath("//*[@ng-reflect-name='organizationType']"));

    public static final SelenideElement OrgType_fieldValidation = $(By.xpath("//mat-error[text()=' Organization type is required ']"));

    public static final SelenideElement Alias = $(By.xpath("//*[@ng-reflect-name='organizationAlias']"));
    public static final SelenideElement Alias_fieldValidation = $(By.xpath("//mat-error[text()=' Alias is required ']"));
    public static final SelenideElement Description = $(By.xpath("//*[@ng-reflect-name='description']"));
//    Anuraginee: Changing the xpaths for Submit and Cancel button
    public static final SelenideElement Submit = $(By.xpath("//*[text()='Submit']"));
    public static final SelenideElement Cancel = $(By.xpath("//*[text()='Cancel']"));

    public static final SelenideElement SearchOrgType = $(By.xpath("//*[@placeholder='Search ...']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement firstRowofTable = $(By.xpath("//tbody//tr[@role='row']"));

}


