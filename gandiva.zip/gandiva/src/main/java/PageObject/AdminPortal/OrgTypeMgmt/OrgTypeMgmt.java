/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 26-09-2023
*/
package PageObject.AdminPortal.OrgTypeMgmt;

import com.codeborne.selenide.Condition;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class OrgTypeMgmt {
    public static final tableImpl org_Type_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hide']")).should(Condition.appear));

}


