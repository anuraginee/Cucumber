package PageObject.AdminPortal.UseCaseManagement;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class UsecaseMapping {

    public static final SelenideElement selectPO = $(By.xpath("//*[@placeholder='Select Providing  Organization']"));
    public static final SelenideElement Select_PO_From_List = $(By.xpath("//*[//*[@label='data.orgName']//span]"));


    public static final ElementsCollection poList = $$(By.xpath("//*[@class='mat-option-text']"));
    public static final SelenideElement selectUA = $(By.xpath("//*[@placeholder='Select User Agency']"));

    public static final ElementsCollection uaList = $$(By.xpath("//*[@class='mat-option-text']"));

   public static final SelenideElement usecaseMapSubmit =$(By.xpath("//*[text()=' Submit ']"));



}
