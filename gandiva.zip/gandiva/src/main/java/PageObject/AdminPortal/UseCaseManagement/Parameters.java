package PageObject.AdminPortal.UseCaseManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class Parameters {
    public static final SelenideElement paramSearch = $(By.xpath("//*[@data-mat-icon-name='search']//following-sibling::input[@placeholder='Search ...']"));
    public static final SelenideElement Add_Parameter = $(By.xpath("//span[contains(@class,'mat-button-wrapper') and contains(text(),'Add Parameter')]"));

    public static final SelenideElement poList = $(By.xpath("//span[contains(@class,mat-select-min-line) and contains(text(),'Please Select')]"));
    public static final ElementsCollection commonList = $$(By.xpath("//div[contains(@class,'ng-trigger-transformPanel') and @role='listbox']"));
    public static final SelenideElement param_Name = $(By.xpath("//input[@formcontrolname='param_Name']"));
    public static final SelenideElement param_Key = $(By.xpath("//input[@formcontrolname='param_Key']"));

    public static final SelenideElement param_Type = $(By.xpath("//mat-select[contains(@id,'mat-select') and contains(@formcontrolname,'param_Type')]"));

    public static final SelenideElement is_Queryable = $(By.xpath("//mat-select[@ng-reflect-name='isQueryable']"));

    public static final SelenideElement Submit_Button = $(By.xpath("//mat-dialog-actions[@align=\"end\"]//button[@type='submit']"));
    public static final SelenideElement Search_Text_Box = $(By.xpath("//*[@placeholder=\"search\"]"));

    public static final SelenideElement Select_PO = $(By.xpath("//*[@label=\"data.orgName\"]"));
    public static final SelenideElement Select_Param_Type = $(By.xpath("(//*[@label=\"dataNew.paramName\"])[1]"));


    public static final SelenideElement paramUpdate = $(By.xpath("//*[text()='Update']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//button[contains(@class,'mat-button-wrapper') and @type='CANCEL']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));
    public static final tableImpl paramTable = new tableImpl($(By.xpath("//*[@id='table_hide']")).should(Condition.appear));

    public static final SelenideElement Param_Type(String Param_Name) {
        SelenideElement ParamType = $(By.xpath("//div[contains(@class,'ng-trigger-transformPanel') and @role='listbox']//mat-option[@label='dataNew.paramName']//span[contains(text(),'" + Param_Name + "')]"));
        return ParamType;
    }

    public static final SelenideElement Is_Queryable(String Value) {
        SelenideElement ParamType = $(By.xpath("//div[contains(@class,'ng-trigger-transformPanel') and @role='listbox']//mat-option[contains(@class,'mdc-list-item')]//span[contains(text(),'" + Value + "')]"));
        return ParamType;
    }


}
