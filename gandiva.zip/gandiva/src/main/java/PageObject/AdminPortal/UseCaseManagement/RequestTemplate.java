package PageObject.AdminPortal.UseCaseManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Sleeper;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class RequestTemplate {

   public static final SelenideElement reqTempSearch = $(By.xpath("//*[@data-mat-icon-name='search']//following-sibling::input[@placeholder='Search ...']"));
   public static final SelenideElement addRequestTemp =$(By.xpath("//*[@ng-reflect-message='Add Request Template']"));
   public static final SelenideElement selectPO = $(By.xpath("//*[@formcontrolname='orgIdPo']"));
   public static final SelenideElement reqTempName = $(By.xpath("//*[@formcontrolname='reqTemplateName']"));
   public static final SelenideElement descrpt = $(By.xpath("//*[@formcontrolname='reqTplDesc']"));

   public static final SelenideElement selectParam = $(By.xpath("//*[@formcontrolname='paramId']"));

   public static final SelenideElement selectInputType = $(By.xpath("//*[@formcontrolname='inputTypeId']"));

   public static final SelenideElement selectValidation = $(By.xpath("//*[@formcontrolname='validationId']"));

   public static final SelenideElement paramOrder = $(By.xpath("//*[@formcontrolname='paramOrder']"));

   public static final SelenideElement dependsOn = $(By.xpath("//*[@formcontrolname='dependsOn']"));

   public static final SelenideElement helpText = $(By.xpath("//*[@formcontrolname='helpText']"));

   public static final SelenideElement sqlQuery = $(By.xpath("//*[@formcontrolname='sqlQuery']"));

   public static final SelenideElement isMandatory = $(By.xpath("//*[@ng-reflect-name='isMandatory']"));

   public static final SelenideElement groupWith = $(By.xpath("//*[@ng-reflect-name='groupWith']"));

   public static final SelenideElement optionalGroupWith = $(By.xpath("//*[@ng-reflect-name='optinalGroupWith']"));

   public static final SelenideElement dependsOnCondition = $(By.xpath("//*[@ng-reflect-name='dependsOnCondition']"));

   public static final SelenideElement isPartial = $(By.xpath("//*[@ng-reflect-name='isPartial']"));

   public static final SelenideElement dateRange = $(By.xpath("//*[@ng-reflect-name='dateRange']"));

   public static final SelenideElement isFutureDateEnable = $(By.xpath("//*[@ng-reflect-name='isFutureDateRangeEnable']"));

   public static final SelenideElement isCurrentDateEnable = $(By.xpath("//*[@ng-reflect-name='isCurrentDateEnable']"));

   public static final SelenideElement errorMessage = $(By.xpath("//*[@ng-reflect-name='errorMessage']"));

   public static final SelenideElement sqlQueryCondition = $(By.xpath("//*[@ng-reflect-name='sqlQueryCondition']"));

   public static final SelenideElement requestSubmit = $(By.xpath("//*[text()='Submit']"));

   public static final tableImpl reqTempTable = new tableImpl($(By.xpath("//*[@id='table_hide']")).should(Condition.appear));

   public static final SelenideElement reqTempUpdate = $(By.xpath("//*[text()='Update']"));








}
