/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.UseCaseManagement;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class UseCaseManagement {
    public static final SelenideElement gandiva_icon = $(By.className("relative"));
    // Cart Users
    public static final SelenideElement cart_users_Total = $(By.xpath("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/following::div[1]"));
    public static final SelenideElement bar_dashboard = $(By.xpath("//fuse-vertical-navigation//div//span[text()=\"Dashboard\"]"));
    // Admin Case mapping
    public static final SelenideElement Use_case_Management = $(By.xpath("//span[contains(@class,'item-label') and contains(text(),'Use Case Management')]"));
    // Use Case Management Child Class
    public static final SelenideElement Parameters = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Parameters')]"));
    public static final SelenideElement Request_Templates = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Request Templates')]"));
    public static final SelenideElement Response_Templates = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Response Templates')]"));
    public static final SelenideElement Use_Cases = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Use Cases')]"));
    public static final SelenideElement Use_Case_Mapping = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Use Case Mapping')]"));
    // Parameters page xpath_IDs
    public static final SelenideElement Add_Parameter = $(By.xpath("//span[contains(@class,'mat-button-wrapper') and contains(text(),'Add Parameter')]"));
    //Create new parameter


    public void clickLink(String linkName) {
        SelenideElement link = $(By.xpath("//at-sidenav-container//span[text()=" + linkName + "]"));
        link.click();
    }

}
