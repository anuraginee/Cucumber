package PageObject.AdminPortal.ManageUSB;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class ManageUSB {

   public static final SelenideElement manageUSBMenu = $(By.xpath("//*[text()='Manage USB']"));

   public static final SelenideElement approveUSB = $(By.xpath("//*[text()='Approve USB']"));

   public static final SelenideElement existingUSB = $(By.xpath("//*[text()='Existing USB Devices']"));

    public static final SelenideElement approveBtn = $(By.xpath("(//*[@mattooltip='Approve'])[1]"));

    public static final SelenideElement rejectBtn = $(By.xpath("(//*[@mattooltip='Reject'])[1]"));

    public static final SelenideElement addUSB = $(By.xpath("//*[text()=' Add/Manage USB']"));

    public static final SelenideElement pid = $(By.xpath("//*[@formcontrolname='pid']"));

    public static final SelenideElement vid = $(By.xpath("//*[@formcontrolname='vid']"));

    public static final SelenideElement officeLocation = $(By.xpath("//*[@id='officeLocation']"));

    public static final SelenideElement remarksNodal  = $(By.xpath("//*[@id='remarks']"));

    public static final SelenideElement createBtn = $(By.xpath("//*[text()=' Create ']"));

    public static final SelenideElement terminalTable = $(By.xpath("//*[@id='table_hide']"));

    public static final SelenideElement manageUSBUA = $(By.xpath("//*[text()=' Manage USB ']"));

    public static final SelenideElement addUSBUA = $(By.xpath("//*[text()=' Add/Manage USB']//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement approvalRemark = $(By.xpath("//*[@formcontrolname='remarks']"));

    public static final SelenideElement yesBtn =$(By.xpath("//*[text()='Yes']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement searchFeild = $(By.xpath("//*[@placeholder='Search']"));










}
