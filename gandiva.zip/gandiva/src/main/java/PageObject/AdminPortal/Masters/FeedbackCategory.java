/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.Masters;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class FeedbackCategory extends Admin_dashboard {

    public static final SelenideElement feedbackSearch = $(By.xpath("//*[@placeholder='Search ...']"));
    public static final SelenideElement  FeedbackCategoryTitle  = $(By.xpath("//a[contains(text(),'Feedback Category')]"));
    public static final SelenideElement  Add_New_Feedback_Category  = $(By.xpath("//span[contains(text(),'Add Feedback Category')]"));
    public static final SelenideElement  Filters  = $(By.xpath("//button[@type='button' and @ng-reflect-message='Filters']"));
    public static final SelenideElement  Notification  = $(By.xpath("//div[@ng-reflect-message='Notification']"));
    public static final SelenideElement  New_Feedback_Category_Title  = $(By.xpath("//h2[contains(text(),'Add Feedback Category')]"));
    public static final SelenideElement  CategoryName  = $(By.xpath("//input[@formcontrolname='feedbackCateName']"));
    public static final SelenideElement  CategoryDescription  = $(By.xpath("//input[@formcontrolname='feedbackCateDes']"));
    public static final SelenideElement  Submit_Button  = $(By.xpath("//button[@type='submit']"));
    public static final SelenideElement  Cancel_Button  = $(By.xpath("//button[@type='button']//span[contains(text(),'Cancel')]"));

    public static final SelenideElement feedbackSubCat = $(By.xpath("//*[@formcontrolname='feedbackSubCatname']"));

    public static final SelenideElement feedbackSubCatDes = $(By.xpath("  //*[@formcontrolname='feedbSubCatdescription']"));

    public static final SelenideElement feedbackCatSubmit = $(By.xpath("(//*[text()='Submit'])[1]"));
    public static final SelenideElement feedbackSubCatSubmit = $(By.xpath("(//*[text()='Submit'])[2]"));


    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final tableImpl FeedbackCategoryTable = new tableImpl($(By.xpath("//table[@id='table_hide' and @role='table' and @ng-reflect-data-source='[object Object]']")).should(Condition.appear));



}
