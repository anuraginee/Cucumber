package PageObject.AdminPortal.Masters;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class POAPIConfiguration {

    public static final SelenideElement POAPISummaryTab = $(By.xpath("//*[text()='PO API Summary']"));

    public static final SelenideElement POAPIConfigurationTab = $(By.xpath("(//*[text()='PO API Configuration'])[2]"));

    public static final SelenideElement AddPOAPISummaryBtn = $(By.xpath("//*[@class='mat-button-wrapper'][text()='Add PO API Summary']"));
    public static final SelenideElement AddPOAPIConfigurationBtn = $(By.xpath("//*[@class='mat-button-wrapper'][text()='Add PO API Configuration']"));

    public static final SelenideElement selectPO = $(By.xpath("//*[@formcontrolname='orgIdPo']"));

    public static final ElementsCollection poList = $$(By.xpath("//span[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement apiURL = $(By.xpath("//*[@formcontrolname='apiUrl']"));

    public static final SelenideElement apiKey = $(By.xpath("//*[@formcontrolname='udckey']"));

    public static final SelenideElement apiValue = $(By.xpath("//*[@formcontrolname='udcvalue']"));

    public static final SelenideElement apiURLMethod = $(By.xpath("//*[@formcontrolname='apiUrlMethod']"));

    public static final SelenideElement apiLabel = $(By.xpath("//*[@formcontrolname='apiLabel']"));

    public static final SelenideElement headerReqParam = $(By.xpath("//*[@formcontrolname='headerReqParam']"));
    public static final SelenideElement headerResParam = $(By.xpath("//*[@formcontrolname='headerResParam']"));

    public static final SelenideElement apiService = $(By.xpath("//*[@formcontrolname='apiServiceType']"));

    public static final ElementsCollection apiServiceList = $$(By.xpath("//span[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement poAPI = $(By.xpath("//*[@formcontrolname='apiTypeIdList']"));

    public static final ElementsCollection POApiList = $$(By.xpath("//span[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement reqParamWithURL =$(By.xpath("//*[@formcontrolname='requestParamWithUrl']"));



    public static final SelenideElement submit = $(By.xpath("//*[text()='Submit']"));





}
