package PageObject.AdminPortal.Masters;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class ManageInputType {

    public static final SelenideElement addInputTypeBtn = $(By.xpath("//*[text()='Add Input Type ']"));

    public static final SelenideElement inputType =$(By.xpath("//*[@ng-reflect-name='inputType']"));

// Anuraginee: Changed teh Xpath for Submit button
    public static final SelenideElement submitInputType = $(By.xpath("//*[text()='Submit']"));

    public static final SelenideElement searchInputType = $(By.xpath("//*[@placeholder='Search ...']"));

    public static final ElementsCollection inputTypeList = $$(By.xpath("//*[@id='pdfTable']//tbody//tr/td[1]"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));
}
