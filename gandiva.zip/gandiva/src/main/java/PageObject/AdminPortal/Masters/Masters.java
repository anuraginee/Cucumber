/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.Masters;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Masters extends Admin_dashboard {
    public static final SelenideElement masters = $(By.xpath("//mat-sidenav-container//span[text()=\"Masters\"]"));
    public static final SelenideElement Manage_Input_Type = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Manage Input Type')]"));
    public static final SelenideElement Parameter_Validation = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Parameter Validation')]"));
    public static final SelenideElement PO_API_Configuration = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'PO API Configuration')]"));
    public static final SelenideElement Request_Response_Type = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Request/Response Type')]"));
    public static final SelenideElement Notification_Event = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Notification Event')]"));
    public static final SelenideElement Notification_Mode = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Notification Mode')]"));
    public static final SelenideElement Notification_Recipient = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Notification Recipient')]"));
    public static final SelenideElement Feedback_Type = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Feedback Type')]"));
    public static final SelenideElement Feedback_Category = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Feedback Category')]"));
    public static final SelenideElement Feedback_Sub_Module = $(By.xpath("//span[contains(@class,'vex-sidenav-item__label') and contains(text(),'Feedback Sub Module')]"));
   // public static final SelenideElement Manage_Terminal = $(By.xpath("//span[contains(@class,'item-label') and contains(text(),'Manage Terminal')]"));

}
