package PageObject.AdminPortal.Masters;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class RequestResponseType {

    public static final SelenideElement searchInputType = $(By.xpath("//*[@placeholder='Search ...']"));

    public static final ElementsCollection reqResList = $$(By.xpath("//*[@id='table_hide']//tbody//tr//td[1]"));
    public static final SelenideElement addReqResButton = $(By.xpath("//*[text()='Add Request / Response Type']"));

    public static final SelenideElement reqResName = $(By.xpath("//*[@ng-reflect-name='apiReqResTypeName']"));

    public static final SelenideElement reqResSubmit = $(By.xpath("//*[text()='SUBMIT' or text()='Submit']"));
    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));


}
