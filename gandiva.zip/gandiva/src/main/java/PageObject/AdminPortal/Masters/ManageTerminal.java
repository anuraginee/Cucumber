package PageObject.AdminPortal.Masters;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class ManageTerminal {

    public static final SelenideElement searchInputType = $(By.xpath("//*[@placeholder='Search']"));

    public static final ElementsCollection macIdList =$$(By.xpath("//*[@id='table_hide']//tbody//tr//td[3]"));
    public static final SelenideElement addManageTerminal = $(By.xpath("//*[text()='Add Manage Terminal ']"));

    public static final SelenideElement selectUaCategory = $(By.xpath("(//*[@id='selectSources'])[1]"));
    public static final ElementsCollection uaCategoryList =$$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement selectUA = $(By.xpath("(//*[@id='selectSources'])[2]"));

    public static final ElementsCollection uaList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement macAddress = $(By.xpath("//*[@formcontrolname='macaddress']"));

    public static final SelenideElement manageFlag = $(By.xpath("//*[@ng-reflect-form-control-name='flag']"));

    public static final ElementsCollection manageFlagList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement trustedFlag = $(By.xpath("//*[@ng-reflect-form-control-name='isTrustedFlag']"));

    public static final SelenideElement manageTerminalSubmit = $(By.xpath("//*[text()='SUBMIT' or text()='Submit']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

}
