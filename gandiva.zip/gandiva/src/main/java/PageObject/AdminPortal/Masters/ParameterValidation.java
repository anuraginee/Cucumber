package PageObject.AdminPortal.Masters;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class ParameterValidation {

    public static final SelenideElement searchInputType = $(By.xpath("//*[@placeholder='Search ...']"));

    public static final List<SelenideElement> parametersList = $$(By.xpath("//*[@id='table_hide']//tbody//tr//td[1]"));
    public static final SelenideElement addParameterValidation = $(By.xpath("//*[text()='Add Parameter Validation']"));

    public static final SelenideElement validationName =$(By.xpath("//*[@ng-reflect-name='validationName']"));

    public static final SelenideElement valiationErrMsg = $(By.xpath("//*[@ng-reflect-name='validationErrorMsg']"));

    public static final SelenideElement validationRegex = $(By.xpath("//*[@ng-reflect-name='validationRegex']"));

    public static final SelenideElement valParamSubmit = $(By.xpath("//*[text()='SUBMIT' or text()='Submit']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));



    
}
