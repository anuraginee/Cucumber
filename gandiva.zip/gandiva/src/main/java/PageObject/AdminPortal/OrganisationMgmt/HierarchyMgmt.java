package PageObject.AdminPortal.OrganisationMgmt;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class HierarchyMgmt {

    public static final SelenideElement addMoreLevel = $(By.xpath("//*[text()='Add more levels']"));

    public static final ElementsCollection roleIDList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

  public static final SelenideElement roleId = $(By.xpath("//*[@ng-reflect-name='roleId']"));

    public static final ElementsCollection rankList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement blankClick = $(By.xpath("(//*[@class='mat-dialog-content'])[1]"));

   public static final SelenideElement rankID = $(By.xpath("//*[@formcontrolname='roleRankName']"));

    public static final SelenideElement isNodalToggle = $(By.xpath("(//*[@formcontrolname='isNodal'])[4]"));

    public static final SelenideElement poIsNodalToggle = $(By.xpath("(//*[@formcontrolname='isNodal'])[1]"));

    public static final SelenideElement orgMgmtSubmit = $(By.xpath("(//*[text()='Submit'])[2]"));

    //*[text()='Submit']




}
