/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.OrganisationMgmt;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 *
 */
@Component
public class OrganisationMgmt extends CommonElements {
    //    public static final SelenideElement Modify = $(By.xpath("//div//button[@ng-reflect-message='Modify']"));

//    public static final SelenideElement Modify = $(By.xpath("//*[@id=\"table_hideActDeac\"]/tbody/tr[2]/td[7]/div/div[1]/button"));

    public static final tableImpl org_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hideActDeac']")).should(Condition.appear));

    public static final SelenideElement enrollOrgBtn = $(By.xpath("//*[text()=' Enroll Organization ']"));

    public static final SelenideElement enrollOrgWindowPopUp = $(By.xpath("//div[@class='mat-mdc-dialog-surface mdc-dialog__surface']"));

    public static final ElementsCollection orgTypeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement orgType = $(By.xpath("//*[@ng-reflect-name='orgTypeId']"));

    public static final SelenideElement orgName = $(By.xpath("//*[@ng-reflect-name='orgName']"));

    public static final SelenideElement alias = $(By.xpath("//*[@ng-reflect-name='orgAlias']"));

    public static final SelenideElement selectPortal = $(By.xpath("//*[@formcontrolname='orgPortalList']"));

    public static final ElementsCollection portalList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

   public static final SelenideElement orgAddress = $(By.xpath("//*[@formcontrolname='orgAddr']"));

   public static final ElementsCollection agencyTypeList = $$(By.xpath("//*[@class='mat-button-toggle-label-content']"));

   public static final SelenideElement central = $(By.xpath("//*[text()='Central']//parent::button"));

  // public static final SelenideElement centralAgency = $(By.xpath("((//*[@class='mat-button-toggle-focus-overlay'])[2]"));

   public static final SelenideElement stateAgency = $(By.xpath("//*[text()='State']"));

   public static final SelenideElement orgMgmtSubmit = $(By.xpath("//*[@class='flex flex-row justify-between']/descendant::button[@type='submit']"));

}
