package PageObject.AdminPortal.OrganisationMgmt;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class MenuMapping {


    public static final SelenideElement DesignatedOfficer = $(By.xpath("(//*[text()='DESIGNATED OFFICER'])[3]"));
    public static final SelenideElement ApprovingOfficer = $(By.xpath("(//*[text()='APPROVING OFFICER'])[3]"));
    public static final SelenideElement SupervisoryOfficer = $(By.xpath("(//*[text()='SUPERVISORY OFFICER'])[3]"));

    public static final SelenideElement NodalOfficer = $(By.xpath("(//*[text()='NODAL OFFICER'])[3]"));

    public static final SelenideElement AuthorizedOfficer = $(By.xpath("(//*[text()='AUTHORIZED OFFICER'])[3]"));

    public static final SelenideElement GandivaPortal = $(By.xpath("//*[text()='GANDIVA']"));

    public static final SelenideElement SudarshanPortal = $(By.xpath("//*[text()='SUDARSHAN']"));

    public static final SelenideElement MenuMappingSubmit = $(By.xpath("(//*[text()='Submit'])[3]"));

    public static final ElementsCollection menuAndPermissions =  $$(By.xpath("//*[@class='mat-checkbox-label']"));






}
