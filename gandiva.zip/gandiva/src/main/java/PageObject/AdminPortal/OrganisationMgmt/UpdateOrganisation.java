/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 18-07-2023
*/

package PageObject.AdminPortal.OrganisationMgmt;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 *  UpdateOrganisation
 */
@Component
public class UpdateOrganisation extends CommonElements {
    // Common Elements
    public static final SelenideElement btn_Cancel = $(By.xpath("//div//span[@class='mat-button-wrapper' and text()=\"CANCEL\"]"));
    public static final SelenideElement btn_Update = $(By.xpath("(//*[text()='Update'])[1]"));
//    public static final SelenideEleme btn_Update2 = (SelenideElement) $$(By.xpath("//form//div//button[@type='submit']//span[text()=\"UPDATE\"]"));
    public static final ElementsCollection btn_Update2 = $$(By.xpath("(//*[text()='Update'])[2]"));

    //1. Basic Details

    //2. Hierarchy Management & Rights
    public static final SelenideElement label_Hierarchy_mgmt = $(By.xpath("//div//mat-step-header//div//div[text()='Hierarchy Management & Rights']"));


    //3. Menu Mapping Permissions

    public static final SelenideElement btn_DESIGNATED_OFFICER = $(By.xpath("//div//div[@ng-reflect-ng-class='[object Object]' and text()=\"DESIGNATED OFFICER\"]"));
    public static final SelenideElement btn_APPROVING_OFFICER = $(By.xpath("//div//div[text()=\"APPROVING OFFICER\"]"));
    public static final SelenideElement btn_SUPERVISORY_OFFICER = $(By.xpath("//div//div[@ng-reflect-ng-class='[object Object]' and text()=\"SUPERVISORY OFFICER\"]"));
    public static final SelenideElement btn_NODAL_OFFICER = $(By.xpath("//div//div[text()=\"NODAL OFFICER\"]"));
    public static final SelenideElement btn_AUTHORIZED_OFFICER = $(By.xpath("//div//div[@ng-reflect-ng-class='[object Object]' and text()=\"AUTHORIZED OFFICER\"]"));


    /**
     * @param officerRole
     */
    // Method to dynamically click on Any Officer (Button)
    public void clickOnOfficerRank(String officerRole) {
        SelenideElement btn_XXX_OFFICER = $(By.xpath("//div//div[@ng-reflect-ng-class='[object Object]' and text()=" + "'" + officerRole + "']"));//
        btn_XXX_OFFICER.click();
    }

}
