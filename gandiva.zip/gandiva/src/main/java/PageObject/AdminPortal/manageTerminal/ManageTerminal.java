package PageObject.AdminPortal.manageTerminal;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class ManageTerminal {

    public static final SelenideElement manageTerminalMenu = $(By.xpath("//*[text()='Manage Terminal - Admin']"));

    public static final SelenideElement approveTerminal =$(By.xpath("//*[text()='Approve Terminal']"));

    public static final SelenideElement registerTerminal = $(By.xpath("//*[text()='Register Terminal']"));

    public static final SelenideElement terminalTable = $(By.xpath("//*[@id='table_hide']"));

    public static final SelenideElement existingTerminal = $(By.xpath("//*[text()='Existing Terminals']"));


    public static final SelenideElement addManageTerminal = $(By.xpath("//*[text()='Add/Manage Terminal']//following-sibling::span[@class='mat-mdc-focus-indicator']"));

    public static final SelenideElement ipAddress = $(By.xpath("//*[@formcontrolname='htIpAddress']"));

    public static final SelenideElement macAddress = $(By.xpath("//*[@formcontrolname='htMacAddress']"));

    public static final SelenideElement officeLocation = $(By.xpath("//*[@id='officeLocation']"));

    public static final SelenideElement remarksManageTerminal  = $(By.xpath("//*[@id='remarks']"));

    public static final SelenideElement createbtn = $(By.xpath("//*[text()=' Create ']"));

    public static final SelenideElement searchField = $(By.xpath("//*[@type='search']"));

    public static final SelenideElement approveBtn = $(By.xpath("(//*[@mattooltip='Approve'])[1]"));

    public static final SelenideElement rejectBtn = $(By.xpath("(//*[@mattooltip='Reject'])[1]"));

    public static final SelenideElement approvalRemark = $(By.xpath("//*[@formcontrolname='remarks']"));

    public static final SelenideElement yesBtn =$(By.xpath("//*[text()='Yes']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement addMangeTerminalAdmin = $(By.xpath("//*[text()='Add/Manage Terminal ']"));

    public static final SelenideElement selectUACategory = $(By.xpath("(//*[@id='selectSources'])[1]"));

    public static final SelenideElement selectUA = $(By.xpath("(//*[@id='selectSources'])[2]"));

    public static final SelenideElement officeLocationAdmin = $(By.xpath("//*[@formcontrolname='officeLocation']"));


    public static final SelenideElement remarksRegisterTerminal = $(By.xpath("//*[@formcontrolname='remarks']"));


    public static final SelenideElement submit = $(By.xpath("//*[text()='Submit']"));

    public static final ElementsCollection elementList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));





}
