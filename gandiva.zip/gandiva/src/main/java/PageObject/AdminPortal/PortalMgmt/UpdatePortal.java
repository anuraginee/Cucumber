/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 26-09-2023
*/

package PageObject.AdminPortal.PortalMgmt;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class UpdatePortal {

    public static final SelenideElement portalAliasField = $(By.xpath("//*[@ng-reflect-name='portalAlias']"));
    public static final SelenideElement portalDescriptionField = $(By.xpath("//*[@ng-reflect-name='portalDesc']"));
    public static final SelenideElement portalUpdateBtn = $(By.xpath("//*[text()='UPDATE']"));
    public static final SelenideElement portalToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));
    public static final ElementsCollection menuAndPermissions =  $$(By.xpath("//*[@class='mat-checkbox-label']"));
}
