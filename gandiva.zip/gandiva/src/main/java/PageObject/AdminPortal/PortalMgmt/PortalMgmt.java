/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 18-07-2023
*/

package PageObject.AdminPortal.PortalMgmt;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class PortalMgmt {
    public static final SelenideElement portalMgmt_btn = $(By.xpath("//*[text()='Portal Management']"));

    public static final SelenideElement PO_btn_Update = $(By.xpath("//*[text()=' PO Portal ']/..//following-sibling::td/button"));

    public static final SelenideElement Gandiva_btn_Update = $(By.xpath("//*[text()=' GANDIVA ']/..//following-sibling::td/button"));

    public static final SelenideElement Sudarshan_btn_Update = $(By.xpath(" //*[text()=' SUDARSHAN ']/..//following-sibling::td/button"));

  //  public static final SelenideElement portalAliasField = $(By.xpath("//*[@formcontrolname='portalAlias']"));
   // public static final SelenideElement portalDescriptionField = $(By.xpath("//*[@formcontrolname='portalDesc']"));

    public static final SelenideElement aliasField = $(By.xpath("//*[@formcontrolname='portalAlias']"));
    public static final SelenideElement descriptionField = $(By.xpath("//*[@ng-reflect-name='portalDesc']"));

//    Anuraginee: Updating the Xpath for Update button
    public static final SelenideElement portalUpdateBtn = $(By.xpath("//*[text()='Update']"));
    public static final SelenideElement portalToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final ElementsCollection menuAndPermissions =  $$(By.xpath("//*[@class='mdc-label']"));

    public static final tableImpl portal_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hide']")).should(Condition.appear));

    public  static final SelenideElement btn_Update = $(By.xpath("//*[text()='Update']"));




}
