package PageObject.AdminPortal.UserManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Sleeper;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class Users {

    public  static  final SelenideElement addNodalOfficer = $(By.xpath("(//*[text()='Add Nodal Officer'])[1]"));
    public static final SelenideElement nodalName = $(By.xpath("//*[@formcontrolname='userName']"));

    public static final SelenideElement nodalEmailId = $(By.xpath("//*[@formcontrolname='emailId']"));

    public static final SelenideElement nodalContactNo = $(By.xpath("//*[@formcontrolname='contactNo']"));

    public static final SelenideElement nodalAddress = $(By.xpath("//*[@formcontrolname='address']"));

    public static final SelenideElement nodalUpdate = $(By.xpath("//*[text()='Update']"));

    public  static final SelenideElement nodalLoginID = $(By.xpath("//*[@formcontrolname='loginId']"));
    public static final SelenideElement nodalOrgType = $(By.xpath("//*[@formcontrolname='orgTypeId']"));

    public static final ElementsCollection nodalOrgTypeList = $$(By.xpath("//*[@class='mat-option-text']"));
    public static final SelenideElement nodalOrgName  =  $(By.xpath("//*[@formcontrolname='orgId']"));

   public static final ElementsCollection nodalOrgNameList = $$(By.xpath("//*[@class='mat-option-text']"));

   public static final SelenideElement nodalSubmit = $(By.xpath("//*[text()='Submit']"));

   public static final SelenideElement addAdminUser = $(By.xpath("(//*[text()='Add Admin User'])[1]"));

   public static final SelenideElement nodalPortal = $(By.xpath("//*[@formcontrolname='portalId']"));

   public static final SelenideElement gandivaPortal = $(By.xpath("//*[@class='mat-option-text']"));


    public static final SelenideElement rankId = $(By.xpath("//*[@formcontrolname='rankId']"));

    public static final SelenideElement nodalRank = $(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final tableImpl admin_user_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hideAdminUser']")).should(Condition.appear));

}
