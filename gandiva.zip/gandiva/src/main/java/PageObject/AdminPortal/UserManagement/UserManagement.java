/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.UserManagement;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class UserManagement extends CommonElements {
    public static final SelenideElement bar_UserManagement= $(By.xpath("//*[text()='User Management']"));
    public static final SelenideElement bar_UserManagement_Users= $(By.xpath("//*[text()='Users']"));

    public  static  final SelenideElement addNodalOfficer = $(By.xpath("//*[@ng-reflect-message='Add Nodal Officer']"));
    public static final SelenideElement nodalName = $(By.xpath("//*[@formcontrolname='userName']"));

    public static final SelenideElement nodalEmailId = $(By.xpath("//*[@formcontrolname='emailId']"));

    public static final SelenideElement nodalContactNo = $(By.xpath("//*[@formcontrolname='contactNo']"));

    public static final SelenideElement nodalAddress = $(By.xpath("//*[@formcontrolname='address']"));

    public static final SelenideElement nodalUpdate = $(By.xpath("//*[text()='Update']"));

    public  static final SelenideElement nodalLoginID = $(By.xpath("//*[@formcontrolname='loginId']"));
    public static final SelenideElement nodalOrgType = $(By.xpath("//*[@formcontrolname='orgTypeId']"));

    public static final ElementsCollection nodalOrgTypeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));
    public static final SelenideElement nodalOrgName  =  $(By.xpath("//*[@formcontrolname='orgId']"));

    public static final ElementsCollection nodalOrgNameList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement nodalSubmit = $(By.xpath("//*[text()='Submit']"));

    public static final SelenideElement addAdminUser = $(By.xpath("(//*[text()='Add Admin User'])[1]"));

    public static final SelenideElement nodalPortal = $(By.xpath("//*[@formcontrolname='portalId']"));

    public static final SelenideElement gandivaPortal = $(By.xpath("//*[@class='mdc-list-item__primary-text']"));


    public static final SelenideElement rankId = $(By.xpath("//*[@formcontrolname='rankId']"));

    public static final SelenideElement nodalRank = $(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement unblockUsers= $(By.xpath("//mat-sidenav-container//span[text()=\"Unblock Users\"]"));
    public static final SelenideElement password_Reset_Requests= $(By.xpath("//mat-sidenav-container//span[text()=\"Password Reset Requests\"]"));

    public static final tableImpl user_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hideActDec']")).should(Condition.appear));

}
