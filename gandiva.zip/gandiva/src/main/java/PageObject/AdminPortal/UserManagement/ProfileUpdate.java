package PageObject.AdminPortal.UserManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class ProfileUpdate {


   public static final SelenideElement nodalOfficer = $(By.xpath("//*[text()='NODAL OFFICER']"));

   public static final SelenideElement profileMenu = $(By.xpath("(//*[@role='menuitem'])[2]"));

   public static final SelenideElement editProfile = $(By.xpath("//*[text()='Edit Proﬁle']"));

   public static final SelenideElement emailIDField = $(By.xpath("//*[@id='emailId']"));

   public static final SelenideElement mobileField = $(By.xpath("//*[@id='mobile']"));

   public static final SelenideElement profileUpdateRemark = $(By.xpath("//*[@id='profileUpdateRemarks']"));

   public static final  SelenideElement profileUpdateButton = $(By.xpath("//*[text()=' Update ']//parent::button"));

   public static final SelenideElement confirmationYes = $(By.xpath("//*[text()=' Yes ']//parent::button"));

    public static final SelenideElement signoutMenu = $(By.xpath("(//*[@role='menuitem'])[3]"));

    public static final SelenideElement approveButton  = $(By.xpath("//*[text()=' Approve ']"));

    public static final SelenideElement searchField = $(By.xpath("//*[@type='text']"));

   public static final SelenideElement rejectButton  = $(By.xpath("//*[text()=' Reject ']"));

   public static final SelenideElement confirmationAdminYes =$(By.xpath("//*[text()='Yes']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));



}
