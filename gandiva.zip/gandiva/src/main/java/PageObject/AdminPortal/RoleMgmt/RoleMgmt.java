/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 20-08-2023
*/
package PageObject.AdminPortal.RoleMgmt;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Sleeper;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class RoleMgmt {

    public static final SelenideElement btn_RoleManagement = $(By.xpath("//span[text()='Role Management']"));
    public static final SelenideElement btn_AddRole = $(By.xpath("//span[text()=' Add Role ']"));

    public static final SelenideElement field_Search = $(By.xpath("//input[@type='text']"));
    public static final SelenideElement icon_Update = $(By.xpath("//button[@role='menuitem']"));
   public static final SelenideElement field_OrgType = $(By.xpath("//*[@formcontrolname='organizationTypeIdList']"));

   // public static final SelenideElement field_OrgType = $(By.xpath("//*[text()='Organization Type']"));

    public static final ElementsCollection orgTypeList = $$(By.xpath("//*[@class='mdc-list-item__primary-text']"));
    public static final SelenideElement field_RoleName = $(By.xpath("//*[@ng-reflect-name='roleName']"));

    public static final SelenideElement drop_RoleLevel = $(By.xpath("//*[@formcontrolname='roleLevelTypeIdList']"));

    public static final ElementsCollection roleLevelList =$$(By.xpath("//*[@class='mdc-list-item__primary-text']"));

    public static final SelenideElement field_RoleAlias = $(By.xpath("//input[@ng-reflect-name='roleAlias']"));

    public static final SelenideElement field_RoleDescription = $(By.xpath("//*[@ng-reflect-name='roleDesc']"));

    public static final SelenideElement proceedBtn =  $(By.xpath("//*[text()='Proceed']"));

    public static final SelenideElement btn_Update = $(By.xpath("//*[text()='Update ']"));


    public static final SelenideElement toastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement adminLoginTab = $(By.xpath("//*[text()='ADMIN']"));

    public static final SelenideElement adminLogout = $(By.xpath("//*[text()='Logout']"));
    public static final SelenideElement btn_Submit = $(By.xpath("//*[text()='Submit']"));

    public static final tableImpl role_Mgmt_table = new tableImpl($(By.xpath("//table[@id='table_hide']")).should(Condition.appear));



}
