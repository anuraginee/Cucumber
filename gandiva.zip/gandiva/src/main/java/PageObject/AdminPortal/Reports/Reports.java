/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.AdminPortal.Reports;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Reports extends Admin_dashboard {
    public static final SelenideElement reports = $(By.xpath("//mat-sidenav-container//span[text()=\"Reports\"]"));
    public static final SelenideElement user_Agency_Wise_Request_Response_Summary = $(By.xpath("//*[text()='UA Wise Request Response Summary']"));
    public static final SelenideElement po_Wise_Request_Response = $(By.xpath("//span[text()='PO Wise Request Response Summary']"));
    public static final SelenideElement previous_Month_Request_Response_Summary = $(By.xpath("//span[text()='Previous Month Request Summary']"));
    public static final SelenideElement total_Request_Response_Summary = $(By.xpath("//span[text()='Total Request Response Summary']"));
    public static final SelenideElement category_Wise_Request_Summary = $(By.xpath("//span[text()='Category Wise Request Summary']"));
    public static final SelenideElement admin_Approval_Request_Summary = $(By.xpath("//span[text()='Admin Approval Request Summary']"));
    public static final SelenideElement ua_Wise_Query_Executed = $(By.xpath("//span[text()='UA Wise Query Executed']"));
    public static final SelenideElement use_Case_Query_Executed = $(By.xpath("//span[text()='Use Case Query Executed']"));
    public static final SelenideElement user_Agency_Wise_Day_Wise_Request_Response_Summary = $(By.xpath("//span[text()='UA Wise Day Wise Request Response Summary']"));
   // public static final SelenideElement po_Wise_DayWise_Request_Response_Summary = $(By.xpath("//span[contains(@class,'item-label') and contains(text(),'PO Wise Day Wise Request Response Summary')]"));
    public static final SelenideElement po_Wise_Request_Response_Summary = $(By.xpath("(//span[text()='PO Wise Request Response Summary'])[2]"));

    public static final SelenideElement day_Wise_Request_Response_Summary = $(By.xpath("//span[text()='Day Wise Request Response Summary']"));
    public static final SelenideElement user_Wise_High_Query_Count = $(By.xpath("//span[text()='User Wise High Query Count']"));
    public static final SelenideElement ua_Wise_Month_Wise = $(By.xpath("//span[text()='UA Wise Month Wise']"));
    public static final SelenideElement ua_Wise_Data_Sharing = $(By.xpath("//span[text()='UA Wise Data Sharing']"));
    public static final SelenideElement po_Wise_Month_Wise = $(By.xpath("//span[text()='PO Wise Month Wise']"));
    public static final SelenideElement ua_Wise_Case_Statistics = $(By.xpath("//span[text()='UA Wise Use Case Statistics']"));
    public static final SelenideElement un_responded = $(By.xpath("//span[text()='Unresponded']"));
    public static final SelenideElement migration_Status = $(By.xpath("//*[text()='Migration Status']"));

    public static final SelenideElement  Day_Wise_ER_Request_Summary  =$(By.xpath("//*[text()='Day Wise ER Request Summary']"));

    public static final SelenideElement  UA_Wise_Role_Wise_User_Details  =$(By.xpath("//*[text()='UA Wise Role Wise User Details']"));

    public static final SelenideElement  UA_Wise_PO_Wise_Failed_Query_Statistics  =$(By.xpath("//*[text()='UA Wise PO Wise Failed Query Statistics']"));

    public static final SelenideElement  Use_Case_Master  =$(By.xpath("(//*[text()='Use Case Master'])[1]"));

    public static final SelenideElement useCaseMasterTab = $(By.xpath("(//*[text()='Use Case Master'])[2]"));


    public static final SelenideElement  Use_Case_Mapping_UA_Wise  =$(By.xpath("//*[text()='Use Case Map']"));

    public static final SelenideElement xlxsReport = $(By.xpath("//*[@mattooltip='Download xlxs']"));

    public static final SelenideElement pdfReport = $(By.xpath("//*[@mattooltip='Download pdf']"));

    public static final SelenideElement userPassword = $(By.xpath("//*[@formcontrolname='confirmpassword']"));


    public static final SelenideElement saveBtn = $(By.xpath("//*[text()='save']"));
    public static final SelenideElement saveBtnPdf = $(By.xpath("//*[text()='Save']"));
    public static final SelenideElement SaveBtn_Admin = $(By.xpath("//*[text()='Save']//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));


    public static final SelenideElement submitBtn =$(By.xpath("(//*[text()='Submit'])[1]"));

    public static final SelenideElement reportSubmit = $(By.xpath("//*[text()=' Submit ']/..//preceding-sibling::span"));



}
