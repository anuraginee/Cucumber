package PageObject.AdminPortal;


import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class AdminFeedback {

    public static final SelenideElement Feedback_Title = $(By.xpath("//*[contains(text(),'Feedback')]"));

    public static final tableImpl AdminFeedbackTable = new tableImpl($(By.xpath("//table[contains(@class,'mat-mdc-table') and @role='table' and @ng-reflect-data-source='[object Object]']")));
    public static final SelenideElement Chat_History_Heading = $(By.xpath("//h2[text()='Chat History']"));
    public static final SelenideElement Close_Issue = $(By.xpath("//button[contains(@class,'close-btn')]//span[contains(text(),'Close Issue')]"));
    public static final SelenideElement Input_Text_Box = $(By.xpath("//input[@placeholder='Type a message...' and @formcontrolname='message']"));
    public static final SelenideElement Chat_Close_Button = $(By.xpath("//button[text()=' Close Issue']"));
    public static final SelenideElement Chat_Close_Confirmation_Title = $(By.xpath("//*[text()='Confirmation Request']"));
    public static final SelenideElement Proceed_Button = $(By.xpath("//button[@type=\"submit\"]//span[text()='Proceed']"));

    public static final SelenideElement Text_Submit_Button = $(By.xpath("//button[@type='submit']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("(//button[@type='button']//mat-icon[@data-mat-icon-name=\"close\"])[2]"));


    //    Download Chat
    public static final SelenideElement Download_Chat = $(By.xpath("//form[contains(@class,'ng-untouched') and @ng-reflect-form=\"[object Object]\"]//mat-icon[@role=\"img\" and contains(@class,'cursor-pointer')]"));
    public static final SelenideElement Submit_Button = $(By.xpath("//button[@type='submit']//span[text()='Submit']"));

    //    Created as I am not able to click on Chat button using Table IMP
    public static final SelenideElement New_Chat_Button = $(By.xpath("//table[contains(@class,'mat-table') and @role='table' and @ng-reflect-data-source='[object Object]']//tbody//tr[1]//td[9]/div/div/img[@matbadgesize='small' and @ng-reflect-size='small']"));


}
