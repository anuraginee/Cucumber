package PageObject.AdminPortal.PushNotifications;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class PushNotifications {


    public static final SelenideElement allNGITUsers = $(By.xpath("//*[text()='All NG IT Users']"));
    public static final SelenideElement RolesSpecificUA = $(By.xpath("//*[text()='Specific Roles of Specific UA ']"));

    public static final SelenideElement allNodalOfficers = $(By.xpath("//*[text()='All UA Nodal Officers ']"));
    public static final SelenideElement UserAgencyCategory = $(By.xpath("//mat-select[@role=\"combobox\" and @id=\"selectSources\"]"));


    public static final SelenideElement UserAgency = $(By.xpath("//*[@type=\"text\" and @placeholder=\"Select User Agency\"]"));


    public static final SelenideElement SelectRole = $(By.xpath("//*[@placeholder='Select Role']"));

    public static final ElementsCollection UACategoryList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final ElementsCollection UAList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final ElementsCollection roleList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement selectOrgId = $(By.xpath("//*[@formcontrolname='orgId']"));

    public static final SelenideElement selectRole = $(By.xpath("//*[@formcontrolname='role']"));

    public static final SelenideElement specificUserMode = $(By.xpath("//*[@formcontrolname='notModeSpecific']"));

    public static final SelenideElement specificUserContent = $(By.xpath("//*[@formcontrolname='notContentSpecific']"));

    public static final SelenideElement specificUserConfigType = $(By.xpath("//*[@formcontrolname='configTypeSpecific']"));
    public static final SelenideElement notificationMode = $(By.xpath("//*[@data-placeholder='Notification Mode']"));

    public static final SelenideElement portalDropdown = $(By.xpath("//*[text()='Portal']"));

    public static final SelenideElement smsDropdown = $(By.xpath("//*[text()='SMS']"));

    public static final SelenideElement notContent = $(By.xpath("//*[@placeholder='Notification Mode']"));
    public static final SelenideElement NotMode = $(By.xpath("//div[contains(@class,'mdc-menu-surface')]"));


    public static final SelenideElement nodalNotContent = $(By.xpath("//*[@ng-reflect-name='notContentNodal']"));

    public static final SelenideElement notMode = $(By.xpath("//*[@formcontrolname='notMode']"));

    public static final SelenideElement nodalNotMode = $(By.xpath("//*[@formcontrolname='notModeNodal']"));
    public static final ElementsCollection modeList = $$(By.xpath("//*[@class='mat-option-text']"));
    public static final SelenideElement Not_Content_Field = $(By.xpath("//textarea[@formcontrolname=\"notContent\"]"));
    public static final SelenideElement Not_Content_Field_Nodal = $(By.xpath("//textarea[@formcontrolname=\"notContentNodal\"]"));
    public static final SelenideElement Not_Content_Field_Specific = $(By.xpath("//textarea[@formcontrolname=\"notContentSpecific\"]"));

    public static final ElementsCollection agencyList = $$(By.xpath("//*[contains(@class,'mat-radio-button')]"));
    public static final SelenideElement send = $(By.xpath("//*[text()=' Send ']"));

    public static final SelenideElement uaNotificationIcon = $(By.xpath("(//*[@class='mat-focus-indicator mat-icon-button mat-button-base'])[2]"));

    public static final ElementsCollection recivedNotification = $$(By.xpath("//div[@class='flex flex-auto py-3 pl-6 ng-star-inserted']/../../../.."));

    public static final SelenideElement firstNotification = $(By.xpath("(//*[@class='cdk-overlay-pane']//div[@class='font-bold ng-star-inserted'])[1]"));

    public static final SelenideElement configType = $(By.xpath("//*[@formcontrolname='configType']"));
    public static final SelenideElement configType_Nodal = $(By.xpath("//*[@formcontrolname='configTypeNodal']"));
    public static final SelenideElement configType_Specific = $(By.xpath("//*[@formcontrolname='configTypeSpecific']"));

    public static final SelenideElement nodalConfigType = $(By.xpath("//*[@formcontrolname='configTypeNodal']"));

    public static final ElementsCollection configList = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement toastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));

    public static final SelenideElement currentDate = $(By.xpath("//*[@class='mat-calendar-body-cell-content mat-focus-indicator mat-calendar-body-today']"));
    public static final SelenideElement Start_Date_calender = $(By.xpath("(//button[@type='button' and @aria-label='Open calendar']//span[contains(@class,'mat-mdc-button-persistent')])[1]"));
    public static final SelenideElement End_Date_calender = $(By.xpath("(//button[@type='button' and @aria-label='Open calendar']//span[contains(@class,'mat-mdc-button-persistent')])[2]"));


    public static final SelenideElement calendarIcon = $(By.xpath("(//*[@class='mat-datepicker-toggle-default-icon ng-star-inserted'])[1]"));

    public static final SelenideElement calendarIcontodate = $(By.xpath("(//*[@class='mat-datepicker-toggle-default-icon ng-star-inserted'])[2]"));

    public static final SelenideElement fromTime = $(By.xpath("//*[@formcontrolname='fromTime']"));

    public static final SelenideElement toTime = $(By.xpath("//*[@formcontrolname='toTime']"));

    public static final SelenideElement fromTimeNodal = $(By.xpath("//*[@formcontrolname='fromTimeNodal']"));

    public static final SelenideElement toTimeNodal = $(By.xpath("//*[@formcontrolname='toTimeNodal']"));


    public static final SelenideElement fromTimeSpecific = $(By.xpath("//*[@formcontrolname='fromTimeSpecific']"));

    public static final SelenideElement toTimeSpecific = $(By.xpath("//*[@formcontrolname='toTimeSpecific']"));


    public static final SelenideElement Notification_Mode(String NotMode) {
        SelenideElement Not_Mode = $(By.xpath("//div[contains(@class,'mdc-menu-surface')]//mat-option[@role='option']//span[contains(text(),'" + NotMode + "')]"));
        return Not_Mode;
    }

    public static final SelenideElement User_Agency_Category(String UACategory) {
        SelenideElement Not_Mode = $(By.xpath("//*[@id='selectSources-panel']//mat-option//span[text()=' " + UACategory + " ']"));
        return Not_Mode;
    }

    public static final SelenideElement Configuration(String Config) {
        SelenideElement Config_Option = $(By.xpath("//div[contains(@class,'mdc-menu-surface')]//mat-option[@role='option']//span[text()='" + Config + "']"));
        return Config_Option;
    }

    public static final SelenideElement Select_User_Role(String UserRole) {
        SelenideElement User_Role = $(By.xpath("//*[@role='option']//span[text()=' " + UserRole + " ']"));
        return User_Role;
    }

    public static final SelenideElement Select_User_Agency(String UserAgency) {
        SelenideElement User_Agency = $(By.xpath("//*[@role='option']//span[text()=' " + UserAgency + " ']"));
        return User_Agency;
    }


    public static void SelectDate(String Day, String Month, String Year) {
        final SelenideElement Calender = $($(By.xpath("//mat-calendar[@ng-reflect-start-view='month']")).should(Condition.appear));
        final SelenideElement Calender_Year = $(By.xpath("//button[@aria-label=\"Choose month and year\"]//span//span"));
        Calender.shouldBe(Condition.visible);
        System.out.println(Calender_Year.getText());
        Calender_Year.click();
        final SelenideElement Calender_year = $(By.xpath("//button[contains(@class,'mat-calendar-body-cell') and @aria-current='date']//span[text()=' " + Year + " ']"));
        Calender_year.click();
        final SelenideElement Calender_month = $(By.xpath("//button[contains(@class,'mat-calendar-body-cell') and @aria-current='date']//span[text()=' " + Month + " ']"));
        Calender_month.click();
        final SelenideElement Calender_date = $(By.xpath("//button[contains(@class,'mat-calendar-body-cell') and @aria-current='date']//span[text()=' " + Day + " ']"));
        Calender_date.click();
    }


}
