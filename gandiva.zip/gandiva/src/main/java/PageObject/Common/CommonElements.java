package PageObject.Common;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.webdriver;

@Component
public class CommonElements {
    public static final SelenideElement search = $(By.xpath("//input[@type='text']"));
    public static final SelenideElement SUBMIT_BUTTON = $(By.xpath("//span[text()=' Submit ']//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//*[contains(text(),'Cancel')]"));
    public static final SelenideElement SPINNER_CIRCLE_ICON = $(By.xpath("//div[2]//mat-spinner//svg//circle"));
    public static final SelenideElement SPINNER_THREE_DOTS_ICON = $(By.xpath("//div//div[@class='spinner']"));
    public static final SelenideElement LogoutText = $(By.xpath("//div[contains(text(),'You have successfully logged out !')]"));
    public static final SelenideElement Notification_Heading = $(By.xpath("//div[text()=' Notification ']"));
    public static final SelenideElement Notification_View_All = $(By.xpath("//button[contains(@class,'mat-icon-button')]//span[text()=' View All ']"));
    public static final SelenideElement popup_Close =$(By.xpath("//form[@id='popup']/div/button"));
    public static final SelenideElement Vertical_Loader =$(By.xpath("//div[@class=\"mat-progress-bar-buffer mat-progress-bar-element\"]"));


}
