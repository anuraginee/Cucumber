package PageObject.Common;

import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class ProfileUpdate {

    public static final SelenideElement My_Profile = $(By.xpath("//div[text()='My Profile']"));

    //    public static final SelenideElement officerName = $(By.xpath("//*[contains(@class,'text-white')][2]"));
    public static final SelenideElement officerName = $(By.xpath("//span[contains(@class,'flex flex-col')]/span[1]"));
    public static final SelenideElement profileIcon = $(By.xpath("//*[text()='Profile']"));

    public static final SelenideElement editProfile = $(By.xpath("//*[text()='Edit Proﬁle']"));

    public static final SelenideElement emailIdField = $(By.xpath("//*[@id='emailId']"));

    public static final SelenideElement mobileField = $(By.xpath("//*[@id='mobile']"));

    public static final SelenideElement profileUpdateRemarksField = $(By.xpath("//*[@id='profileUpdateRemarks']"));

    public static final SelenideElement profileUpdateBtn = $(By.xpath("//*[text()=' Update ']"));

    public static final SelenideElement confirmationBtn = $(By.xpath("//*[text()=' Yes ']"));

    public static final SelenideElement successToastMessage = $(By.xpath("//*[text()='User details updated successfully']"));

    public static final SelenideElement searchField = $(By.xpath("//*[@placeholder='Search']"));

    public static final SelenideElement approveBtn = $(By.xpath("//*[@mattooltip='Approve']"));

    public static final SelenideElement nodalRemark = $(By.xpath("//*[@formcontrolname='remark']"));

    public static final SelenideElement confirmationYes = $(By.xpath("//*[text()='Yes']"));

    public static final SelenideElement successToastMessageNodal = $(By.xpath("//*[text()='Profile update request approved successfully.']"));

    public static final SelenideElement signOut = $(By.xpath("//span[contains(text(),'Sign out')]"));
    public static final SelenideElement LogOut = $(By.xpath("//span[contains(text(),'out')]"));

    //    ADMIN LOgout and Profile Xpaths
//    public static final SelenideElement Admin_ProfileName = $(By.xpath("//span[text()='NATGRIDADMIN']"));
    public static final SelenideElement Admin_ProfileName = $(By.xpath("//span[contains(@class,'flex flex-col')]/span[1]"));

    public static final SelenideElement Admin_LogOut = $(By.xpath("//span[text()='Logout']"));
    public static final SelenideElement Admin_MyProfile = $(By.xpath("//div[text()='My Profile']"));


}

