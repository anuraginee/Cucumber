package PageObject.POPortal;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class POReports {


    public static final SelenideElement SubmitBtn = $(By.xpath("//*[text()=' Submit ']"));
    public static final SelenideElement errorSubmitBtn = $(By.xpath("//*[text()=' Submit']"));

    public static final SelenideElement SPINNER_CIRCLE_ICON = $(By.xpath("//div[2]//mat-spinner//svg//circle"));



}
