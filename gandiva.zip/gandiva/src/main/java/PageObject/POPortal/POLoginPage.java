/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.POPortal;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class POLoginPage {
    public static final SelenideElement usernameField = $(By.id("mat-input-0"));
    public static final SelenideElement passwordField = $(By.id("mat-input-1"));
    public static final SelenideElement poCaptchaField = $(By.className("captcha-text"));
    public static final SelenideElement poCaptchaTextField = $(By.id("mat-input-2"));
    //    public static final SelenideElement signInButton = $(By.xpath("//button//span//span[text()=\" Sign in \"]"));
    public static final SelenideElement verificationCodeTextField = $(By.id("mat-input-3"));
    public static final SelenideElement loginButton = $(By.xpath("//button//span[text()=\" LOGIN \"]"));

    public void poLogin() {
        loginButton.should(Condition.enabled).click();
    }
}