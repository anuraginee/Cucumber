/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.POPortal;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class PO_dashboard {
    public static final SelenideElement PO_icon = $(By.className("relative"));
    // Cart Users
    public static final SelenideElement Dashboard = $(By.xpath("//span[contains(text(),'Dashboard')]"));
    public static final SelenideElement Request_Response = $(By.xpath("//span[contains(.,'Request Response')]"));
    public static final SelenideElement All_Requests = $(By.xpath("//span[contains(.,'All Requests')]"));
    public static final SelenideElement Request_Response_Pending = $(By.xpath("//span[contains(.,'Request Response Pending')]"));
    public static final SelenideElement Reports = $(By.xpath("//span[contains(.,'Reports')]"));
    public static final SelenideElement Reports_UA_Wise_Requests = $(By.xpath("//span[contains(.,'UA Wise Request')]"));
    public static final SelenideElement Reports_UA_Wise_Response_Summary = $(By.xpath("//span[contains(.,'UA Wise Response Summary')]"));
    public static final SelenideElement Reports_Type_of_Requests = $(By.xpath("//span[contains(.,'Type of Requests')]"));
    public static final SelenideElement Reports_Time_Taken_to_Serve_Requests = $(By.xpath("//span[contains(.,'Time Taken To Serve Requests')]"));
    public static final SelenideElement Reports_Error_Report = $(By.xpath("//span[contains(.,'Error Report')]"));

}
