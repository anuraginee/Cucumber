/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.UseCaseApprovals;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class CaseApproval {
    public static final SelenideElement RequestResponseApprovals = $(By.xpath("//span[contains(text(),' Request – Response Approvals ')]"));


    public static final SelenideElement UseCaseQueriesApprovals = $(By.xpath("//div[@class='fuse-vertical-navigation-item-title']//span[contains(text(),' Use Case Queries – Approval ')]"));


    public static final SelenideElement CaseApprove = $(By.xpath("//button[@mattooltip='Approve']/span[@class='mat-button-wrapper']/img[1]"));

    public static final SelenideElement CaseReject = $(By.xpath("//button[@mattooltip='Reject']/span[@class='mat-button-wrapper']/img[1]"));

    public static final SelenideElement CaseView = $(By.xpath("//button[@mattooltip='View']/span[@class='mat-button-wrapper']/img[1]"));
    public static final SelenideElement BacktoListView = $(By.xpath("//span[contains(text(),' Back to List View ')]"));

    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(text(),'Submit')]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));

    public static final SelenideElement Yes_Button = $(By.xpath("//*[text()=' Yes ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));


    public static final SelenideElement Approval_Confirmation_Title = $(By.xpath("//*[text()='Approval Confirmation']"));
    public static final SelenideElement Reject_Confirmation_Title = $(By.xpath("//*[text()='Rejection Confirmation']"));

    public static final SelenideElement RemarksText = $(By.xpath("//textarea[@data-placeholder='Enter Remarks']"));

    public static final SelenideElement ConfirmOk = $(By.xpath("//div[@class='cdk-overlay-pane']//div[contains(@class,'flex justify-end')]//button/span[@class='mat-button-wrapper' and contains(text(),'Ok')]"));


    public static final SelenideElement UseCaseRecommend_Title = $(By.xpath("//h2[text()=' Use Case Queries - Recommendation ']"));


    public static final SelenideElement UseCaseNotRecommend = $(By.xpath("//button[@mattooltip='Not Recommend']/span[@class='mat-button-wrapper']/img[1]"));

    public static final SelenideElement UseCaseQueryRecommendation = $(By.xpath("//div[@class='fuse-vertical-navigation-item-title']/span[contains(text(),' Use Case Queries – Recommendation ')]"));


    public static final SelenideElement SearchRequest = $(By.xpath(" //input[contains(@placeholder,'Search')]"));
    public static final SelenideElement Request_Remarks = $(By.xpath("//*[@id='requesterComments']"));
    public static final SelenideElement Recommend_Request = $(By.xpath("(//table//tbody//tr//td[contains(@class,'cdk-column-caseName')]//div)[1]"));


    public static final SelenideElement Use_Case_Qury_Related_Activity(String Sub_Request_ID, String Query_Activity) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Sub_Request_ID + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-expand')]//mat-icon[@mattooltip='" + Query_Activity + "']"));
        return action;
    }

    public static final SelenideElement Use_Case_Query_Recommendation(String Case_Name) {
        SelenideElement action = $(By.xpath("//*[text()=' " + Case_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//button[@mattooltip='Recommend']"));
        return action;
    }
    public static final SelenideElement Use_Case_Query_Approval(String Case_Name) {
        SelenideElement action = $(By.xpath("//*[text()=' " + Case_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//button[@mattooltip='Approve']"));
        return action;
    }

    public static final SelenideElement Use_Case_Query_Not_Recommended(String Case_Name) {
        SelenideElement action = $(By.xpath("//*[text()=' " + Case_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//button[@mattooltip='Not Recommend']"));
        return action;
    }
    public static final SelenideElement Use_Case_Query_Reject(String Case_Name) {
        SelenideElement action = $(By.xpath("//*[text()=' " + Case_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//button[@mattooltip='Reject']"));
        return action;
    }

}
