/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query_Related_Approval;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Scheduled_Query_Recommendation {
    public static final tableImpl Scheduled_Query_Recommendation_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'w-full')]")).should(Condition.appear));
    public static final SelenideElement Recommendation_Title = $(By.xpath("//h2[text()=' Recommendation ']"));
    public static final SelenideElement Recommend_Scheduled_Query_Record = $(By.xpath("(//table//tbody//tr//td[contains(@class,'mat-column-wlName')]//div)[1]"));
    public static final SelenideElement Yes_Button = $(By.xpath("//span[text()=' Yes ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement Scheduled_Query_Case_Name = $(By.xpath("(//div//div[text()='Case Name ']//parent::div//div)[2]"));
    public static final SelenideElement Expand_View_All = $(By.xpath("(//table//tbody//tr//td[contains(@class,'mat-column-Action')]//button[text()=' View '])[1]"));
    public static final SelenideElement Recommendation_Confirmation_Title = $(By.xpath("//*[text()='Recommendation Confirmation']"));
    public static final SelenideElement Not_Recommendation_Confirmation_Title = $(By.xpath("//*[text()='Not Recommendation Confirmation']"));
    public static final SelenideElement Recommended_Not_Recommended_Requests = $(By.xpath("(//span[@class='mdc-tab__content'])[2]"));
    public static final SelenideElement Back_to_List_View = $(By.xpath("//*[text()=' Back to List View ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));


    public static final SelenideElement getActionButtonByQuery_Name(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//parent::tr//td[contains(@class,'mat-column-action')]//div//button[contains(@class,'mat-primary')]//img[@mattooltip=\"Approve\"]"));
        return action;
    }

    public static final SelenideElement Sch_Qury_Related_Activity(String Query_Name, String Query_Activity) {
        SelenideElement action = $(By.xpath("//*[text()=' " + Query_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-Expand')]//div[@aria-label='expand row']//img[@mattooltip='" + Query_Activity + "']"));
        return action;
    }

    public static final SelenideElement Approved_By_Query_Name(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td[contains(@class,'mat-column-action')]//img[@mattooltip='Approve']"));
        return action;
    }

    public static final SelenideElement Rejected_By_Query_Name(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td[contains(@class,'mat-column-action')]//img[@mattooltip='Reject']"));
        return action;
    }


}
