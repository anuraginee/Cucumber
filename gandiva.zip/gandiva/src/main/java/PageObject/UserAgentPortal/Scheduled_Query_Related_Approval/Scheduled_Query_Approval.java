/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query_Related_Approval;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Scheduled_Query_Approval {
    public static final tableImpl Scheduled_Query_Approval_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'w-full')]")).should(Condition.appear));
    public static final SelenideElement Search_Bar = $(By.xpath("//*[@type=\"search\"]"));
    public static final SelenideElement Approved_Rejected_Scheduled_Queries = $(By.xpath("//*[text()='Approved/Rejected Scheduled Queries']"));
    public static final SelenideElement Scheduled_Query_Name = $(By.xpath("(//div//div[text()='Name ']//parent::div//div)[2]"));
    public static final SelenideElement Scheduled_Query_Case_Name = $(By.xpath("(//div//div[text()='Case Name ']//parent::div//div)[2]"));
    public static final SelenideElement Scheduled_Query_Approval_Title = $(By.xpath("//h2[text()=' Approval ']"));
    public static final SelenideElement Use_Case_Query_Approval_Title = $(By.xpath("//h2[text()=' Use Case Queries - Approval ']"));
    public static final SelenideElement Scheduled_Query_Approval_Confirmation_Title = $(By.xpath("//div[text()='Approval Confirmation']"));


    public static final SelenideElement ApproveActionButtonByQuery_Name(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//parent::tr//td[contains(@class,'cdk-column-action')]//img[@mattooltip=\"Approve\"]"));
        return action;
    }

    public static final SelenideElement RejectActionButtonByQuery_Name(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td//img[@mattooltip='Reject']"));
        return action;
    }

    public static final SelenideElement Expand_The_Request(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td//div[@aria-label='expand row']//img[@mattooltip='Expand']"));
        return action;
    }

}
