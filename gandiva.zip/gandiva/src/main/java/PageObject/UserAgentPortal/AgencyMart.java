package PageObject.UserAgentPortal;


import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class AgencyMart {

   public static final SelenideElement allCases = $(By.xpath("//*[text()='All Cases ']"));

   public static final SelenideElement viewCase_btn = $(By.xpath("//*[text()=' View Case ']"));

   public static final SelenideElement erSearch_radioBtn = $(By.xpath("//*[text()=' ER Search ']"));

   public static final SelenideElement selectSource = $(By.xpath("//*[@placeholder='Select Source']"));

   public static final SelenideElement person = $(By.xpath("//*[text()='PERSON']"));
   public static final SelenideElement selectParameter = $(By.xpath("//*[@placeholder='Select Parameter']"));

   public static final SelenideElement selectOperator = $(By.xpath("//*[@placeholder='Select Operator']"));

   public static final SelenideElement equalOperator = $(By.xpath("//*[text()='=']"));
   public static final SelenideElement fuzzyOperator = $(By.xpath("//*[text()='Fuzzy']"));

   public static final SelenideElement paramValue = $(By.xpath("//*[@placeholder='Eg:khush']"));

   public static final SelenideElement search_btn = $(By.xpath("//*[text()=' Search ']"));


}
