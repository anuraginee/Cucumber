/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.UserAgentPortal.Reports;

import PageObject.AdminPortal.Dashboard.Admin_dashboard;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class UA_Reports extends Admin_dashboard {
    public static final SelenideElement reports = $(By.xpath("//mat-sidenav-container//span[text()=\"Reports\"]"));
    public static final SelenideElement Case = $(By.xpath("//div[contains(@class,'navigation-item-title')]//span[text()=' Case ']"));

    public static final SelenideElement Case_Case_Summary = $(By.xpath("//span[contains(text(),'Case Summary')]"));
    public static final SelenideElement Case_List_Of_Cases_With_Requests = $(By.xpath("//span[contains(text(),'List of Cases With Request')]"));
    public static final SelenideElement Case_Case_History = $(By.xpath("//span[contains(text(),'Case History')]"));
    public static final SelenideElement Case_User_Wise_Case_Level_Requests = $(By.xpath("//span[contains(text(),'User Wise Case Level Requests')]"));
    public static final SelenideElement Case_Case_Transfer_From_Original_User = $(By.xpath("//span[contains(text(),'Case Transfer From Original User')]"));
    public static final SelenideElement Case_Role_Wise_User_Wise_Case_Statistics = $(By.xpath("//span[contains(text(),'Role Wise User Wise  Case Statistics')]"));
    public static final SelenideElement Case_Case_List = $(By.xpath("//span[contains(text(),'Case List')]"));

//    Requests Reports Related Xpath

    public static final SelenideElement Request = $(By.xpath("//div[contains(@class,'navigation-item-title')]//span[text()=' Request ']"));

    public static final SelenideElement Scheduled_Queries_Summary = $(By.xpath("//span[contains(text(),'Scheduled Query Summary')]"));
    public static final SelenideElement QR_Request_Summary = $(By.xpath("//span[contains(text(),'QR Request Summary')]"));
    public static final SelenideElement Request_History = $(By.xpath("//span[contains(text(),'Request History')]"));
    public static final SelenideElement Request_Error = $(By.xpath("//span[contains(text(),'Request Error')]"));
    public static final SelenideElement ER_Request_Summary = $(By.xpath("//span[contains(text(),'ER Request Summary')]"));
    public static final SelenideElement Request_Summary = $(By.xpath("//span[text()=' Request Summary ']"));
    public static final SelenideElement List_of_Requests = $(By.xpath("//span[contains(text(),'List of Requests')]"));

    //    Approval Reports Related Xpath


    public static final SelenideElement Approval = $(By.xpath("//div[contains(@class,'navigation-item-title')]//span[text()=' Approval ']"));

    public static final SelenideElement Case_Requests_Pending_Approval = $(By.xpath("//span[contains(text(),' Case Requests Pending Approval ')]"));
    public static final SelenideElement List_Of_Pending_Requests_For_Recommendation = $(By.xpath("//span[contains(text(),'List Of Pending Requests For Recommendation')]"));
    public static final SelenideElement List_Of_Pending_Query_Response_For_Their_Action = $(By.xpath("//span[contains(text(),'List Of Pending Query Response For Their Action')]"));
    public static final SelenideElement List_Of_All_Data_Mart_Requests = $(By.xpath("//span[contains(text(),'List Of All Data Mart Requests')]"));
    public static final SelenideElement List_Of_Pending_Query_Requests_For_Their_Action = $(By.xpath("//span[contains(text(),'List Of Pending Query Requests For Their Action')]"));


    public static final SelenideElement Status_Of_Requests_Raised_For_Approval = $(By.xpath("//span[contains(text(),'Status Of Requests Raised For Approval')]"));
    public static final SelenideElement List_Of_Users_With_Cases = $(By.xpath("//span[contains(text(),'List Of Users With Cases')]"));
    public static final SelenideElement Case_Requests_Received_For_Review = $(By.xpath("//span[contains(text(),'Case Requests Received For Review')]"));
    public static final SelenideElement Request_Awaiting_Approving_Officer_Review_Approval = $(By.xpath("//span[contains(text(),'Request Awaiting Approving Officer Review/Approval')]"));
    public static final SelenideElement Case_Report_Nodal_Wise = $(By.xpath("//span[contains(text(),'Case Report Nodal Wise')]"));
    public static final SelenideElement Users = $(By.xpath("//div[contains(@class,'navigation-item-title')]//span[text()=' User ']"));
    public static final SelenideElement List_Of_Existing_Users = $(By.xpath("//span[contains(text(),'List Of Existing Users')]"));

}
