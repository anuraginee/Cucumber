/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Agency_Mart;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Agency_Mart_Approval_Page {

    public static final SelenideElement Intra_Sharing_Approval_Title = $(By.xpath("//div//h2[contains(text(),'Sharing Approval')]"));
    public static final SelenideElement Pending_Request = $(By.xpath("//*[text()='Pending Requests']"));
    public static final SelenideElement Approved_Rejected_Requests = $(By.xpath("//*[text()='Pending Requests']"));
    public static final tableImpl Agency_Common_Mart_Approval_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mdc-data-table__table cdk-table mat-sort w-full')]")).shouldBe(Condition.visible, Duration.ofMinutes(6)));
    public static final SelenideElement Use_Case_Request_Approval = $(By.xpath("//div[contains(text(),'Use Case Request Approval')]"));
    public static final SelenideElement Common_Mart_Title = $(By.xpath("//div//h2[contains(text(),'Common Mart')]"));
    public static final SelenideElement SUBMIT_BUTTON = $(By.xpath("//span[contains(text(),'Submit')]"));
    public static final SelenideElement CANCEL_BUTTON = $(By.xpath("//span[contains(text(),'Cancel')]"));
    public static final SelenideElement Agency_Approved_Rejected_Requests= $(By.xpath("//span[contains(text(),'Approved/Rejected Requests')]"));
    public static final SelenideElement Request_Textbox = $(By.xpath("//*[@placeholder='Enter Remarks']"));

    public static final SelenideElement Ingestion_failed_Message = $(By.xpath("//dynamic-view/div[text()='Ingestion Failed During Agency update in ER ']"));
    public static final SelenideElement Ingestion_Success_Message = $(By.xpath("//dynamic-view/div[contains(text(),'Agency Mart Request Approved Successfully']"));
    public static final SelenideElement BackToListView = $(By.xpath("//span//img[@ng-reflect-message=\"Back\"]"));
    public static final SelenideElement PersonalInformation = $(By.xpath("//app-view-er-profile-action-agency[@ng-reflect--profile-data=\"[object Object]\"]//div//div//div[text()='Person Information']"));



    public static final SelenideElement Expand(String caseName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//button//img[@mattooltip=\"Expand\"]"));
        return action;
    }

    public static final SelenideElement Expand_Profile_Name(String caseName, String Profile_Name) {
        SelenideElement action = $(By.xpath("(//div[text()=' " + caseName + " ']//parent::td//parent::tr//parent::tbody//tr[contains(@class,'example-detail-row')]//td[contains(@class,'cdk-column-expandedDetail')]//div[contains(@class,'example-element-detail')]//div//div[contains(@class,'mat-elevation-')]//table[contains(@class,'mat-table cdk-table mat-sort')]//tbody//tr//td[contains(@class,'cdk-column-profileName')]//div[text()=' " + Profile_Name + " '])[1]"));
        return action;
    }
    public static final SelenideElement View_Button(String Profile_Name) {
        SelenideElement action = $(By.xpath("(//div//div[contains(@class,'mat-elevation-')]//table[contains(@class,'mat-table cdk-table mat-sort')]//tbody//tr//td[contains(@class,'cdk-column-profileName')]//div[text()=' " + Profile_Name + " ']//parent::td//parent::tr//td//button)[1]\n"));
        return action;
    }

}
