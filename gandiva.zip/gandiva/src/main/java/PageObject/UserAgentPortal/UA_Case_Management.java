/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import static com.codeborne.selenide.Selenide.$;


@Component
public class UA_Case_Management {

    public static final SelenideElement Cases = $(By.xpath("//fuse-vertical-navigation//div[contains(@class,'fuse-vertical-navigation-item-title')]//span[contains(text(),'Cases')]"));
    public static final SelenideElement Cases_View_Only = $(By.xpath("//fuse-vertical-navigation//div[contains(@class,'fuse-vertical-navigation-item-title')]//span[contains(text(),'Cases – View Only')]"));
    public static final SelenideElement Cases_Details_View_Only = $(By.xpath("//fuse-vertical-navigation//div[contains(@class,'fuse-vertical-navigation-item-title')]//span[contains(text(),'Case Details – View Only')]"));
    public static final SelenideElement Case_Participants = $(By.xpath("//fuse-vertical-navigation//div[contains(@class,'fuse-vertical-navigation-item-title')]//span[contains(text(),'Case Participants')]"));
    public static final SelenideElement Case_Owner = $(By.xpath("//fuse-vertical-navigation//div[contains(@class,'fuse-vertical-navigation-item-title')]//span[contains(text(),'Case Owner – Revoke')]"));


}
