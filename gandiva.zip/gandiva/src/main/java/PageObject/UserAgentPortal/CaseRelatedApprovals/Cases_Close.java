/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseRelatedApprovals;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Cases_Close {


    public static final SelenideElement Closed_Cases = $(By.xpath("//span[text()=' Case Close ']"));
    public static final SelenideElement Case_Close_Requests_Title = $(By.xpath("//h2[contains(text(),'Case Close Requests')]"));
    public static final SelenideElement Close_Approved_Rejected_Requests_Tab= $(By.xpath("//span[contains(text(),'Approved/Rejected Requests')]"));
    public static final SelenideElement Case_Close_Requests_Reject= $(By.xpath("(//tr[@role='row'])[2]//span//img[@mattooltip='Reject']"));
    public static final SelenideElement Case_Close_Status= $(By.xpath("(//tr[@role='row'])[2]//span//img[@mattooltip='Approve']"));
    public static final SelenideElement Case_Status= $(By.xpath("//div[@role='button']/div[contains(text(),'Status')]"));

    public static final SelenideElement ActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//img[@mattooltip='" + actionName + "']"));
        return action;
    }
    public static final SelenideElement CaseStatusByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//div[text()=' " + actionName + " ']"));
        return action;
    }
    public static final SelenideElement CaseCloseApproveDateByCaseName(String caseName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//td[contains(@class,'mat-column-closeApprovedOn')]//div"));
        return action;
    }

}
