/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseRelatedApprovals;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Case_Inititaion {


/*
        Xpath for Nodal Officer -------------> UA portal-Case related tabs
*/

    public static final SelenideElement Case_Initiation = $(By.xpath("//span[contains(text(),'Case Initiation')]"));
    public static final SelenideElement Case_Archive = $(By.xpath("//span[contains(text(),'Case Archive')]"));
    public static final SelenideElement Case_Initiation_Requests_Title = $(By.xpath("//h2[contains(text(),'Case Initiation Requests')]"));
    public static final SelenideElement Pending_requests = $(By.xpath("//span[contains(text(),'Pending Requests')]"));
    public static final SelenideElement Approved_Rejected_Requests = $(By.xpath("//span[contains(text(),'Approved Rejected Requests')]"));
    public static final SelenideElement Pending_requests_Requests_CaseNo = $(By.xpath("(//td[contains(@class,'caseNo')])[1]"));
    public static final SelenideElement Pending_requests_Requests_createdByName = $(By.xpath("(//td[contains(@class,'createdByName')])[1]"));
    public static final SelenideElement Pending_requests_Requests_CaseName = $(By.xpath("(//td[contains(@class,'caseName')])[1]"));
    public static final SelenideElement Pending_requests_Requests_Case_physical_Digital = $(By.xpath("(//td[contains(@class,'physicalCaseId')])[1]"));
    public static final SelenideElement User_Hierarchy = $(By.xpath("(//td[contains(@class,'endDate')])[1]"));
    public static final SelenideElement Approve_Button = $(By.xpath("(//button[contains(@class,'primary') and @color='primary'])[1]"));
    public static final SelenideElement Reject_Button = $(By.xpath("(//button[contains(@class,'danger') and @color='danger'])[1]"));
    public static final SelenideElement Approval_Confirmation = $(By.xpath("//div[contains(text(),'Approval Confirmation')]"));
    public static final SelenideElement Rejection_Confirmation = $(By.xpath("//div[contains(text(),'Rejection Confirmation')]"));
    public static final SelenideElement Remarks = $(By.xpath("//textarea[@id='requesterComments']"));
    public static final SelenideElement Approval_page_Case_No = $(By.xpath("//div[contains(text(),'Case Name')]//following-sibling::span[contains(@class,'text-primary')]"));
    public static final SelenideElement Reject_status = $(By.xpath("(//tbody//tr//td[7]//button//img[@mattooltip=\"Rejected\"])[1]"));
    public static final SelenideElement Remarks_Error_Message = $(By.xpath("//div//mat-error[text()=' Please enter the remarks to proceed further ']"));


    public static final SelenideElement ActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//img[@mattooltip='" + actionName + "']"));
        return action;
    }
    public static final SelenideElement CaseStatusByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//div[text()=' " + actionName + " ']"));
        return action;
    }


}
