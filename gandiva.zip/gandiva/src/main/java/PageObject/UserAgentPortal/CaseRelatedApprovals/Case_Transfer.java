/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseRelatedApprovals;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Case_Transfer {
    public static final SelenideElement Case_Transfer_Requests_Title = $(By.xpath("//h2[contains(text(),'Case Transfer Requests')]"));
    public static final SelenideElement Case_Transfer = $(By.xpath("//span[text()=' Case Transfer ']"));
    public static final SelenideElement Role_Name = $(By.xpath("//mat-select[@formcontrolname='roleId']"));
    public static final SelenideElement Transferred_User_ID = $(By.xpath("//mat-select[@formcontrolname='transferredToUserId']"));
    public static final SelenideElement Transfer_Approved_Rejected_Requests = $(By.xpath("//span[contains(text(),'Approved Rejected Requests')]"));

    public static final SelenideElement Role_Name_AUTHORIZED_OFFICER = $(By.xpath("//span[contains(text(),'AUTHORIZED OFFICER')]"));
    public static final SelenideElement Role_Name_APPROVING_OFFICER = $(By.xpath("//span[contains(text(),'APPROVING OFFICER')]"));
    public static final SelenideElement Role_Name_SUPERVISORY_OFFICER = $(By.xpath("//span[contains(text(),'SUPERVISORY OFFICER')]"));


    public static final SelenideElement ActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//img[@mattooltip='" + actionName + "']"));
        return action;
    }

    public static final SelenideElement CaseTransferID(String UserName) {
        SelenideElement action = $(By.xpath("//span[contains(text(),'" + UserName + "@devng.in')]"));
        return action;
    }

    public static final SelenideElement CaseStatusByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//button"));
        return action;
    }

    public static final SelenideElement CaseStatusMouseHoverByCaseName(String caseName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//button//img"));
        return action;
    }

    public static final SelenideElement ApproveDateByCaseName(String caseName) {
        SelenideElement action = $(By.xpath("//div[text()=' " + caseName + " ']//parent::td//parent::tr//td[contains(@class,'mat-column-caseApprovedOn')]//div"));
        return action;
    }
}
