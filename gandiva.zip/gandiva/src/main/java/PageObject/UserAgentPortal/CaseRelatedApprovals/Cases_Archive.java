/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseRelatedApprovals;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Cases_Archive {

// Feature Deprecated


    public static final SelenideElement getActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//parent::div//parent::div//button[@mattooltip='" + actionName + "']"));
        return action;
    }


}
