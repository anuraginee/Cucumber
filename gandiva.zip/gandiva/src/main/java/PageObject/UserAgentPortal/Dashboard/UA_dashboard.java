/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.UserAgentPortal.Dashboard;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class UA_dashboard {
    public static final SelenideElement gandiva_icon = $(By.xpath("//classy-layout//fuse-vertical-navigation//div//div[contains(@class,'fuse-vertical-navigation-content')]//div//div//div[@class='relative']"));
    // Cart Users
    public static final SelenideElement cart_users_Total = $(By.xpath("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/following::div[1]"));
    public static final SelenideElement bar_dashboard = $(By.xpath("//span[contains(text(),'Dashboard')]"));
    public static final SelenideElement case_Management = $(By.xpath("//span[contains(text(),'Case Management')]"));
    public static final SelenideElement Scheduled_Query_Management = $(By.xpath("//span[contains(text(),'Scheduled Query Management')]"));
    public static final SelenideElement Scheduled_Query = $(By.xpath("//span[text()=' Scheduled Query ']"));
    public static final SelenideElement Case_Related_Approvals = $(By.xpath("//span[contains(text(),'Case Related Approvals')]"));
    public static final SelenideElement Request_Response_Approvals = $(By.xpath("//span[contains(text(),'Request – Response Approvals')]"));
    public static final SelenideElement Scheduled_Query_Approvals = $(By.xpath("//span[contains(text(),'Scheduled Query Approvals')]"));
    public static final SelenideElement Intra_Agency_Approval = $(By.xpath("//span[contains(text(),'Intra Agency Approval')]"));
    public static final SelenideElement Intra_Agency_Sharing = $(By.xpath("//span[contains(text(),'Intra Agency Sharing')]"));
    public static final SelenideElement Inter_Agency_Sharing = $(By.xpath("//span[contains(text(),'Inter Agency Sharing')]"));
    public static final SelenideElement Inter_Agency_Approval = $(By.xpath("//span[contains(text(),'Intra Agency Approval')]"));
    public static final SelenideElement Sharing_Approval = $(By.xpath("//span[contains(text(),'Sharing Approval')]"));
    public static final SelenideElement User_Management = $(By.xpath("//span[contains(text(),'User Management')]"));
    public static final SelenideElement Entity_Profiles = $(By.xpath("//span[contains(text(),'Entity Profiles')]"));
    public static final SelenideElement Agency_Mart = $(By.xpath("//span[text()=' Agency Mart ']"));
    public static final SelenideElement Common_Mart = $(By.xpath("//span[text()=' Common Mart ']"));
    public static final SelenideElement Reports = $(By.xpath("//span[contains(text(),'Reports')]"));
    public static final SelenideElement User_Activity_Logs = $(By.xpath("//span[contains(text(),'User Activity Logs')]"));
    public static final SelenideElement Feedback = $(By.xpath("//span[contains(text(),'Feedback')]"));
    public static final SelenideElement Notification_Icon = $(By.xpath("//span//mat-icon[@role ='img' and @ng-reflect-message='Notifications']"));

    public static final SelenideElement update_Profile = $(By.xpath("//*[text()=' Profile Update ']"));
    public static final SelenideElement Recommendation = $(By.xpath("//*[text()=' Recommendation ']"));
    public static final SelenideElement Approval = $(By.xpath("//*[text()=' Approval ']"));
    public static final SelenideElement Users_Heading = $(By.xpath("(//*[contains(text(),'All Users')])[2]"));
    public static final SelenideElement Transferred_Cases_Heading = $(By.xpath("(//*[contains(text(),'Transferred Cases')])[2]"));

    public static final SelenideElement manageTerminal = $(By.xpath("//*[text()=' Manage Terminal ']"));

    public static final SelenideElement manageUSBUA = $(By.xpath("//*[text()=' Manage USB ']"));


    //    Dashboard Widgets

    //    Notification pages after login: remove this xpath after bug fix
    public static final SelenideElement Notification_Window_Close = $(By.xpath("//div[text()='Notifications From NATGRID']//parent::div//button//mat-icon[@role='img']"));
    public static final SelenideElement Notification_Window = $(By.xpath("//mat-dialog-container[@role='dialog']//app-push-dialog//div[text()='Notifications From NATGRID']"));
    public static final SelenideElement Pending_Case_Level_Request = $(By.xpath("//div[text()=' Pending Case Level Request ']"));
    public static final SelenideElement Total_Count = $(By.xpath("//div[@class=\"mat-mdc-paginator-range-actions\"]//div"));



    public void clickLink(String linkName) {
        SelenideElement link = $(By.xpath("//at-sidenav-container//span[text()=" + linkName + "]"));
        link.click();
    }

    // This method will return the Values of Parameters such as Total count e.t.c from dashboard w.r.t widget name.
    public static SelenideElement getCountByWidgetNameAndParam(String widgetName, String param) {
        SelenideElement se = $(By.xpath("//div[text()=' " + widgetName + " ']//parent::div//div[text()='" + param + "']//following-sibling::div"));
        return se;
    }

    public static SelenideElement getWidgetName(String widgetName) {
        SelenideElement se = $(By.xpath("(//div[text()=' " + widgetName + " ']//parent::div//parent::div//parent::div)[1]"));
        return se;
    }

    public static SelenideElement widgetViewAll(String widgetName) {
        SelenideElement ViewAll = $(By.xpath("//div[text()=' " + widgetName + " ']//parent::div//parent::div//parent::div//span[contains(text(),' View All')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
        return ViewAll;
    }

    public static SelenideElement widgetHeading(String widgetName) {
        SelenideElement ViewAll = $(By.xpath("//div[text()=' " + widgetName + " ']"));
        return ViewAll;
    }

    public static SelenideElement password(String loginID) {
        SelenideElement passIcon = $(By.xpath("//*[text()='" + loginID + "']/..//following-sibling::td[contains(@class,'cdk-cell text-secondary cdk-column-isPasswordFlag')]"));
        return passIcon;
    }

    public static SelenideElement action(String loginID) {
        SelenideElement updateUser = $(By.xpath("//*[text()='" + loginID + "']/..//following-sibling::td//div//button[@mattooltip='Update User']"));
        return updateUser;
    }



}
