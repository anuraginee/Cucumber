/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 21-07-2023
*/
package PageObject.UserAgentPortal.Dashboard;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Pending_Case_Level_Requests {
    public static final SelenideElement gandiva_icon = $(By.xpath("//classy-layout//fuse-vertical-navigation//div//div[contains(@class,'fuse-vertical-navigation-content')]//div//div//div[@class='relative']"));
    public static final SelenideElement search = $(By.xpath("//div//input[@placeholder='Search']"));
    public static final tableImpl Pending_Case_Level_Requests_table = new tableImpl($(By.xpath("//*[@class='mat-mdc-table mdc-data-table__table cdk-table mat-sort mat-elevation-z8']")).should(Condition.appear));
    public static final SelenideElement Raised_On = $(By.xpath("//tr[contains(@class,'cdk-header-row') and @role='row']//th[contains(@class,'cdk-column-raisedOn') and @role='columnheader']//div[contains(text(),' Raised On')]"));
    public static final SelenideElement Next_Button = $(By.xpath("//button[@aria-label='Next page']"));
    public static final SelenideElement Last_Page_Button = $(By.xpath("//button[@aria-label='Last page']"));
    public static final SelenideElement Items_per_page = $(By.xpath("//mat-select[@aria-label='Items per page:']"));
    public static final SelenideElement SPINNER_THREE_DOTS_ICON = $(By.xpath("//div//div[@class='spinner']"));
    public static final SelenideElement select_items_perPage(String options) {
        SelenideElement Items_per_page = $(By.xpath("//mat-option//span[contains(text(),'" + options + "')]"));
        return Items_per_page;
    }


}
