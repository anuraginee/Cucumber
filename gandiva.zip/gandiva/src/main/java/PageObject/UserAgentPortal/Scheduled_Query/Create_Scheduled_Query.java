/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Create_Scheduled_Query {

    public static final SelenideElement Create_Scheduled_Query_Button = $(By.xpath("//span[text()=' Create Scheduled Query']//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));
    public static final SelenideElement Create_Scheduled_Query_Title = $(By.xpath("//div[text()='Create Scheduled Query']"));
    public static final SelenideElement Scheduled_Query_Title = $(By.xpath("//div[text()=' Scheduled Query ']"));
    public static final SelenideElement Case_Name_Field = $(By.xpath("//*[@formcontrolname=\"caseName\"]"));
    public static final SelenideElement Scheduled_Query_Name = $(By.xpath("//input[@id=\"watchlistName\"]"));
    public static final SelenideElement Query_Name_Error_Message = $(By.xpath("//div//mat-error[text()=' Scheduled Query Name is Required ']"));
    public static final SelenideElement Start_Date = $(By.xpath("//div//input[@formcontrolname=\"startDate\"]"));

    public static final SelenideElement Start_Date_Calender_Button = $(By.xpath("(//mat-datepicker-toggle//button[@aria-label='Open calendar'])[1]"));
    public static final SelenideElement Start_Date_Error_Message = $(By.xpath("//div//mat-error[text()=' Start Date is Required ']"));
    public static final SelenideElement End_Date = $(By.xpath("//div//input[@formcontrolname=\"endDate\"]"));
    public static final SelenideElement End_Date_Calender_Button = $(By.xpath("(//mat-datepicker-toggle//button[@aria-label='Open calendar'])[2]"));
    public static final SelenideElement End_Date_Error_Message = $(By.xpath("//div//mat-error[text()=' End Date is Required ']"));
    public static final SelenideElement Case_Name_Error_Message = $(By.xpath("//div//mat-error[text()=' Case Name not recognized. Click one of the autocomplete options. ']"));
    public static final SelenideElement Source_Field = $(By.xpath("//*[@formcontrolname=\"source\"]"));
    public static final SelenideElement Source_Error_Message = $(By.xpath("//div//mat-error[text()=' Source Name not recognized. Click one of the autocomplete options. ']"));
    public static final SelenideElement Select_Use_Case = $(By.xpath("//mat-select[@id=\"UseCase\"]"));
    public static final SelenideElement Use_Case = $(By.xpath("(//div[contains(@class,'mat-form-field-infix')])[7]"));
    public static final SelenideElement Use_Case_Arrow = $(By.xpath("(//div[contains(@class,'mat-select-arrow-wrapper')])[1]"));


//  Use_Case is made as Static as got mentioned error : "UseCase not recognized. Click one of the autocomplete options.". Remove Use_Case_Name Xpath once mentioned issue is fixed

    public static final SelenideElement Use_Case_Name = $(By.xpath("//mat-option[@ng-reflect-value='76']"));

    public static final SelenideElement Use_Case_Error_Message = $(By.xpath("//div//mat-error[text()=' UseCase not recognized. Click one of the autocomplete options. ']"));
    public static final SelenideElement Select_Frequency = $(By.xpath("//div//mat-select[@placeholder=\"Frequency\" and @id=\"frequency\"]"));
    public static final SelenideElement Frequency_Error_Message = $(By.xpath("//div//mat-error[text()=' Frequency is Required ']"));
    public static final SelenideElement Remarks = $(By.xpath("//div//textarea[@id=\"remarks\"]"));
    public static final SelenideElement Checkbox = $(By.xpath("//span[@ng-reflect-trigger=\"[object HTMLLabelElement]\"]"));
    public static final SelenideElement Create_Button = $(By.xpath("//span[text()=' Create ']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//span[text()=' Cancel ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));

    public static final SelenideElement Given_Name = $(By.xpath("//input[@id=\"applFirstName\"]"));
    public static final SelenideElement Given_Name_Error_Message = $(By.xpath("//div//mat-error[text()=' Given Name includes First and Middle Name and should be alphabet. Space is allow ']"));
    public static final SelenideElement Sur_Name = $(By.xpath("//input[@id=\"applLastName\"]"));
    public static final SelenideElement Email_ID = $(By.xpath("//input[@id=\"emailID\"]"));
    public static final SelenideElement Email_ID_Error_message = $(By.xpath("//div//mat-error[text()=' Email ID may contain digits, alphabets, underscores, dash, dot, @ between 5 to 3 ']"));
    public static final SelenideElement Passport_Number = $(By.xpath("//div//input[@id=\"passport\"]"));
    public static final SelenideElement Pan_Number = $(By.xpath("//div//input[@id=\"pan\"]"));
    public static final SelenideElement Nationality_Drop_Down = $(By.xpath("//mat-select[@role='combobox' and @placeholder='Select Here']"));


    public static final SelenideElement Get_Case_Name(String caseName) {
        SelenideElement CaseName = $(By.xpath("//div[@role='listbox']//mat-option[@role='option']//span[text()=' " + caseName + " ']"));
        return CaseName;
    }

    public static final SelenideElement Get_Query_Source(String Query_Source) {
        SelenideElement Source = $(By.xpath("//div[@role='listbox']//mat-option[@role='option']//span[text()=' " + Query_Source + " ']"));
        return Source;
    }

    public static final SelenideElement Get_Query_Use_Case(String Query_Use_Case) {
        SelenideElement Use_Case = $(By.xpath("//div[@role='listbox']//mat-option[@role='option']//span[text()=' " + Query_Use_Case + " ']"));
        return Use_Case;
    }

    public static final SelenideElement Get_Nationality(String Country) {
        SelenideElement Use_Case = $(By.xpath("//div[@role='listbox']//mat-option//span[text()='" + Country + "']"));
        return Use_Case;
    }

    public static final SelenideElement Select_Case_Name(String Case_Name) {
        SelenideElement Use_Case = $(By.xpath("//*[@role='listbox']//mat-option[@role='option']//span[text()=' " + Case_Name + " ']"));
        return Use_Case;
    }

    public static void SelectDate(String Day, String Month, String Year) {
        final SelenideElement Calender = $($(By.xpath("//mat-calendar[@ng-reflect-start-view='month']")).should(Condition.appear));
        final SelenideElement Calender_Year = $(By.xpath("//button[@aria-label=\"Choose month and year\"]//span//span"));
        Calender.shouldBe(Condition.visible);
        System.out.println(Calender_Year.getText());
        Calender_Year.click();
        final SelenideElement Calender_year = $(By.xpath("//button[contains(@class,' mat-calendar-body-active')]//div[text()=' " + Year + " ']"));
        Calender_year.click();
        final SelenideElement Calender_month = $(By.xpath("//button[contains(@class,' mat-calendar-body-active')]//div[text()=' " + Month + " ']"));
        Calender_month.click();
        final SelenideElement Calender_date = $(By.xpath("//button[contains(@class,'mat-calendar-body-cell')]//div[text()=' " + Day + " ']"));
        Calender_date.click();
    }

}
