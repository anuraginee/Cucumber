/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Pending_For_Approval {
    public static final tableImpl Pending_For_Approval_Scheduled_Query_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mat-mdc-table')]")).should(Condition.appear));


}
