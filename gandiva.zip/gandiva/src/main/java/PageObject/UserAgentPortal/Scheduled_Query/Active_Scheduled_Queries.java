/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Active_Scheduled_Queries {
    public static final tableImpl Active_Scheduled_Query_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mat-mdc-table')]")).should(Condition.appear));
    public static final SelenideElement Expand_Button = $(By.xpath("(//table//tbody//td[contains(@class,'cdk-column-action')]//div[@aria-label='expand row']//button)[1]"));
    public static final SelenideElement View_Button = $(By.xpath("(//table//tbody//td[contains(@class,'cdk-column-view')]//div[contains(@class,'items-center')]//img[@mattooltip='View'])[1]"));
    public static final SelenideElement View_Scheduled_Query_Title = $(By.xpath("//div[text()='View Scheduled Query']"));
    public static final SelenideElement Scheduled_Query_Name = $(By.xpath("//div//div[text()='Name ']//following::div[1]"));
    public static final SelenideElement Scheduled_Query_Status = $(By.xpath("//*[text()='status ']//following::div[1]"));
    public static final SelenideElement Scheduled_Query_Case_Name = $(By.xpath("//div//div[text()='Case Name ']//following::div[1]"));


    public static final SelenideElement View_Pending_Query_By_Query_Name(String Query_Name) {
        SelenideElement CaseName = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//parent::tr//td[contains(@class,'mat-column-pendingview')]//img[@mattooltip='View']"));
        return CaseName;
    }
    public static final SelenideElement View_Active_Query_By_Query_Name(String Query_Name) {
        SelenideElement CaseName = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//parent::tr//td[contains(@class,'view-button')]//img[@mattooltip='View']"));
        return CaseName;
    }


}
