/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Scheduled_Query;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Scheduled_Query {

    public static final SelenideElement Active_Scheduled_Queries = $(By.xpath("//*[contains(text(),'Active Scheduled Queries')]"));
    public static final SelenideElement Deactivated_Scheduled_Queries = $(By.xpath("//*[contains(text(),'Deactivated Scheduled Queries')]"));
    public static final SelenideElement Pending_Approval = $(By.xpath("//*[contains(text(),'Pending Approval')]"));
    public static final SelenideElement Rejected_Scheduled_Queries = $(By.xpath("//*[contains(text(),'Pending Requests')]"));
}
