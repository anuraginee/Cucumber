/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.UserManagement.CreateUser;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class Create_User {
    public static final SelenideElement Create_User_title = $(By.xpath("//div//div[contains(text(),'Create User')]"));
    public static final SelenideElement Create_Users = $(By.xpath("//span[text()='Create User']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
    public static final SelenideElement UserName = $(By.xpath("//div//input[@formcontrolname='userName']"));
    public static final SelenideElement EmailID = $(By.xpath("//div//input[@formcontrolname='emailId']"));
    public static final SelenideElement User_Role = $(By.xpath("//div//mat-select[@role='combobox' and @formcontrolname='roleId']"));
    public static final SelenideElement LoginID = $(By.xpath("//div/input[@formcontrolname='loginId']")); // Only Digits
    public static final SelenideElement LoginID_Domain = $(By.xpath("//div[contains(@class,'domainName')]"));
    public static final SelenideElement Rank_Field = $(By.xpath("//div/mat-select[@role='combobox' and @formcontrolname=\"rankId\"]"));
    public static final SelenideElement Select_Rank_DropDown = $(By.xpath("//div[@class='cdk-overlay-pane']/div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span"));
    public static final SelenideElement Portal_Access_Field = $(By.xpath("//div//mat-select[@role='combobox' and @formcontrolname='portalId']"));
    public static final SelenideElement Gandiva_Portal = $(By.xpath("//div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span"));
    public static final SelenideElement Contact_Number_Field = $(By.xpath("//div//input[@formcontrolname='contactNo']"));
    public static final SelenideElement Address = $(By.xpath("//textarea[@id=\"caseDescription\"]"));
    public static final SelenideElement Login_ID_prefix = $(By.xpath("//div[contains(@class,'mat-mdc-form-field-icon-prefix')]//span"));
    public static final SelenideElement Menu_and_Access_Permission_Heading = $(By.xpath("//p[text()='Menu and Access Permission']"));
    public static final SelenideElement Menu_and_Access_Permission_Menu_Tab_Header = $(By.xpath("//span[@class=\"mdc-tab__text-label\"]"));
    public static final ElementsCollection menu_Permissions = $$(By.xpath("(//div//div[@fxlayout=\"row wrap\"]//mat-tab-group[contains(@class,'mat-tab-group')]//div[@class=\"mat-tab-body-wrapper\"]//mat-tab-body[@role='tabpanel']//div[contains(@class,'ng-trigger-translateTab')]//mat-dialog-content//div[2]//div)[1]"));
//    public static final tableImpl User_table = new tableImpl($(By.xpath("//table[contains(@class,'mat-mdc-table')]")).should(Condition.appear));

    public static final SelenideElement firstTimePassword = $(By.xpath(" //*[contains(text(),'User Password')]"));
    public static final SelenideElement passIcon = $(By.xpath("(//*[@mattooltip='View Password'])[1]"));

    public static final SelenideElement popUpClose = $(By.xpath("(//mat-icon[@role=\"img\" and @data-mat-icon-name=\"clear\"]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"])[2]"));

    public static final ElementsCollection roleList = $$(By.xpath("//*[contains(@class,'ng-trigger-transformPanel') and @role='listbox']"));

    public static final SelenideElement currentPassword = $(By.xpath("//*[@formcontrolname='showCurrentPassCode']"));

    public static final SelenideElement newPassword = $(By.xpath("//*[@formcontrolname='showNewPassCode']"));

    public static final SelenideElement confirmNewPassword = $(By.xpath("//*[@formcontrolname='showConfirmPassCode']"));

    public static final SelenideElement resetPasswordSubmit = $(By.xpath("//*[text()=' Submit ']//following-sibling::span[@class='mat-mdc-button-touch-target']"));

    public static final SelenideElement resetPasswordiagree = $(By.xpath("//*[@class='mat-ripple-element mat-checkbox-persistent-ripple']"));

    public static final SelenideElement Disclaimer = $(By.xpath("//*[text()=' End-User License Agreement (EULA) ']"));
    public static final SelenideElement Agree_checkbox = $(By.xpath("//div//mat-checkbox//*[@class=\"mdc-label\"]"));

    public static final SelenideElement nameErrorMsg = $(By.xpath("//*[text()=' Name is Required ']"));

    public static final SelenideElement emailErrorMsg = $(By.xpath("//*[text()=' Email ID is Required ']"));
    public static final SelenideElement roleErrorMsg = $(By.xpath("//*[text()=' Role is Required ']"));
    public static final SelenideElement loginErrorMsg = $(By.xpath("//*[text()=' Login ID is Required ']"));
    public static final SelenideElement rankErrorMsg = $(By.xpath("//*[text()=' Rank is Required ']"));
    public static final SelenideElement portalErrorMsg = $(By.xpath("//*[text()=' Portal is Required ']"));
    public static final SelenideElement contactNoErrorMsg = $(By.xpath("//*[text()=' Contact Number is Required ']"));

    public static final SelenideElement Designated_Officer_Reporter = $(By.xpath("//div//input[@formcontrolname='userReportingRoleId' and @ng-reflect-name='userReportingRoleId' and @ng-reflect-model='DESIGNATED OFFICER']"));

    public static final SelenideElement Select_User_Role(String User_role) {
        SelenideElement ViewCase = $(By.xpath("//div[@role='listbox']//mat-option[@role='option']//span[contains(text(),'" + User_role + "')]"));
        return ViewCase;
    }

    public static final SelenideElement User_Reporting_To(String User_role) {
        SelenideElement ViewCase = $(By.xpath("//div//input[@formcontrolname='userReportingRoleId' and @ng-reflect-name='userReportingRoleId' and @ng-reflect-model='" + User_role + "']"));
        return ViewCase;
    }


}
