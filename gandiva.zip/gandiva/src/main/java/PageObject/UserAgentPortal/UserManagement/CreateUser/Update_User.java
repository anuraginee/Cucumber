/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.UserManagement.CreateUser;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.cucumber.java.eo.Se;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Update_User {


    public static final SelenideElement createUserSearch = $(By.xpath("//*[@placeholder='Search']"));

    public static final tableImpl user_Mgmt_table = new tableImpl($(By.xpath("//table[@role='table']")).should(Condition.appear));

    public static final SelenideElement userName =  $(By.xpath("//*[@formcontrolname='userName']"));

    public static final SelenideElement emailID = $(By.xpath("//*[@formcontrolname='emailId']"));

    public static final SelenideElement contactNo = $(By.xpath("//*[@formcontrolname='contactNo']"));
    public static final SelenideElement updatebtn= $(By.xpath("//*[text()=' Update ']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
   public static final SelenideElement submitbtn = $(By.xpath("//*[text()=' Submit ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement forgetPassword = $(By.xpath("//*[@src='../../../../../../assets/icons/Forgot password.svg']"));



}
