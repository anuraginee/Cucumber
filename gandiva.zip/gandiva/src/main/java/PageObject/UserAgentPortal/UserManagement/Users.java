/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.UserManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Users {
    public static final SelenideElement Users_Tab = $(By.xpath("//fuse-vertical-navigation-collapsable-item//div[contains(@class,'fuse-vertical-navigation-item-children')]//fuse-vertical-navigation-basic-item//div//a//span[text()=' Users ']"));
    public static final SelenideElement Create_Users = $(By.xpath("//span[text()='Create User']"));
    public static final SelenideElement Search_bar = $(By.xpath("//div[@fxlayout='row']//mat-icon//input[@placeholder='Search']"));

    public static final SelenideElement ToastMessage = $(By.xpath("//*[@class='hot-toast-bar-base']"));









}
