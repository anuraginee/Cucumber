package PageObject.UserAgentPortal;


import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Component
public class Feedback {

    public static final SelenideElement User_role = $(By.xpath("//span[contains(@class,'mat-mdc-menu-trigger')]//span[2]"));

    public static final SelenideElement Feedback_Title = $(By.xpath("//*[contains(text(),'Feedback')]"));

    public static final SelenideElement Add_Feedback_Button = $(By.xpath("//span[contains(text(),'Add Feedback')]//following-sibling::span[@class='mat-mdc-button-touch-target']"));

    public static final SelenideElement Search_Bar = $(By.xpath("//input[@placeholder='Search']"));

    public static final SelenideElement SelectCategory = $(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));

    public static final SelenideElement SelectSubCategory = $(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));


    public static final SelenideElement FromDate = $(By.xpath("//input[@formcontrolname='fromDate' and @data-mat-calendar='mat-datepicker-2']"));

    public static final SelenideElement ToDate = $(By.xpath("//input[@formcontrolname='toDate' and @data-mat-calendar='mat-datepicker-1']"));

    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(text(),'Submit')]"));
    public static final SelenideElement Reset_Button = $(By.xpath("//span[contains(text(),'Reset')]"));
    public static final SelenideElement Add_Feedback_Window_Title = $(By.xpath(" //div[text()='Add Feedback']"));

    public static final SelenideElement FeedbackCategorySearch = $(By.xpath("//input[@formcontrolname=\"moduleId\"]"));
    public static final SelenideElement SubFeedbackCategoryDropdown = $(By.xpath("//input[@formcontrolname=\"subModuleId\"]"));
    public static final SelenideElement Menu_Drop_Down = $(By.xpath("//mat-select[@formcontrolname='menuId' and @role='combobox' and @ng-reflect-name='menuId']"));
    public static final SelenideElement Description = $(By.xpath("//div/textarea[@id='feedback']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//mat-icon[@data-mat-icon-name='clear' and @type='button']"));
    public static final SelenideElement Create_Button = $(By.xpath("//span[contains(text(),'Create')]//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));
    public static final SelenideElement Yes_button = $(By.xpath("//span[contains(text(),'Yes')]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement First_Row_Status = $(By.xpath("(//table//tbody//tr//td[contains(@class,'cdk-column-activeFlag')]//div//button)[1]"));
    public static final SelenideElement Confirmation_Window_Title = $(By.xpath("//div//div[text()='Confirmation']"));
    public static final SelenideElement Confirmation_Message = $(By.xpath("//span[text()='Do you wish to proceed?']"));

    public static final SelenideElement Created_On_Column = $(By.xpath("//div[text()=' Created On']"));
    public static final SelenideElement Text_Send_Button = $(By.xpath("//mat-icon[@data-mat-icon-name='send']"));
    public static final SelenideElement New_Chat_Box_UA = $(By.xpath("//table[contains(@class,'mat-mdc-table') and @role='table']//tbody//tr[1]//td[8]/div/div/img"));
    public static final SelenideElement  Input_Text_Box_UA = $(By.xpath("//textarea[@formcontrolname='message']"));

//    Download the Chat History Xpath(s)
    public static final SelenideElement  UA_Download_chat = $(By.xpath("//mat-icon[@data-mat-icon-name='cloud_download']"));

    public static final SelenideElement  Confirmation_Window = $(By.xpath("//*[text()='Confirmation']"));
    public static final SelenideElement  Confirm_Password = $(By.xpath("//*[@formcontrolname='confirmpassword']"));
    public static final SelenideElement  Save_Button = $(By.xpath("//div//button[@type=\"submit\"]//span[text()=' Save']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));




    public static final tableImpl FeedbackCategoryTable = new tableImpl($(By.xpath("//table[contains(@class,'mat-mdc-table')]")));

    public static final SelenideElement FeedbackCategory(String FeedbackCategoryName) {
        SelenideElement attributes = $(By.xpath("//div//div[@role='listbox']//span[text()='" + FeedbackCategoryName + "']"));
        return attributes;
    }

    public static final SelenideElement SubFeedbackCategory(String SubFeedbackCategoryName) {
        SelenideElement attributes = $(By.xpath("//div//div[@role='listbox' and @tabindex='-1' and @id='subModule-panel']//span[contains(text(),'" + SubFeedbackCategoryName + "')]"));
        return attributes;
    }


}
