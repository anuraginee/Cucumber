/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.Advanced_Search;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class Advanced_Search_Page {
    // Advanced Search Xpaths
    public static final SelenideElement Advanced_Search_Title = $(By.xpath("//div//div[contains(text(),'Advanced Search')]"));
    public static final SelenideElement Both_Radio_Button = $(By.xpath("//span[contains(text(),'Both')]"));
    public static final SelenideElement Use_Case_Radio_Button = $(By.xpath("//span[contains(text(),'Use Cases')]"));
    public static final SelenideElement ER_Profiles_Radio_Button = $(By.xpath("//span[contains(text(),'ER Profiles')]"));
    public static final List<SelenideElement> Select_Parameter = $$(By.xpath("//div//mat-select[contains(@id,'mat-select-') and @name='field' and @placeholder='Select Parameter']"));
    public static final SelenideElement source = $(By.xpath("//div//mat-select[contains(@id,'mat-select-')]"));

    public static final SelenideElement Add_Rule = $(By.xpath("//span[contains(text(),'+ Add Parameter')]//parent::span//following-sibling::span[@class='mat-mdc-focus-indicator']"));

    public static final List<SelenideElement> Select_Operator = $$(By.xpath("//div//mat-select[contains(@id,'mat-select-') and @name='operator' and @placeholder='Select Operator']"));

    public static final SelenideElement Search_Button = $(By.xpath("//span[text()='Search']//parent::span//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement Clear_Button = $(By.xpath("//span[contains(text(),'Clear')]"));
    public static final SelenideElement Advanced_Search_Mart = $(By.xpath("//div[text()=' Advanced Search']"));
    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(@class,'mat-button-wrapper') and contains(text(),'Submit')]"));

    // Apply condition i.e., first condition visible then click/select
    public static SelenideElement ER_Source(String Entity) {
        SelenideElement Entity_Source = $(By.xpath("//span[@class='mat-option-text' and contains(text(),' " + Entity + " ')]"));
        return Entity_Source;
    }

    public static SelenideElement ER_Parameter(String Parameter) {
        SelenideElement element = $(By.xpath("//div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span[contains(text(),'" + Parameter + "')]"));
        return element;
    }

    public static SelenideElement ER_Operator(String Operator) {
        SelenideElement element = $(By.xpath("//div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span[contains(text(),'" + Operator + "')]"));
        return element;
    }

    public static SelenideElement InputElementForParam(String Parameter) {
        SelenideElement element = $(By.xpath("//span[text()='" + Parameter + "']//parent::span//parent::div//parent::div//parent::mat-select//parent::div//parent::div//parent::div//parent::mat-form-field//parent::div//parent::div//parent::div[@class='ng-star-inserted']//div/input"));
        return element;
    }



}
