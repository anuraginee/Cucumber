/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import java.util.List;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class ViewCase_Discover {
    public static final SelenideElement Discover = $(By.xpath("//div[contains(text(),'Discover')]"));
    public static final SelenideElement Use_Case_Search = $(By.xpath("//span[contains(text(),'Use Case Search')]"));
    public static final SelenideElement ER_Search = $(By.xpath("//span[contains(text(),'ER Search')]"));
    public static final SelenideElement PO_Wise_Search = $(By.xpath("//span[contains(text(),'PO Wise Search ')]"));
    public static final SelenideElement Image_Search = $(By.xpath("//span[contains(text(),'Image Search')]"));
    public static final List<SelenideElement> Select_Parameter = $$(By.xpath("//div//mat-select[contains(@id,'mat-select-') and @name='field' and @placeholder='Select Parameter']"));
    public static final SelenideElement source = $(By.xpath("//div//mat-select[contains(@id,'mat-select-')]"));

    public static final SelenideElement Add_Rule = $(By.xpath("//span[@class='mdc-button__label' and contains(text(),' + Add Rule ')]/following-sibling::span[@class='mat-mdc-button-touch-target']"));

    public static final List<SelenideElement> Select_Operator = $$(By.xpath("//div//mat-select[contains(@id,'mat-select-') and @name='operator' and @placeholder='Select Operator']"));

    public static final SelenideElement Search_Button = $(By.xpath("//span[@class=\"mdc-button__label\" and contains(text(),'Search')]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));


    public static final SelenideElement ER_Search_Button = $(By.xpath("//span[@class='mdc-button__label' and contains(text(),'Search')]/following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Clear_Button = $(By.xpath("//span[@class='mat-button-wrapper' and contains(text(),'Clear')]"));
    public static final SelenideElement Remarks_Window = $(By.xpath("//textarea[contains(@id,'requesterComments')]"));
    public static final SelenideElement Enter_Remarks = $(By.xpath("//textarea[@placeholder='Enter Remarks']"));
    public static final SelenideElement Checkbox = $(By.xpath("//input[@type='checkbox']"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//span[contains(@class,'mdc-button__label') and contains(text(),'Cancel')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(@class,'mdc-button__label') and contains(text(),'Submit')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement System_Error_Toast_Message = $(By.xpath("//dynamic-view[@class='ng-star-inserted']//div[text()='System error']"));
    public static final SelenideElement Success_Toast_Message = $(By.xpath("//dynamic-view[@class='ng-star-inserted']//div[contains(text(),'Request submitted successfully . You can view the result anytime in Request-Response tab')]"));

    // Apply condition i.e., first condition visible then click/select
    public static SelenideElement ER_Source(String Entity) {
        SelenideElement Entity_Source = $(By.xpath("//span[@class='mdc-list-item__primary-text' and contains(text(),' " + Entity + " ')]"));
        return Entity_Source;
    }

    public static SelenideElement ER_Parameter(String Parameter) {
        SelenideElement element = $(By.xpath("//div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span[contains(text(),'" + Parameter + "')]"));
        return element;
    }

    public static SelenideElement ER_Operator(String Operator) {
        SelenideElement element = $(By.xpath("//div[@role='listbox' and @tabindex='-1']//mat-option[@role='option']//span[contains(text(),'" + Operator + "')]"));
        return element;
    }

    public static SelenideElement InputElementForParam(String Parameter) {
        SelenideElement element = $(By.xpath("//span[text()='" + Parameter + "']//parent::span//parent::div//parent::div//parent::mat-select//parent::div//parent::div//parent::div//parent::mat-form-field//parent::div//parent::div//parent::div[@class='ng-star-inserted']//div/input"));
        return element;
    }


}
