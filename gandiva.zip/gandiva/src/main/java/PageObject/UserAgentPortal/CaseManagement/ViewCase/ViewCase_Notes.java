/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class ViewCase_Notes {
    public static final SelenideElement Notes = $(By.xpath("//div//div[contains(text(),'Notes')]"));
    public static final SelenideElement Notes_Icon = $(By.xpath("//div[@id=\"noteicon\"]//button[contains(@class,\"mat-mdc-button-base\")]"));
    public static final SelenideElement Notes_Heading = $(By.xpath("//div[text()='Notes']"));
    public static final SelenideElement Personal_Notes = $(By.xpath("//*[text()='Personal Notes']"));
    public static final SelenideElement Case_Notes = $(By.xpath("(//*[text()='Case Notes'])[1]"));
    public static final SelenideElement No_Notes_Added_Yet_Text_Message = $(By.xpath("//div[text()=' No Notes Added Yet ']"));
    public static final SelenideElement Take_Note_Button = $(By.xpath("//button//span[text()='+Take a note...']//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Title_Input_Box = $(By.xpath("//mat-card//div//div[@class=\"w-full border rounded\"]//input[@placeholder=\"Title\"]"));
    public static final SelenideElement Description_Input_Box = $(By.xpath("//mat-card//div[@class=\"border rounded\"]//textarea[@placeholder=\"Description\"]"));
    public static final SelenideElement Add_Button = $(By.xpath("//button[text()='Add']"));
    public static final SelenideElement Personal_Notes_Toast_Message = $(By.xpath("//div[text()='Personal Note added successfully']"));
    public static final SelenideElement Case_Notes_Toast_Message = $(By.xpath("//div[text()='Case Note added successfully']"));
    public static final SelenideElement Close_Button = $(By.xpath("//span[@class=\"mat-mdc-button-touch-target\"]//preceding::span[@class=\"mat-mdc-focus-indicator\"]//preceding::img[@src=\"..\\assets\\icons\\close.svg\"]"));


    public static SelenideElement Note_Validation_Notes_Tab(String Note_Title) {
        SelenideElement element = $(By.xpath("//div[text()='Title ']/following-sibling::div[contains(text(),'"+Note_Title+"')]]"));
        return element;
    }


}
