/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class UseCase_Search {

//    ER result Cluster Table xpath
    public static final SelenideElement Use_Case_Selected_heading = $(By.xpath("//div[text()='No use case selected ']"));
    public static final SelenideElement Input_text = $(By.xpath("//input[contains(@class,'mat-input-element')]"));
    public static final SelenideElement Add_Button = $(By.xpath("//div//button//span[text()='Add']"));


    public static SelenideElement PO_Source(String PO_Source_Name) {
        SelenideElement PO_Source = $(By.xpath("//mat-card[contains(@class,'mat-card')]//mat-accordion//mat-expansion-panel[contains(@class,'mat-expansion-panel')]//mat-expansion-panel-header[@role='button' and @tabindex='0']//span//mat-panel-title//div[contains(text(),'" + PO_Source_Name + "')]"));
        return PO_Source;
    }

    public static tableImpl PO_UseCase(String PO_Source_Name) {
        SelenideElement PO_UseCase_Table = $(By.xpath("//div[contains(text(),'" + PO_Source_Name + "')]//parent::mat-panel-title//parent::span//parent::mat-expansion-panel-header//parent::mat-expansion-panel//table[@role='table']"));
        return new tableImpl(PO_UseCase_Table);
    }
    public static SelenideElement PO_UseCase_Title(String PO_UseCase_Name) {
        SelenideElement PO_UseCase_Title = $(By.xpath("//h1[text()='"+PO_UseCase_Name+"']"));
        return PO_UseCase_Title;
    }
    public static SelenideElement Use_Case_Query(String PO_Source_Name) {
        SelenideElement PO_UseCase_Title = $(By.xpath("//div[@class='mat-chip-list-wrapper']//mat-chip[@role='option']//div[text()='"+PO_Source_Name+"']"));
        return PO_UseCase_Title;
    }
}
