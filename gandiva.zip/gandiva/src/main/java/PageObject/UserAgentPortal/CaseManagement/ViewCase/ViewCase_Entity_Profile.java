/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase;

import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;


@Component
public class ViewCase_Entity_Profile {
    public static final SelenideElement Entity_Proﬁles = $(By.xpath("//div[contains(text(),'Entity Proﬁles')]"));
    public static final SelenideElement Remark_Textbox = $(By.xpath("//textarea[@id='requesterComments']"));
    public static final SelenideElement Checkbox = $(By.xpath("//mat-label[contains(text(),'Declaration')]//parent::div//mat-checkbox//div[@class=\"mdc-checkbox\"]//input[@type=\"checkbox\"]"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//span[contains(@class,'mdc-button__label') and contains(text(),'Cancel')]//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));
    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(@class,'mdc-button__label') and contains(text(),'Submit')]//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));
    public static final SelenideElement Remark_Title = $(By.xpath("//div[contains(text(),'Push To Agency Mart')]"));
    public static final SelenideElement Push_To_mart_Title = $(By.xpath("//div[contains(text(),'Push to Mart')]"));
    public static final SelenideElement ER_Checkbox = $(By.xpath("//div[@class='items-center h-auto ng-star-inserted']//div//div//mat-checkbox//label//span//span[@ng-reflect-disabled='false']"));
    public static final SelenideElement Push_data_Button = $(By.xpath("//span[contains(text(),'Push Data')]"));
    public static final SelenideElement Select_Entity_Profile = $(By.xpath("(//mat-checkbox[contains(@class,'mat-mdc-checkbox')]//div[@class=\"mat-mdc-checkbox-touch-target\"])[1]"));



    public static final SelenideElement GetActionButton(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[contains(text(),'" + caseName + "')]//parent::div//parent::div//parent::h3//parent::div//parent::div/div/div//button[@mattooltip='" + actionName + "']"));

        return action;
    }

    public static final SelenideElement Perform_Sharing_Profile_Action(String actionName) {
        SelenideElement action = $(By.xpath("//div[@role='menu']//div//button[text()=' " + actionName + " ']"));

        return action;
    }

    public static final SelenideElement Entity_Profile(String Entity_Profile_Name) {
        SelenideElement Profile = $(By.xpath("//*[contains(text(),'" + Entity_Profile_Name + "')]"));
        return Profile;
    }

    public static final SelenideElement Select_Entity_Profile_From_List(String Entity_Profile_Name) {
        SelenideElement Profile = $(By.xpath("(//button[contains(text(),' " + Entity_Profile_Name + "')]//parent::div//mat-checkbox[contains(@class,'mat-mdc-checkbox')]//div[@class='mdc-checkbox']//div[@class='mdc-checkbox__background'])[1]"));
        return Profile;
    }

}
