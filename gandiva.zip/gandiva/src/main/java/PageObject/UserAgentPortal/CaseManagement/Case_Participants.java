/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import java.time.Duration;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class Case_Participants {
    public static final SelenideElement Case_Participants_Heading = $(By.xpath("//div//h2[text()=' Case Participants ']"));
    public static final tableImpl Case_Participants_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mat-mdc-table')]")).shouldBe(Condition.visible, Duration.ofMinutes(5)));
    public static final SelenideElement Add_Case_Participants_heading = $(By.xpath("//div[text()='Add Case Participants']"));
    public static final SelenideElement Add_New_Participants_Button = $(By.xpath("//*[text()=' + Add New Participants']/parent::*"));
    public static final SelenideElement Select_Login_ID = $(By.xpath("//*//label//mat-label[text()='Select Login ID']"));
    public static final SelenideElement User_Login_ID = $(By.xpath("//*[@formcontrolname=\"userId\" and @role=\"combobox\"]"));
    public static final SelenideElement User_Login_ID_2 = $(By.xpath("(//*[@formcontrolname=\"userId\" and @role=\"combobox\"])[2]"));
    public static final SelenideElement User_Login_ID_3 = $(By.xpath("(//*[@formcontrolname=\"userId\" and @role=\"combobox\"])[3]"));
    public static final SelenideElement Search_Login_ID = $(By.xpath("//div[@role=\"listbox\"]//input[@placeholder=\"Search\"]"));
    public static final SelenideElement Remarks = $(By.xpath("//div//textarea[@formcontrolname=\"remarks\" and @id=\"remarks\"]"));
    public static final SelenideElement User_ID = $(By.xpath("//mat-option[@label=\"userData?.userLoginId\"]//span"));
    public static final SelenideElement User_ID_1 = $(By.xpath("//mat-option[@label=\"userData?.userLoginId\" and @ng-reflect-value=\"5976\"]//span"));
    public static final SelenideElement User_ID_2 = $(By.xpath("//mat-option[@label=\"userData?.userLoginId\" and @ng-reflect-value=\"5977\"]//span"));
    public static final SelenideElement Search_Bar = $(By.xpath("//input[@placeholder=\"Search\"]"));
    public static final SelenideElement Delete_Button = $(By.xpath("//div//span[contains(@class,\"material-icons\")]//img[contains(@class,'my-auto')]"));
    public static final ElementsCollection Login_ID_List_Box = $$(By.xpath("//div[@role=\"listbox\"]"));




    public static final SelenideElement Remove_Login_ID(String Username) {
        SelenideElement action = $(By.xpath("//div//mat-select[@role='combobox']//span[text()='" + Username + "']"));
        return action;
    }
    //div//mat-select[@role="combobox"]//span[text()='adsauth_2@devng.in']


}
