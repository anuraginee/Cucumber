/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class ER_Search {

//    ER result Cluster Table xpath

    public static final tableImpl ER_Result_Table = new tableImpl($(By.xpath("//table[@id='table_Er' and @role='table' and contains(@class,'mat-mdc-table')]")).should(Condition.appear));
    public static final SelenideElement Resolve_Entity = $(By.xpath("//span[contains(text(),'Resolve Entity')]"));
    public static final SelenideElement Attach_Entity_To_Case = $(By.xpath("//span[contains(text(),'Attach Entity To Case')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Confirmation_window = $(By.xpath("//div[text()='Confirmation']"));
    public static final SelenideElement Ok_Button = $(By.xpath("//span[text()='OK']"));
    public static final SelenideElement Yes_Button = $(By.xpath("//span[contains(text(),'Yes')]"));
    public static final SelenideElement Attach_Entity_To_Case_Title = $(By.xpath("//div[text()='Attach Entity To Case']"));
    public static final SelenideElement Profile_Name = $(By.xpath("(//div//div[@role='listbox']//mat-option[@role=\"option\" and @label=\"name\"]//span)[1]"));
    public static final SelenideElement Select_Profile_Name = $(By.xpath("//mat-select[@role='combobox']//div//span[text()='Please Select']"));
    public static final SelenideElement Entity_details = $(By.xpath("//div//mat-card[contains(@class,'break-inside-avoid')]//div[contains(@class,'justify-between')]/div/p[text()='FULL NAME']//following-sibling::p"));
    public static final SelenideElement Confirmation_message = $(By.xpath("//dynamic-view/div[text()='Profile Created Successfully']"));
    public static final SelenideElement Search_Bar = $(By.xpath("//input[@placeholder='Search']"));
    public static final SelenideElement Parameters_chip = $(By.xpath("(//span[contains(@class,'mat-mdc-chip-action-label')])[1]"));
    public static final SelenideElement Entity_Profile_Name = $(By.xpath("//div[@class=\"flex justify-between\"]//div[contains(@class,'font-semibold')]"));
//    public static final SelenideElement Entity_Profile_List = $(By.xpath("(//div[contains(@aria-describedby,'cdk-describedby-message-')]//button)[1]"));
    public static final SelenideElement Generate_Linkages = $(By.xpath("//span[@class=\"mat-mdc-button-touch-target\"]//parent::button[contains(@class,'mdc-button--raised ')]//span[@class=\"mdc-button__label\"]//img"));
    public static final SelenideElement Linkage_Heading = $(By.xpath("//*[text()='Linkages']"));
    public static final SelenideElement Linkage_Expand_Button = $(By.xpath("//span[text()='Expand']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
    public static final SelenideElement Reset_Button = $(By.xpath("//span[text()='Reset']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
    public static final SelenideElement Save_To_Profile_Button = $(By.xpath("//span[text()='Save to profile']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement Zoom_In_Button = $(By.xpath("//mat-icon[@data-mat-icon-name='zoom-in']"));
    public static final SelenideElement Zoom_Out_Button = $(By.xpath("//mat-icon[@data-mat-icon-name='zoom-out']"));
    public static final SelenideElement Close_Button = $(By.xpath("//mat-icon[@data-mat-icon-name='x-mark']"));
    public static final SelenideElement Attached_Linkage = $(By.xpath("//div[text()='Attached Linkages']"));






    public static SelenideElement Expand_button(String Param_Value) {
        SelenideElement Expand_button = $(By.xpath("(//div[contains(text(),'" + Param_Value + "')]//parent::td//parent::tr//td[contains(@class,'mat-column-expand')]/div/mat-icon[@role='img' and @color='primary']/button/img[@mattooltip='Expand'])[1]"));
        return Expand_button;
    }

    public static SelenideElement Select_Record(String Param_Value) {
        SelenideElement Expand_button = $(By.xpath("//div[contains(text(),'" + Param_Value + "')]//parent::td//parent::tr/td[@role='cell']/mat-checkbox"));
        return Expand_button;
    }

//    public static SelenideElement Entity_profile(String Entity_Profile_Name) {
//        SelenideElement Entity_profile = $(By.xpath("//div//div[@ng-reflect-message='" + Entity_Profile_Name + "']//button"));
//        return Entity_profile;
//    }

    public static SelenideElement Single_Record_Cluster(String Param_Value) {
        SelenideElement Expand_button = $(By.xpath("//div[contains(text(),'" + Param_Value + "')]//parent::td//parent::tr//td[contains(@class,'cdk-column-Show_Info')]//div[contains(@class,'unclickable')]//button"));
        return Expand_button;
    }
    public static SelenideElement Unmask_Record_Cluster(String Param_Value) {
        SelenideElement Expand_button = $(By.xpath("(//div[contains(text(),'" + Param_Value + "')]//parent::td//parent::tr//td[contains(@class,'cdk-column-Show_Info')]//button[@mattooltip=\"Unmask record\"])[1]"));
        return Expand_button;
    }
}
