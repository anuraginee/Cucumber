/*
Author : Prashant Deshmukh
Project : Natgrid (Gandiva)
Dated : 16-10-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover;

import PageObject.Common.CommonElements;
import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Image_Search extends CommonElements{
    public static final SelenideElement Upload_A_File = $(By.xpath("//div//div[@mattooltip='Browse files']/following-sibling::input"));
    public static final SelenideElement Upload_A_Folder = $(By.xpath("//app-image-search//div//div[2]//div[@class='flex']//div[contains(text(), \"Browse folder\")]//following-sibling::input"));
    public static final SelenideElement Upload_And_Search = $(By.xpath("//span[text()='Upload & search']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
    public static final SelenideElement Image_Processing = $(By.xpath("//div//img[@alt='Processing Image']"));
    public static final SelenideElement Remove_Image = $(By.xpath("//*[@mattooltip=\"Remove image\"]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement Remark = $("#requesterComments");
//    public static final SelenideElement Declaration_CheckBox = $("#mat-checkbox-3-input");
    public static final SelenideElement Declaration_text = $(By.xpath("//*[@type='checkbox']"));
    public static final SelenideElement SUBMIT_BUTTON = $(By.xpath("//*[text()=' Submit ']//following-sibling::span[@class='mat-mdc-button-touch-target']"));

    public static final SelenideElement Expand_Entity_panel = $(By.xpath("//mat-expansion-panel-header[aria-controls=contains(text(), \"cdk-accordion-child\")]"));
    public static final SelenideElement Expand_Entity = $(By.xpath("//mat-expansion-panel-header[contains(@class,'mat-expansion-toggle')]"));

    public static final tableImpl Entities_Result_Table = new tableImpl($(By.xpath("//table[contains(@class,'mat-mdc-table') and @role='table']")));

    public static final SelenideElement Select_All_Entities_Checkbox = $(By.xpath("//mat-checkbox[id=contains(text(), 'mat-checkbox')]"));
    public static final SelenideElement BUTTON_RESOLVE_ENTITY = $(By.xpath("//span[text()='Resolve Entity ']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));

    public static final SelenideElement BUTTON_ATTACH_ENTITY_TO_CASE = $(By.xpath("//*[text()='Attach Entity To Case']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));



}
