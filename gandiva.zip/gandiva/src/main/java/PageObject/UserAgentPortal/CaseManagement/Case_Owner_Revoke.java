/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class Case_Owner_Revoke {

    public static final SelenideElement Case_Owner_Revoke_Heading = $(By.xpath("//div//h2[text()=' Case Owner-Revoke ']"));
    public static final tableImpl Case_revoke_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mat-mdc-table')]")).should(Condition.appear));
    public static final SelenideElement Revoke_Case_Owner_heading = $(By.xpath("//div[text()='Revoke Case Owner']"));
    public static final SelenideElement Role_Name = $(By.xpath("//mat-select[@role=\"combobox\" and @formcontrolname=\"roleId\"]"));
    public static final ElementsCollection Role_Name_Drop_down = $$(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));
    public static final SelenideElement Assign_Officer = $(By.xpath("//mat-select[@role=\"combobox\" and @formcontrolname=\"userId\"]"));
    public static final ElementsCollection Assign_Officer_Drop_down = $$(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));
    public static final SelenideElement Search_Case = $(By.xpath("//*[@placeholder=\"Search\"]"));
    public static final SelenideElement Revoke = $( By.xpath("(//table[@role='table' and@ng-reflect-data-source='[object Object]']//tbody//tr[" + 1 + "]//td//button[text()='Revoke'])[1]"));
    public static final SelenideElement Remarks = $(By.xpath("//div//textarea[@id=\"remarks\"]"));
    public static final SelenideElement Revoke_Button = $(By.xpath("//*[text()=' Revoke ']"));
    public static final SelenideElement Revoke_Table_Button = $(By.xpath("//*[text()='Revoke']"));


    public static final SelenideElement getActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//parent::div//parent::div//button[@mattooltip='" + actionName + "']"));
        return action;
    }
}
