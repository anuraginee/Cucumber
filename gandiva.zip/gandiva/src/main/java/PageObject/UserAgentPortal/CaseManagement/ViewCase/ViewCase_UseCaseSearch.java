/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class ViewCase_UseCaseSearch {

//    public static final SelenideElement CBDT = $(By.xpath("//div[contains(text(),'CBDT')]"));


    public static final tableImpl Use_Case_List_Table = new tableImpl($(By.xpath("//table[@role='table' and contains(@class,'mat-table')]")));

    public static final SelenideElement CBDTusecase = $(By.xpath(" (//*[@ng-reflect-message='Raise Request'])[6]"));
    public static final SelenideElement CBDTusecase2 = $(By.xpath(" (//*[@ng-reflect-message='Raise Request'])[4]"));

    public static final SelenideElement CBDTusecase3 = $(By.xpath(" (//*[@ng-reflect-message='Raise Request'])[5]"));


    public static final SelenideElement FYlistdropdown = $(By.xpath("(//div[contains(@class,'mat-form-field-infix')])[2]"));
    public static final ElementsCollection FYlist = $$(By.xpath("//*[@class='mat-option-text']"));

    public static final SelenideElement YearRangedropdown = $(By.xpath("(//div[contains(@class,'mat-form-field-infix')])[2]"));
    public static final ElementsCollection YearRangelist = $$(By.xpath("//*[@class='mat-option-text']"));
    public static final SelenideElement PANno = $(By.xpath("//*[@id='pan']"));
    public static final SelenideElement TANno = $(By.xpath("//*[@id='tan']"));
    public static final SelenideElement Financial_Year = $(By.xpath("//mat-label[text()='Financial Year']//parent::label//parent::div//mat-select[@role='combobox']"));
    public static final SelenideElement Financial_Year_Search = $(By.xpath("//input[@placeholder=\"Search\"]"));
    public static final SelenideElement Year_Range = $(By.xpath("//mat-label[text()='Year Range']//parent::label//parent::div//mat-select[@role='combobox']"));
    public static final SelenideElement Select_Year_Range = $(By.xpath("(//mat-option[@role=\"option\"]//span[@class=\"mdc-list-item__primary-text\" and text()=' 1 '])[1]"));

    public static final SelenideElement Add_Button = $(By.xpath("//*[text()='Add']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement SelectedUseCase = $(By.xpath("//div[contains(text(),'Central Board of Direct Taxes')]"));
    public static final SelenideElement Use_Case_chip = $(By.xpath("//*[contains(text(),'Selected Use Case')]//parent::div//mat-chip-list"));
    public static final SelenideElement Ok_Button = $(By.xpath("//*[text()='Ok']//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));
    public static final SelenideElement SaveDraft = $(By.xpath("//img[@mattooltip='Save Draft']"));
    public static final SelenideElement SaveDraftName = $(By.xpath("//input[@data-placeholder='Enter Draft Name']"));
    public static final SelenideElement Save_Button = $(By.xpath("//div[@class='cdk-overlay-pane']//span[contains(@class,'mat-button-wrapper') and contains(text(),'Save')]"));
    public static final SelenideElement LowUseCase = $(By.xpath("//span[@class='mat-button-toggle-label-content' and contains(text(),'Low')]"));
    public static final SelenideElement CommentsText = $(By.xpath("//textarea[@id='requesterComments']"));
    public static final SelenideElement Declaration = $(By.xpath("//input[@type=\"checkbox\"]"));
    public static final SelenideElement Submit_Button_UseCase = $(By.xpath("//*[text()=' Submit ']//following-sibling::span[@class='mat-mdc-button-touch-target']"));
    public static final SelenideElement RequestResponseTab = $(By.xpath("//div[contains(text(),'Request-Response')]"));
    public static final SelenideElement ConfirmOk = $(By.xpath("//div[@class='cdk-overlay-pane']//div[contains(@class,'flex justify-end')]//button/span[@class='mat-button-wrapper' and contains(text(),'Ok')]"));

    public static final SelenideElement Submit_Button = $(By.xpath("//*[text()='Submit']//following-sibling::span[@class='mat-mdc-button-touch-target']"));


    //  Sensitive Use Cases
    public static final SelenideElement Confirmation_Title_Heading = $(By.xpath("//*[text()='Confirmation']"));
    public static final SelenideElement Confirmation_Ok_Button = $(By.xpath("//*[text()='Ok']//following-sibling::span[@class='mat-mdc-button-touch-target']"));


    public static SelenideElement Select_PO(String PO) {
        SelenideElement PO_Name = $(By.xpath("//mat-expansion-panel-header[@role='button']//mat-panel-title//div[contains(text(),'" + PO + "')]"));
        return PO_Name;
    }

    public static SelenideElement Financial_Year(String Year) {
        SelenideElement FinancialYear = ($(By.xpath("//mat-option[@role='option']//span[@class='mdc-list-item__primary-text' and text()=' " + Year + " ']")).should(Condition.appear));
        return FinancialYear;
    }

    public static SelenideElement Use_Case_Table(String PO) {
        SelenideElement UseCaseTable = ($(By.xpath("//div[contains(text(),'" + PO + "')]//parent::mat-panel-title//parent::span//parent::mat-expansion-panel-header//parent::mat-expansion-panel//table[@role='table']")));
        return UseCaseTable;
    }

    public static SelenideElement Use_Case_request_Page_Heading(String UseCase) {
        SelenideElement Use_Case_Heading = $(By.xpath("//h1[text()='" + UseCase + "']"));
        return Use_Case_Heading;
    }

    public static SelenideElement Use_Case(String PO, String UseCase) {
        SelenideElement Use_Case_Heading = $(By.xpath("//div[contains(text(),'" + PO + "')]//ancestor::mat-expansion-panel//div[@role=\"region\"]//table[contains(@class,'mdc-data-table__table')]//tbody//tr//td[contains(@class,'cdk-column-use_case_description')]//span[text()='" + UseCase + "']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//button[@mattooltip=\"Raise Request\"]"));
        return Use_Case_Heading;
    }

}
