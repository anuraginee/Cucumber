/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;


@Component
public class Cases {


    //Case management page tabs
    public static final SelenideElement Cases = $(By.xpath("//div//div//div//h2[contains(text(),'Cases')]"));
    public static final SelenideElement All_cases = $(By.xpath("//span[contains(text(),'All Cases')]"));
    public static final SelenideElement Active_Cases = $(By.xpath("//span[contains(text(),'Active Cases')]"));
    public static final SelenideElement Closed_Cases = $(By.xpath("//span[contains(text(),'Closed Cases')]"));
    //public static final SelenideElement Archived_Cases = $(By.xpath("//span[contains(text(),'Archived Cases')]")); //-- Depricated


    public static final SelenideElement User_role = $(By.xpath("//span[contains(@class,'mat-mdc-menu-trigger')]//span[2]"));
    public static final SelenideElement Sign_out = $(By.xpath("//span[contains(text(),'Sign out')]"));


//    User Profile

    public static final SelenideElement My_Profile_Title = $(By.xpath("//div[text()='My Proﬁle']"));
    public static final SelenideElement Login_ID = $(By.xpath("//p[text()='Login ID']//parent::div//p[@class='font-semibold']"));


    public static final SelenideElement User_Profile = $(By.xpath("//button//span[text()='Profile']"));

    // Advanced Search Xpaths
    public static final SelenideElement Advanced_Search = $(By.xpath("//span[contains(text(),'Advanced Search')]//following-sibling::span[@class=\"mat-mdc-button-touch-target\"]"));

    //Case initiation Xpath
    public static final SelenideElement Initiate_Case_button = $(By.xpath("//span[contains(text(),'Initiate Case')]//following-sibling::span[@class=\"mat-mdc-focus-indicator\"]"));
    //Fields in Case Initiation form
    public static final SelenideElement Case_Name = $(By.xpath("//input[contains(@id,'caseName')]"));
    public static final SelenideElement Search_bar = $(By.xpath("//div[@fxlayout='row']//input[@placeholder='Search']"));
    public static final SelenideElement physical_Digital_CaseId = $(By.id("physicalDigitalCaseId"));
    public static final SelenideElement Case_Description = $(By.id("caseDescription"));
    public static final SelenideElement Tags = $(By.xpath("//div//input[@formcontrolname='tag' and @type='text']"));
    public static final SelenideElement AddTags = $(By.xpath("//div//input[@formcontrolname='addTag' and @type='text']"));
    public static final ElementsCollection Tag_list = $$(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));
    public static final SelenideElement Tags_dropdown = $(By.xpath("//div[contains(@id,'cdk-overlay-')]//div[@role='listbox']//mat-option//span"));
    public static final SelenideElement Checkbox = $(By.xpath("//input[@type=\"checkbox\"]"));
    public static final SelenideElement Cancel_Button = $(By.xpath("//span[contains(text(),'Cancel')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Submit_Button = $(By.xpath("//span[contains(text(),'Submit')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement submit_Button = $(By.xpath("//span[contains(text(),'submit')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Yes_button = $(By.xpath("//span[contains(text(),'Yes')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement No_button = $(By.xpath("//span[contains(text(),'No')]//following-sibling::span[@class='mat-mdc-focus-indicator']"));
    public static final SelenideElement Case_Name_Validation = $(By.xpath("(//div[contains(@class,'case-name')])[1]"));
    public static final SelenideElement Case_Status_Button = $(By.xpath("(//div[@class=\"carousel-container\"]//button)[1]"));

    public static final SelenideElement Case_approved_Status = $(By.xpath("(//mat-chip[contains(text(),'Approved')])[1]"));
    public static final SelenideElement Case_Transfer_Request_PageHeading = $(By.xpath("(//div[contains(text(),'Case Transfer Request')])[2]"));

    public static final SelenideElement LogoutText = $(By.xpath("//div[contains(text(),'You have successfully logged out !')]"));
    public static final SelenideElement CaseName_Error_Message = $(By.xpath("//div//mat-error[text()=\" Please enter case name \"]"));
    public static final SelenideElement Physical_Digital_Case_ID_Error_message = $(By.xpath("//div//mat-error[text()=\"Please enter physical digital case ID \"]"));
    public static final SelenideElement Description_Error_Message = $(By.xpath("//div//mat-error[text()=\"Please enter description \"]"));
    public static final SelenideElement Tag_Error_message = $(By.xpath("//div//mat-error[text()=\" Tag type name not recognized. Click one of the autocomplete options. \"]"));



    public static final SelenideElement getActionButtonByCaseName(String caseName, String actionName) {
        SelenideElement action = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//parent::div//parent::div//button[@mattooltip='" + actionName + "']"));
        return action;
    }

    //    View case element in All Cases tab in Manage Case page under Case_management - Cases
    public static final SelenideElement ViewCaseByCaseName(String caseName) {
        SelenideElement ViewCase = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//parent::div//parent::div//div/button/span[contains(text(),'View Case')]"));
        return ViewCase;
    }

    public static final SelenideElement getCaseStatusByCaseName(String caseName, String Attributes) {
        SelenideElement attributes = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//div//mat-chip-list/div/span[contains(text(),'" + Attributes + "')]"));
        return attributes;
    }

    public static final SelenideElement getCaseStatusOnActiveCasesByCaseName(String caseName, String Attributes) {
        SelenideElement attributes = $(By.xpath("//div[text()='" + caseName + "']//parent::div//mat-chip[contains(text(),'" + Attributes + "')]"));
        return attributes;
    }

    public static final SelenideElement Case_Status(String caseName, String Attributes) {
        SelenideElement CaseStatus = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//div[@class='lg:w-full grid']//div[@class='carousel-container']//div[@class='md-stepper-horizontal green']//div[text()='" + Attributes + "']"));
        return CaseStatus;
    }

    public static final SelenideElement Case_Date_Time(String caseName, String Attributes) {
        SelenideElement CaseDateTime = $(By.xpath("//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//div[@class='lg:w-full grid']//div[@class='carousel-container']//div[@class='md-stepper-horizontal green']//div[text()='" + Attributes + "']//parent::div//div[@class='md-step-date']"));
        return CaseDateTime;
    }

    public static final SelenideElement Case_ID(String caseName) {
        SelenideElement CaseID = $(By.xpath("((//div[text()='" + caseName + "']//parent::div//parent::div//parent::div//div[contains(@class,'col-span-')])[3]//div[contains(@class,'text-gray-')])[1]"));
        return CaseID;
    }

}
