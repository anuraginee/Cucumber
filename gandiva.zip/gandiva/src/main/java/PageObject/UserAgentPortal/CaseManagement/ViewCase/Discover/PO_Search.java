/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.CaseManagement.ViewCase.Discover;

import org.springframework.stereotype.Component;


@Component
public class PO_Search {


}
