/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Common_Mart;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Common_Mart_Page {
    public static final SelenideElement Use_cases_Tab = $(By.xpath("//div[text()='Use Cases']"));
    public static final SelenideElement ER_Tab = $(By.xpath("//div[text()='ER Profiles']"));
    public static final SelenideElement Advanced_Search = $(By.xpath("//div[text()=' Advanced Search']"));
    public static final tableImpl Agency_Mart_ER_Table = new tableImpl($(By.xpath("//table[@role='table' and@ng-reflect-data-source='[object Object]']")).should(Condition.appear));
}
