/*
Author : Anuraginee Swain
Project : Natgrid (Gandiva)
Dated : 28-08-2023
*/
package PageObject.UserAgentPortal.Common_Mart;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;
import utils.table.tableImpl;

import static com.codeborne.selenide.Selenide.$;


@Component
public class Common_Mart_Approval_Page {

    public static final SelenideElement Common_Mart_Approval_Title = $(By.xpath("//div//h2[contains(text(),'Recommendation')]"));
    public static final SelenideElement Pending_Request = $(By.xpath("//div[@class='mat-tab-label-container']//div[@role='tablist']//div//div[@role='tab' and @tabindex='0']//div[@class='mat-tab-label-content']"));
    public static final SelenideElement Recommended_Not_Recommended_Requests = $(By.xpath("(//span[@class='mdc-tab__content'])[2]"));
    public static final tableImpl Common_Mart_Approval_Table = new tableImpl($(By.xpath("//table[@role='table' and@ng-reflect-data-source='[object Object]']")).should(Condition.appear));
    public static final SelenideElement Recommendation_Confirmation_Title = $(By.xpath("//div[contains(text(),'Recommendation Confirmation')]"));

    //    Designated Officer Xpaths
    public static final SelenideElement Approval_Title = $(By.xpath("//div[contains(text(),'Pending Requests')]"));


    public static final SelenideElement Expand_The_Request(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td//div[@aria-label='expand row']//img[@mattooltip='Expand']"));
        return action;
    }


    public static final SelenideElement Approve_Request(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//img[@mattooltip='Approve']"));
        return action;
    }

    public static final SelenideElement Reject_Request(String Query_Name) {
        SelenideElement action = $(By.xpath("//div[text()=' " + Query_Name + " ']//parent::td//following-sibling::td[contains(@class,'cdk-column-action')]//img[@mattooltip='Reject']"));
        return action;
    }

}
