package PageObject.UserAgentPortal;


import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;

import static com.codeborne.selenide.Selenide.$;

@Component
public class Reports_Xpath {

   public static final SelenideElement Cases = $(By.xpath("//div[contains(@class,'ng-trigger-expandCollapse')]//fuse-vertical-navigation-collapsable-item[@ng-reflect-name=\"mainNavigation\"]//div//div[@ng-reflect-ng-class=\"[object Object]\"]//div//div//span[contains(text(),'Case')]"));

   public static final SelenideElement Request = $(By.xpath("//div[contains(@class,'ng-trigger-expandCollapse')]//fuse-vertical-navigation-collapsable-item[@ng-reflect-name=\"mainNavigation\"]//div//div[@ng-reflect-ng-class=\"[object Object]\"]//div//div//span[contains(text(),'Request')]"));

   public static final SelenideElement Approval = $(By.xpath("//div[contains(@class,'ng-trigger-expandCollapse')]//fuse-vertical-navigation-collapsable-item[@ng-reflect-name=\"mainNavigation\"]//div//div[@ng-reflect-ng-class=\"[object Object]\"]//div//div//span[contains(text(),'Approval')]"));


   public static final SelenideElement Status_Of_Requests_Raised_For_Approval = $(By.xpath("//span[contains(text(),'Status Of Requests Raised For Approval')]"));
   public static final SelenideElement ListOfUsersWithCases = $(By.xpath("//span[contains(text(),'List Of Users With Cases')]"));
   public static final SelenideElement RequestAwaitingApprovingOfficer_Review_Approval = $(By.xpath("//span[contains(text(),'Request Awaiting Approving Officer Review/Approval')]"));
   public static final SelenideElement Case_Requests_Received_For_Review = $(By.xpath("//span[contains(text(),'Case Requests Received For Review')]"));
   public static final SelenideElement Case_Report_Nodal_Wise = $(By.xpath("//span[contains(text(),'Case Report Nodal Wise')]"));


   public static final SelenideElement Approval_Case_Requests_Pending_Approval = $(By.xpath("//span[contains(text(),'Case Requests Pending Approval')]"));
   public static final SelenideElement Approval_List_of_Pending_Requests_For_Recommendation = $(By.xpath("//span[contains(text(),' List Of Pending Requests For Recommendation ')]"));
   public static final SelenideElement Approval_List_Of_Pending_Query_Response_For_Their_Action = $(By.xpath("//span[contains(text(),'List Of Pending Query Response For Their Action')]"));
   public static final SelenideElement Approval_List_Of_All_Data_Mart_Requests = $(By.xpath("//span[contains(text(),'List Of All Data Mart Requests')]"));
   public static final SelenideElement Approval_List_Of_Pending_Query_Requests_For_Their_Action = $(By.xpath("//span[contains(text(),'List Of Pending Query Requests For Their Action')]"));


   public static final SelenideElement Request_Scheduled_Query_Summary = $(By.xpath("//span[contains(text(),'Scheduled Query Summary')]"));
   public static final SelenideElement Request_QR_Request_Summary = $(By.xpath("//span[contains(text(),'QR Request Summary')]"));
   public static final SelenideElement Request_List_of_Requests = $(By.xpath("//span[contains(text(),'List of Requests')]"));
   public static final SelenideElement Request_Request_History = $(By.xpath("//span[contains(text(),'Request History')]"));
   public static final SelenideElement Request_Request_Error = $(By.xpath("//span[contains(text(),'Request Error')]"));
   public static final SelenideElement Request_ER_Request_Summary = $(By.xpath("//span[contains(text(),'ER Request Summary')]"));
   public static final SelenideElement Request_Request_Summary = $(By.xpath("//span[contains(text(),'Request Summary')]"));


   public static final SelenideElement Case_Case_Summary = $(By.xpath("//span[contains(text(),'Case Summary')]"));
   public static final SelenideElement Case_List_of_Cases_With_Request = $(By.xpath("//span[contains(text(),'List of Cases With Request')]"));
   public static final SelenideElement Case_Case_History = $(By.xpath("//span[contains(text(),'Case History')]"));
   public static final SelenideElement Case_User_Wise_Case_Level_Requests = $(By.xpath("//span[contains(text(),'User Wise Case Level Requests')]"));
   public static final SelenideElement Case_Case_Transfer_From_Original_User = $(By.xpath("//span[contains(text(),'Case Transfer From Original User')]"));
   public static final SelenideElement Case_User_Wise_Case_Owner_And_Case_Participant = $(By.xpath("//span[contains(text(),'User Wise Case Owner And Case Participant')]"));
   public static final SelenideElement Case_Case_List = $(By.xpath("//span[contains(text(),'Case List')]"));



}
